-- day_plan_rules_migration.sql
-- -----------------------------------------------------------------
-- Optional (recommended) database-level safety net for the new
-- Day Plan rules:
--
--   1. Only ONE entry per CB Serial No is allowed for a single day.
--   2. Once a product is created for a CB Serial No (in
--      `added_products`), it can no longer be added to the plan.
--
-- The PHP code already enforces both rules before inserting, so
-- this migration is not strictly required for the app to work
-- correctly. Running it just adds a hard database-level guarantee
-- against race conditions / direct DB edits.
--
-- Safe to run on an existing `plan_demo` database that already has
-- the `day_plans` table (created automatically by
-- includes/day_plan_shared.php on first use).
-- -----------------------------------------------------------------

-- 1) Enforce "one entry per CB Serial No per day" at the DB level.
--    NOTE: if you already have duplicate (cb_serial_no, plan_date)
--    rows in day_plans from before this change, this ALTER will
--    fail with a duplicate-key error. In that case, first find and
--    remove/merge the duplicates, then re-run this statement:
--
--    SELECT cb_serial_no, plan_date, COUNT(*) c
--    FROM day_plans
--    GROUP BY cb_serial_no, plan_date
--    HAVING c > 1;

ALTER TABLE day_plans
    ADD UNIQUE KEY uniq_cb_per_day (cb_serial_no, plan_date);

-- 2) Helpful index for the "already has a product?" lock-out check
--    (added_products.cb_serial_no is looked up on every plan add).
--    Skip this if the column is already indexed/primary in your DB.

ALTER TABLE added_products
    ADD INDEX idx_added_products_cb (cb_serial_no);
