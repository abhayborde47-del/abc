-- extra_entry_migration.sql
-- Run this once in phpMyAdmin (or mysql CLI) against your `plan_demo` database.
--
-- Adds `entry_type` to `added_products` so the app can tell apart:
--   'Plan'  -> normal entry added by matching an existing CB Serial No in `plans`
--   'Extra' -> manual entry added via the new "Extra Entry" form (no plan match)
--
-- Note: the `status` column (Pending / In Progress / Completed) already exists
-- in your uploaded plan_demo.sql, so no change is needed there. The Add/Update
-- Product screens now show it as "Not Done" / "In Process" / "Completed".

ALTER TABLE `added_products`
    ADD COLUMN `entry_type` ENUM('Plan','Extra') NOT NULL DEFAULT 'Plan' AFTER `status`;
