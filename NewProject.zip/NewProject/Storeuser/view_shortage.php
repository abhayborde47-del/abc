<?php
require "../config.php";
require "../includes/auth_user.php";

// auth_user.php only confirms someone is logged in as a "user" - it doesn't
// know which department. This page is for storeemp only, so check that here.
if (($_SESSION['user_department'] ?? '') !== 'storeemp') {
    header("Location: ../login.php");
    exit;
}

$view = $_GET['view'] ?? 'shortage'; // 'shortage' (default) or 'full'
if (!in_array($view, ['shortage', 'full'])) {
    $view = 'shortage';
}

$kitNoSearch = trim($_GET['kit_no'] ?? '');
$poSearch    = trim($_GET['production_order'] ?? '');

$perPage = 13;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;

// -----------------------------------------------------------------
// Resolve the search into a KITNO filter.
// - Searching by KITNO uses it directly.
// - Searching by Production Order first looks up which KITNO it
//   belongs to, then shows every remaining row (per the Shortage/Full
//   toggle) for that whole KITNO, not just the single order row.
// -----------------------------------------------------------------
$kitFilter   = '';
$searchError = '';

if ($kitNoSearch !== '') {
    $kitFilter = $kitNoSearch;
} elseif ($poSearch !== '') {
    $stmt = $conn->prepare("SELECT kit_no FROM plansstore WHERE production_order = ? LIMIT 1");
    $stmt->bind_param("s", $poSearch);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res && $res->num_rows > 0) {
        $kitFilter = $res->fetch_assoc()['kit_no'];
    } else {
        $searchError = 'No record found for Production Order "' . $poSearch . '".';
    }
    $stmt->close();
}

$joinType    = $view === 'shortage' ? 'LEFT JOIN' : 'INNER JOIN';
$statusWhere = $view === 'shortage'
    ? "COALESCE(ps.status,'shortage') = 'shortage'"
    : "ps.status = 'full'";

$where  = "WHERE $statusWhere";
$params = [];
$types  = '';

if ($kitFilter !== '') {
    $where   .= " AND p.kit_no = ?";
    $params[] = $kitFilter;
    $types   .= 's';
} elseif ($poSearch !== '') {
    // Production order search that resolved to nothing -> force empty result set.
    $where .= " AND 1 = 0";
}

// Total count, for pagination
$countSql = "
    SELECT COUNT(*) AS total
    FROM plansstore p
    $joinType plan_status ps ON ps.plan_id = p.id
    $where
";
$countStmt = $conn->prepare($countSql);
if ($types !== '') { $countStmt->bind_param($types, ...$params); }
$countStmt->execute();
$totalRows = (int)($countStmt->get_result()->fetch_assoc()['total'] ?? 0);
$countStmt->close();

$totalPages = max(1, (int)ceil($totalRows / $perPage));
if ($page > $totalPages) {
    $page   = $totalPages;
    $offset = ($page - 1) * $perPage;
}

$statusSelect = $view === 'shortage' ? "COALESCE(ps.status,'shortage') AS status" : "ps.status";

// created_by / updated_by both come from plan_status. created_by is only
// ever set once (at INSERT time in save_status.php) so it reflects who
// first touched the row; updated_by reflects whoever saved most recently.
$sql = "
    SELECT p.*, $statusSelect, ps.shortage_qty, ps.created_by, ps.updated_by, ps.updated_at
    FROM plansstore p
    $joinType plan_status ps ON ps.plan_id = p.id
    $where
    ORDER BY p.id ASC
    LIMIT ? OFFSET ?
";

$stmt = $conn->prepare($sql);
$allParams   = $params;
$allTypes    = $types . 'ii';
$allParams[] = $perPage;
$allParams[] = $offset;
$stmt->bind_param($allTypes, ...$allParams);
$stmt->execute();
$result = $stmt->get_result();

$rows = [];
while ($r = $result->fetch_assoc()) { $rows[] = $r; }
$stmt->close();

// Helper to build a pagination/query-string URL that keeps the current filters
function shortagePageUrl($view, $kitNoSearch, $poSearch, $page) {
    $params = ['view' => $view, 'page' => $page];
    if ($kitNoSearch !== '') { $params['kit_no'] = $kitNoSearch; }
    if ($poSearch !== '')    { $params['production_order'] = $poSearch; }
    return 'view_shortage.php?' . http_build_query($params);
}

// CHANGED: Download Excel now carries the active search straight through to
// download_shortage.php, so it downloads exactly what's on screen instead of
// landing on a blank filter form the admin has to fill in again.
function downloadUrl($view, $kitNoSearch, $poSearch) {
    $params = ['view' => $view];
    if ($kitNoSearch !== '') { $params['kit_no'] = $kitNoSearch; }
    if ($poSearch !== '')    { $params['production_order'] = $poSearch; }
    return 'download_shortage.php?' . http_build_query($params);
}

$redirectUrl = htmlspecialchars($_SERVER['REQUEST_URI']);
?>
<?php include "../includes/header.php"; ?>

  <?php include "../includes/storesidebar_user.php"; ?>

  <!-- Main content -->
  <div class="flex-grow-1 p-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
      <h3 class="mb-0">View Shortage</h3>
      <div>
        <a href="view_shortage.php?view=shortage" class="btn btn-sm <?= $view === 'shortage' ? 'btn-danger' : 'btn-outline-danger' ?>">Shortage</a>
        <a href="view_shortage.php?view=full" class="btn btn-sm <?= $view === 'full' ? 'btn-success' : 'btn-outline-success' ?>">Full</a>
        <a href="<?= htmlspecialchars(downloadUrl($view, $kitNoSearch, $poSearch)) ?>" class="btn btn-sm btn-outline-primary">Download Excel</a>
      </div>
    </div>

    <!-- Search by KITNO or Production Order. Production Order resolves to its KITNO
         and shows every remaining row for that KITNO. -->
    <div class="row mb-3 gy-2">
      <div class="col-md-5">
        <form action="view_shortage.php" method="GET" class="d-flex">
          <input type="hidden" name="view" value="<?= htmlspecialchars($view) ?>">
          <input type="text" name="kit_no" class="form-control me-2"
                 placeholder="Search by KITNO" value="<?= htmlspecialchars($kitNoSearch) ?>">
          <button type="submit" class="btn btn-primary text-nowrap">Search</button>
        </form>
      </div>
      <div class="col-md-5">
        <form action="view_shortage.php" method="GET" class="d-flex">
          <input type="hidden" name="view" value="<?= htmlspecialchars($view) ?>">
          <input type="text" name="production_order" class="form-control me-2"
                 placeholder="Search by Production Order" value="<?= htmlspecialchars($poSearch) ?>">
          <button type="submit" class="btn btn-success text-nowrap">Search</button>
        </form>
      </div>
      <?php if ($kitNoSearch !== '' || $poSearch !== ''): ?>
        <div class="col-md-2">
          <a href="view_shortage.php?view=<?= htmlspecialchars($view) ?>" class="btn btn-outline-secondary w-100">Clear</a>
        </div>
      <?php endif; ?>
    </div>

    <?php if ($searchError !== ''): ?>
      <div class="alert alert-warning"><?= htmlspecialchars($searchError) ?></div>
    <?php elseif ($kitFilter !== ''): ?>
      <div class="alert alert-info">
        Showing all remaining <?= $view === 'shortage' ? 'shortage' : 'full' ?> rows for KITNO
        <strong><?= htmlspecialchars($kitFilter) ?></strong>.
      </div>
    <?php endif; ?>

    <?php if (empty($rows)): ?>
      <?php if ($searchError === ''): ?>
        <div class="alert alert-info">No <?= $view === 'shortage' ? 'shortage' : 'full' ?> records found.</div>
      <?php endif; ?>
    <?php else: ?>
      <!-- Each row saves independently: its own <form> and its own Save button
           inside the Edit cell. The qty box takes the QTY RECEIVED IN THIS UPDATE,
           not the remaining shortage. save_status.php subtracts it from the
           current remaining shortage server-side. -->
      <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle">
          <thead class="<?= $view === 'shortage' ? 'table-danger' : 'table-success' ?>">
            <tr>
              <th>KITNO</th>
              <th>Rating</th>
              <th>Kit Size</th>
              <th>Date</th>
              <th>Material</th>
              <th>Material Description</th>
              <th>Total</th>
              <?php if ($view === 'shortage'): ?><th>Shortage Qty</th><?php endif; ?>
              <th>Created By</th>
              <th>Updated By</th>
              <th width="240">Edit</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rows as $r): ?>
              <?php
                $isFull = $r['status'] === 'full';
                $id     = (int)$r['id'];
                // Shortage still outstanding right now (before this submission).
                $currentShortage = $r['shortage_qty'] ?? $r['total'];
              ?>
              <tr class="status-row <?= $view === 'shortage' ? 'table-danger' : 'table-success' ?>" data-id="<?= $id ?>">
                <td><?= htmlspecialchars($r['kit_no']) ?></td>
                <td><?= htmlspecialchars($r['rating']) ?></td>
                <td><?= htmlspecialchars($r['kit_size']) ?></td>
                <td><?= htmlspecialchars($r['plan_date']) ?></td>
                <td><?= htmlspecialchars($r['material']) ?></td>
                <td><?= htmlspecialchars($r['material_description']) ?></td>
                <td><?= htmlspecialchars($r['total']) ?></td>
                <?php if ($view === 'shortage'): ?>
                  <td><?= htmlspecialchars($r['shortage_qty'] ?? '') ?></td>
                <?php endif; ?>
                <td><?= htmlspecialchars($r['created_by'] ?? '-') ?></td>
                <td><?= htmlspecialchars($r['updated_by'] ?? '-') ?></td>
                <td>
                  <form method="POST" action="save_status.php" class="row-status-form">
                    <input type="hidden" name="redirect" value="<?= $redirectUrl ?>">
                    <input type="hidden" name="plan_ids[]" value="<?= $id ?>">

                    <div class="form-check">
                      <input class="form-check-input full-checkbox" type="checkbox"
                             id="full-<?= $id ?>" name="full[<?= $id ?>]" value="1"
                             <?= $isFull ? 'checked' : '' ?>>
                      <label class="form-check-label" for="full-<?= $id ?>">Full</label>
                    </div>

                    <div class="shortage-box" id="shortage-box-<?= $id ?>"
                         style="display:<?= $isFull ? 'none' : 'block' ?>;">
                      <div class="form-text mb-1">Currently short: <strong><?= htmlspecialchars($currentShortage) ?></strong></div>
                      <input type="text" name="received_qty[<?= $id ?>]" class="form-control form-control-sm mb-2"
                             placeholder="Enter qty received now">
                    </div>

                    <button type="submit" class="btn btn-primary btn-sm">Save</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <!-- Pagination: 20 rows per page -->
      <?php if ($totalPages > 1): ?>
        <nav class="d-flex justify-content-between align-items-center mt-3">
          <div class="text-muted small">
            Page <?= $page ?> of <?= $totalPages ?> (<?= $totalRows ?> records)
          </div>
          <ul class="pagination mb-0">
            <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
              <a class="page-link" href="<?= $page > 1 ? htmlspecialchars(shortagePageUrl($view, $kitNoSearch, $poSearch, $page - 1)) : '#' ?>">Previous</a>
            </li>
            <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
              <a class="page-link" href="<?= $page < $totalPages ? htmlspecialchars(shortagePageUrl($view, $kitNoSearch, $poSearch, $page + 1)) : '#' ?>">Next</a>
            </li>
          </ul>
        </nav>
      <?php endif; ?>
    <?php endif; ?>

  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarToggle')?.addEventListener('click', function () {
    document.getElementById('sidebar').classList.toggle('d-none');
});

// Checkbox just toggles this row's shortage box. Nothing is sent anywhere
// until THIS row's own Save button is clicked.
document.querySelectorAll('.full-checkbox').forEach(function (cb) {
    cb.addEventListener('change', function () {
        var row = cb.closest('.status-row');
        var box = row.querySelector('.shortage-box');
        box.style.display = cb.checked ? 'none' : 'block';
        if (!cb.checked) {
            box.querySelector('input[name^="received_qty"]').focus();
        }
    });
});

// Each row validates only itself before its own Save submits.
document.querySelectorAll('.row-status-form').forEach(function (form) {
    form.addEventListener('submit', function (e) {
        var cb = form.querySelector('.full-checkbox');
        var qtyInput = form.querySelector('input[name^="received_qty"]');
        if (!cb.checked && qtyInput.value.trim() === '') {
            e.preventDefault();
            form.querySelector('.shortage-box').classList.add('border', 'border-danger');
            alert('Please enter a received quantity, or mark this row Full.');
        }
    });
});
</script>
</body>
</html>