<?php
require "../config.php"; // config.php already calls session_start()
require "../includes/security.php";

// --- Auth guard: only logged-in store employees allowed here ---
if (!isset($_SESSION['user_email']) || $_SESSION['user_department'] !== 'storeemp') {
    header("Location: ../index.php");
    exit;
}

$msg = "";
$msgType = "info";

$user_email = $_SESSION['user_email'] ?? '';

/* Make sure the table exists even on a fresh install */
$conn->query("
    CREATE TABLE IF NOT EXISTS queries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_email VARCHAR(150) NOT NULL,
        subject VARCHAR(200) NOT NULL,
        message TEXT NOT NULL,
        status ENUM('Open','In Progress','Resolved') NOT NULL DEFAULT 'Open',
        admin_reply TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_user_email (user_email),
        INDEX idx_status (status)
    )
");


/* =========================================================
   SUBMIT NEW QUERY
========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_query'])) {

    csrf_verify($_POST['csrf_token'] ?? '');

    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($subject === '' || $message === '') {
        $msg = "Please fill in both Subject and Message.";
        $msgType = "danger";
    } else {
        $stmt = $conn->prepare(
            "INSERT INTO queries (user_email, subject, message) VALUES (?, ?, ?)"
        );
        $stmt->bind_param("sss", $user_email, $subject, $message);

        if ($stmt->execute()) {
            $msg = "Your query has been submitted.";
            $msgType = "success";
        } else {
            $msg = "Error submitting query: " . htmlspecialchars($conn->error);
            $msgType = "danger";
        }
    }
}


/* =========================================================
   UPDATE OWN QUERY (only while still Open)
========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_query'])) {

    csrf_verify($_POST['csrf_token'] ?? '');

    $id      = (int)($_POST['id'] ?? 0);
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($subject === '' || $message === '') {
        $msg = "Please fill in both Subject and Message.";
        $msgType = "danger";
    } else {
        $stmt = $conn->prepare(
            "UPDATE queries
             SET subject = ?, message = ?
             WHERE id = ? AND user_email = ? AND status = 'Open'"
        );
        $stmt->bind_param("ssis", $subject, $message, $id, $user_email);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            $msg = "Query updated.";
            $msgType = "success";
        } else {
            $msg = "That query can no longer be edited (it may already be in progress or resolved).";
            $msgType = "warning";
        }
    }
}


/* =========================================================
   DELETE OWN QUERY
========================================================= */
if (isset($_GET['delete'])) {

    csrf_verify($_GET['csrf_token'] ?? '');

    $id = (int)$_GET['delete'];

    $stmt = $conn->prepare("DELETE FROM queries WHERE id = ? AND user_email = ?");
    $stmt->bind_param("is", $id, $user_email);
    $stmt->execute();

    header("Location: queries.php?deleted=1");
    exit;
}

if (isset($_GET['deleted'])) {
    $msg = "Query deleted.";
    $msgType = "success";
}


/* =========================================================
   FETCH: query being edited (if any) + own query list
========================================================= */
$editQuery = null;
if (isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    $stmt = $conn->prepare("SELECT * FROM queries WHERE id = ? AND user_email = ?");
    $stmt->bind_param("is", $editId, $user_email);
    $stmt->execute();
    $editQuery = $stmt->get_result()->fetch_assoc();
}

$stmt = $conn->prepare("SELECT * FROM queries WHERE user_email = ? ORDER BY created_at DESC");
$stmt->bind_param("s", $user_email);
$stmt->execute();
$myQueries = $stmt->get_result();

function query_status_badge($status) {
    $map = [
        'Open'        => 'bg-warning text-dark',
        'In Progress' => 'bg-info text-dark',
        'Resolved'    => 'bg-success',
    ];
    $class = $map[$status] ?? 'bg-secondary';
    return '<span class="badge ' . $class . '">' . htmlspecialchars($status) . '</span>';
}
?>

<?php include "../includes/header.php"; ?>

  <?php include "../includes/storesidebar_user.php"; ?>

  <!-- Main content -->
  <div class="flex-grow-1 p-4">

    <h4 class="mb-3">My Queries</h4>

    <?php if ($msg): ?>
        <div class="alert alert-<?= $msgType ?> alert-dismissible fade show">
            <?= htmlspecialchars($msg) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- SUBMIT / EDIT FORM -->
    <div class="card mb-4">
        <div class="card-header">
            <?= $editQuery ? 'Edit Query' : 'Submit a New Query' ?>
        </div>
        <div class="card-body">
            <form method="POST">
                <?php csrf_field(); ?>

                <?php if ($editQuery): ?>
                    <input type="hidden" name="id" value="<?= (int)$editQuery['id'] ?>">
                <?php endif; ?>

                <div class="mb-3">
                    <label class="form-label">Subject</label>
                    <input type="text" name="subject" class="form-control" required
                           maxlength="200"
                           value="<?= htmlspecialchars($editQuery['subject'] ?? '') ?>">
                </div>

                <div class="mb-3">
                    <label class="form-label">Message</label>
                    <textarea name="message" class="form-control" rows="3" required><?= htmlspecialchars($editQuery['message'] ?? '') ?></textarea>
                </div>

                <?php if ($editQuery): ?>
                    <button type="submit" name="update_query" class="btn btn-success">Save Changes</button>
                    <a href="queries.php" class="btn btn-secondary">Cancel</a>
                <?php else: ?>
                    <button type="submit" name="add_query" class="btn btn-primary">Submit Query</button>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <!-- MY QUERY LIST -->
    <div class="card">
        <div class="card-header">
            <h5 class="mb-0">My Submitted Queries</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>Subject</th>
                            <th>Message</th>
                            <th>Status</th>
                            <th>Admin Reply</th>
                            <th>Submitted</th>
                            <th width="160">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($myQueries && $myQueries->num_rows > 0): ?>
                        <?php while ($q = $myQueries->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($q['subject']) ?></td>
                                <td style="max-width:280px; white-space:pre-wrap;"><?= htmlspecialchars($q['message']) ?></td>
                                <td><?= query_status_badge($q['status']) ?></td>
                                <td style="max-width:220px; white-space:pre-wrap;">
                                    <?= $q['admin_reply'] ? htmlspecialchars($q['admin_reply']) : '<span class="text-muted">No reply yet</span>' ?>
                                </td>
                                <td><?= htmlspecialchars($q['created_at']) ?></td>
                                <td class="text-nowrap">
                                    <?php if ($q['status'] === 'Open'): ?>
                                        <a href="queries.php?edit=<?= (int)$q['id'] ?>" class="btn btn-sm btn-primary">Edit</a>
                                    <?php endif; ?>
                                    <a href="?delete=<?= (int)$q['id'] ?>&csrf_token=<?= urlencode(csrf_token()) ?>"
                                       class="btn btn-sm btn-danger"
                                       onclick="return confirm('Delete this query?')">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-3">You haven't submitted any queries yet.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

</body>
</html>
