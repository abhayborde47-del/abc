<?php

require "../config.php";
require "../includes/auth_user.php";
require "../includes/security.php";


if (
    strtolower(trim($_SESSION['user_department']))
    !== 'sscontrol'
) {
    header("Location: ../login.php");
    exit;
}


$id = (int)($_GET['id'] ?? 0);


if ($id <= 0) {

    require "../includes/header.php";
    require "../includes/sidebar_admin.php";

    echo '
    <div class="content">
        <div class="container-fluid">

            <div class="alert alert-danger mt-4">
                Invalid entry ID.
            </div>

            <a href="view.php" class="btn btn-secondary">
                Back to Entries
            </a>

        </div>
    </div>';

    exit;
}


$stmt = $conn->prepare("
    SELECT
        id,
        so_no_new,
        panel_status,
        panel_other_desc,
        mb_status,
        mb_other_desc,
        cable_status,
        cable_other_desc,
        rating_plate_status,
        rating_plate_other_desc,
        remark
    FROM sscontrol_entries
    WHERE id = ?
    LIMIT 1
");


if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}


$stmt->bind_param("i", $id);

$stmt->execute();

$result = $stmt->get_result();

$row = $result->fetch_assoc();

$stmt->close();


if (!$row) {

    require "../includes/header.php";
    require "../includes/sidebar_admin.php";

    echo '
    <div class="content">
        <div class="container-fluid">

            <div class="alert alert-danger mt-4">
                SSControl entry not found.
            </div>

            <a href="view.php" class="btn btn-secondary">
                Back to Entries
            </a>

        </div>
    </div>';

    exit;
}


$so_no_new =
    $row['so_no_new'] ?? '';

$panel_status =
    $row['panel_status'] ?? '';

$panel_other_desc =
    $row['panel_other_desc'] ?? '';

$mb_status =
    $row['mb_status'] ?? '';

$mb_other_desc =
    $row['mb_other_desc'] ?? '';

$cable_status =
    $row['cable_status'] ?? '';

$cable_other_desc =
    $row['cable_other_desc'] ?? '';

$rating_plate_status =
    $row['rating_plate_status'] ?? '';

$rating_plate_other_desc =
    $row['rating_plate_other_desc'] ?? '';

$remark =
    $row['remark'] ?? '';

?>

<?php require "../includes/header.php"; ?>

<?php require "../includes/sidebar_admin.php"; ?>


<div class="content">

    <div class="container-fluid">

        <div class="d-flex justify-content-between align-items-center mb-4">

            <div>

                <h2>Edit SSControl Entry</h2>

                <p class="text-muted mb-0">
                    Update SSControl information
                </p>

            </div>

            <a
                href="view.php"
                class="btn btn-secondary"
            >
                ← Back to Entries
            </a>

        </div>


        <div class="card shadow-sm">

            <div class="card-body">

                <form
                    method="POST"
                    action="update.php"
                >

                    <input
                        type="hidden"
                        name="id"
                        value="<?= (int)$id ?>"
                    >


                    <div class="row g-3">


                        <!-- SO -->

                        <div class="col-md-6">

                            <label class="form-label fw-semibold">
                                SO No.
                            </label>

                            <input
                                type="text"
                                name="so_no_new"
                                class="form-control"
                                value="<?= htmlspecialchars($so_no_new) ?>"
                                required
                            >

                        </div>


                        <!-- PANEL -->

                        <div class="col-md-6">

                            <label class="form-label fw-semibold">
                                Panel Status
                            </label>

                            <select
                                name="panel_status"
                                id="panel_status"
                                class="form-select"
                                required
                            >

                                <option value="">
                                    Select Status
                                </option>

                                <option value="Yes"
                                    <?= $panel_status === 'Yes' ? 'selected' : '' ?>>
                                    Yes
                                </option>

                                <option value="No"
                                    <?= $panel_status === 'No' ? 'selected' : '' ?>>
                                    No
                                </option>

                                <option value="Not Applicable"
                                    <?= $panel_status === 'Not Applicable' ? 'selected' : '' ?>>
                                    Not Applicable
                                </option>

                                <option value="Other"
                                    <?= $panel_status === 'Other' ? 'selected' : '' ?>>
                                    Other
                                </option>

                            </select>

                        </div>


                        <!-- PANEL OTHER -->

                        <div
                            class="col-md-6"
                            id="panel_other_div"
                            style="<?= $panel_status === 'Other' ? '' : 'display:none;' ?>"
                        >

                            <label class="form-label fw-semibold">
                                Panel Description
                            </label>

                            <input
                                type="text"
                                name="panel_other_desc"
                                class="form-control"
                                value="<?= htmlspecialchars($panel_other_desc) ?>"
                            >

                        </div>


                        <!-- MB -->

                        <div class="col-md-6">

                            <label class="form-label fw-semibold">
                                MB Status
                            </label>

                            <select
                                name="mb_status"
                                id="mb_status"
                                class="form-select"
                                required
                            >

                                <option value="">
                                    Select Status
                                </option>

                                <option value="Yes"
                                    <?= $mb_status === 'Yes' ? 'selected' : '' ?>>
                                    Yes
                                </option>

                                <option value="No"
                                    <?= $mb_status === 'No' ? 'selected' : '' ?>>
                                    No
                                </option>

                                <option value="Not Applicable"
                                    <?= $mb_status === 'Not Applicable' ? 'selected' : '' ?>>
                                    Not Applicable
                                </option>

                                <option value="Other"
                                    <?= $mb_status === 'Other' ? 'selected' : '' ?>>
                                    Other
                                </option>

                            </select>

                        </div>


                        <!-- MB OTHER -->

                        <div
                            class="col-md-6"
                            id="mb_other_div"
                            style="<?= $mb_status === 'Other' ? '' : 'display:none;' ?>"
                        >

                            <label class="form-label fw-semibold">
                                MB Description
                            </label>

                            <input
                                type="text"
                                name="mb_other_desc"
                                class="form-control"
                                value="<?= htmlspecialchars($mb_other_desc) ?>"
                            >

                        </div>


                        <!-- CABLE -->

                        <div class="col-md-6">

                            <label class="form-label fw-semibold">
                                Cable Status
                            </label>

                            <select
                                name="cable_status"
                                id="cable_status"
                                class="form-select"
                                required
                            >

                                <option value="">
                                    Select Status
                                </option>

                                <option value="Yes"
                                    <?= $cable_status === 'Yes' ? 'selected' : '' ?>>
                                    Yes
                                </option>

                                <option value="No"
                                    <?= $cable_status === 'No' ? 'selected' : '' ?>>
                                    No
                                </option>

                                <option value="Not Applicable"
                                    <?= $cable_status === 'Not Applicable' ? 'selected' : '' ?>>
                                    Not Applicable
                                </option>

                                <option value="Other"
                                    <?= $cable_status === 'Other' ? 'selected' : '' ?>>
                                    Other
                                </option>

                            </select>

                        </div>


                        <!-- CABLE OTHER -->

                        <div
                            class="col-md-6"
                            id="cable_other_div"
                            style="<?= $cable_status === 'Other' ? '' : 'display:none;' ?>"
                        >

                            <label class="form-label fw-semibold">
                                Cable Description
                            </label>

                            <input
                                type="text"
                                name="cable_other_desc"
                                class="form-control"
                                value="<?= htmlspecialchars($cable_other_desc) ?>"
                            >

                        </div>


                        <!-- RATING -->

                        <div class="col-md-6">

                            <label class="form-label fw-semibold">
                                Rating Plate Status
                            </label>

                            <select
                                name="rating_plate_status"
                                id="rating_plate_status"
                                class="form-select"
                                required
                            >

                                <option value="">
                                    Select Status
                                </option>

                                <option value="Yes"
                                    <?= $rating_plate_status === 'Yes' ? 'selected' : '' ?>>
                                    Yes
                                </option>

                                <option value="No"
                                    <?= $rating_plate_status === 'No' ? 'selected' : '' ?>>
                                    No
                                </option>

                                <option value="Not Applicable"
                                    <?= $rating_plate_status === 'Not Applicable' ? 'selected' : '' ?>>
                                    Not Applicable
                                </option>

                                <option value="Other"
                                    <?= $rating_plate_status === 'Other' ? 'selected' : '' ?>>
                                    Other
                                </option>

                            </select>

                        </div>


                        <!-- RATING OTHER -->

                        <div
                            class="col-md-6"
                            id="rating_plate_other_div"
                            style="<?= $rating_plate_status === 'Other' ? '' : 'display:none;' ?>"
                        >

                            <label class="form-label fw-semibold">
                                Rating Plate Description
                            </label>

                            <input
                                type="text"
                                name="rating_plate_other_desc"
                                class="form-control"
                                value="<?= htmlspecialchars($rating_plate_other_desc) ?>"
                            >

                        </div>


                        <!-- REMARK -->

                        <div class="col-12">

                            <label class="form-label fw-semibold">
                                Remark
                            </label>

                            <textarea
                                name="remark"
                                class="form-control"
                                rows="4"
                            ><?= htmlspecialchars($remark) ?></textarea>

                        </div>


                    </div>


                    <div class="mt-4 d-flex gap-2">

                        <button
                            type="submit"
                            class="btn btn-success"
                        >
                            Update Entry
                        </button>

                        <a
                            href="view.php"
                            class="btn btn-secondary"
                        >
                            Cancel
                        </a>

                    </div>


                </form>

            </div>

        </div>

    </div>

</div>


<script>

function toggleOther(selectId, divId) {

    const select =
        document.getElementById(selectId);

    const div =
        document.getElementById(divId);


    function updateVisibility() {

        if (select.value === "Other") {

            div.style.display = "";

        } else {

            div.style.display = "none";

        }

    }


    select.addEventListener(
        "change",
        updateVisibility
    );


    updateVisibility();
}


toggleOther(
    "panel_status",
    "panel_other_div"
);


toggleOther(
    "mb_status",
    "mb_other_div"
);


toggleOther(
    "cable_status",
    "cable_other_div"
);


toggleOther(
    "rating_plate_status",
    "rating_plate_other_div"
);

</script>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="../assets/js/script.js"></script>

</body>
</html>