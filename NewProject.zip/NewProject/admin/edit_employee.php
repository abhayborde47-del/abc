<?php
require "../config.php";
require "../includes/auth_admin_ais.php";

$msg = "";
$employee_code = $_GET['employee_code'] ?? ($_POST['employee_code'] ?? '');

if ($employee_code === '') {
    header("Location: employees.php");
    exit;
}

/* Handle Update */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_employee'])) {

    $factory = trim($_POST['factory']);
    $name    = trim($_POST['name']);

    $stmt = $conn->prepare(
        "UPDATE employees SET factory = ?, name = ? WHERE employee_code = ?"
    );
    $stmt->bind_param("sss", $factory, $name, $employee_code);

    if ($stmt->execute()) {
        $msg = "Employee updated successfully";
    } else {
        $msg = "Error: " . $conn->error;
    }
}

/* Fetch Current Record */
$stmt = $conn->prepare(
    "SELECT factory, employee_code, name FROM employees WHERE employee_code = ? LIMIT 1"
);
$stmt->bind_param("s", $employee_code);
$stmt->execute();
$employee = $stmt->get_result()->fetch_assoc();

if (!$employee) {
    header("Location: employees.php");
    exit;
}
?>

<?php require "../includes/header.php"; ?>
<?php require "../includes/sidebar_admin.php"; ?>

<div class="content">

    <div class="container-fluid">

        <h3 class="mb-3">Edit Employee</h3>

        <?php if (!empty($msg)) : ?>
            <div class="alert alert-info">
                <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <div class="card mb-4">
            <div class="card-body">

                <form method="POST">

                    <input type="hidden"
                           name="employee_code"
                           value="<?= htmlspecialchars($employee['employee_code']); ?>">

                    <div class="row">

                        <div class="col-md-4 mb-3">
                            <label class="form-label">Employee Code</label>
                            <input type="text"
                                   class="form-control"
                                   value="<?= htmlspecialchars($employee['employee_code']); ?>"
                                   disabled>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label">Name</label>
                            <input type="text"
                                   name="name"
                                   class="form-control"
                                   value="<?= htmlspecialchars($employee['name']); ?>"
                                   required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label">Factory</label>
                            <input type="text"
                                   name="factory"
                                   class="form-control"
                                   value="<?= htmlspecialchars($employee['factory']); ?>"
                                   required>
                        </div>

                    </div>

                    <button type="submit"
                            name="update_employee"
                            class="btn btn-success">
                        Update Employee
                    </button>

                    <a href="employees.php" class="btn btn-secondary">
                        Cancel
                    </a>

                </form>

            </div>
        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

</body>
</html>