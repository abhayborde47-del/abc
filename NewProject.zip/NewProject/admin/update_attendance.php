<?php
require "../config.php";
require "../includes/auth_admin_ais.php";

header('Content-Type: application/json');

$employee_id = $_POST['employee_id'] ?? '';
$date        = $_POST['attendance_date'] ?? '';
$status      = $_POST['status'] ?? '';

$employee_id = (int) $employee_id;

if ($employee_id <= 0 || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
    echo json_encode(['success' => false, 'message' => 'Invalid employee or date.']);
    exit;
}

/* Don't allow marking future dates */
if ($date > date('Y-m-d')) {
    echo json_encode(['success' => false, 'message' => 'Cannot mark attendance for a future date.']);
    exit;
}

/* Confirm the employee actually exists */
$check = $conn->prepare("SELECT id FROM employees WHERE id = ?");
$check->bind_param("i", $employee_id);
$check->execute();
if ($check->get_result()->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'Employee not found.']);
    exit;
}

$allowedStatuses = ['Present', 'Half Day', 'Absent'];

if ($status === '') {
    /* Clear / un-mark this day */
    $stmt = $conn->prepare("DELETE FROM attendance WHERE employee_id = ? AND attendance_date = ?");
    $stmt->bind_param("is", $employee_id, $date);
    $ok = $stmt->execute();
    echo json_encode(['success' => (bool) $ok]);
    exit;
}

if (!in_array($status, $allowedStatuses, true)) {
    echo json_encode(['success' => false, 'message' => 'Invalid status.']);
    exit;
}

/* Requires a UNIQUE KEY on (employee_id, attendance_date) in the attendance table.
   If that unique key doesn't exist yet, run:
   ALTER TABLE attendance ADD UNIQUE KEY uniq_emp_date (employee_id, attendance_date); */
$stmt = $conn->prepare("
    INSERT INTO attendance (employee_id, attendance_date, status)
    VALUES (?, ?, ?)
    ON DUPLICATE KEY UPDATE status = VALUES(status)
");
$stmt->bind_param("iss", $employee_id, $date, $status);
$ok = $stmt->execute();

echo json_encode(['success' => (bool) $ok]);