<?php
require "../config.php";
require "../includes/auth_admin_ais.php";
require "../includes/day_plan_download_shared.php";
