<?php

require "../config.php";
require "../includes/auth_admin_ais.php";


/* =========================================================
   GET SELECTED MONTH
========================================================= */

$month = trim($_GET['month'] ?? '');


if ($month === '') {

    die("Please select a month.");

}


/* =========================================================
   VALIDATE MONTH FORMAT
   Example: 2026-08
========================================================= */

if (!preg_match('/^\d{4}-\d{2}$/', $month)) {

    die("Invalid month.");

}


$year  = substr($month, 0, 4);
$monthNo = substr($month, 5, 2);


/* =========================================================
   CREATE DATE RANGE
========================================================= */

$startDate = $month . "-01";

$endDate = date(
    "Y-m-t",
    strtotime($startDate)
);


/* =========================================================
   GET RECORDS
========================================================= */

$stmt = $conn->prepare(
    "SELECT
        cb_serial_no,
        hall,
        spare,
        so_no_new,
        region,
        customer,
        product,
        creepage,
        production_date,
        remark,
        added_by,
        added_at
     FROM added_products
     WHERE added_at >= ?
     AND added_at < DATE_ADD(?, INTERVAL 1 DAY)
     ORDER BY added_at ASC"
);


$stmt->bind_param(
    "ss",
    $startDate,
    $endDate
);


$stmt->execute();

$result = $stmt->get_result();


/* =========================================================
   MONTH NAME
========================================================= */

$monthName = date(
    "F_Y",
    strtotime($startDate)
);


/* =========================================================
   EXCEL FILE NAME
========================================================= */

$fileName = "Product_History_" . $monthName . ".xls";


/* =========================================================
   EXCEL HEADERS
========================================================= */

header(
    "Content-Type: application/vnd.ms-excel; charset=UTF-8"
);

header(
    "Content-Disposition: attachment; filename=\"$fileName\""
);

header(
    "Pragma: no-cache"
);

header(
    "Expires: 0"
);


/* =========================================================
   EXCEL TABLE
========================================================= */

echo "\xEF\xBB\xBF";

?>

<table border="1">

    <tr>

        <th>CB Serial No</th>
        <th>Hall</th>
        <th>Spare</th>
        <th>SO No New</th>
        <th>Region</th>
        <th>Customer</th>
        <th>Product</th>
        <th>Creepage</th>
        <th>Production Date</th>
        <th>Remark</th>
        <th>Added By</th>

    </tr>


    <?php while ($row = $result->fetch_assoc()): ?>

        <tr>

            <td>
                <?= htmlspecialchars(
                    $row['cb_serial_no'] ?? ''
                ) ?>
            </td>

            <td>
                <?= htmlspecialchars(
                    $row['hall'] ?? ''
                ) ?>
            </td>

            <td>
                <?= htmlspecialchars(
                    $row['spare'] ?? ''
                ) ?>
            </td>

            <td>
                <?= htmlspecialchars(
                    $row['so_no_new'] ?? ''
                ) ?>
            </td>

            <td>
                <?= htmlspecialchars(
                    $row['region'] ?? ''
                ) ?>
            </td>

            <td>
                <?= htmlspecialchars(
                    $row['customer'] ?? ''
                ) ?>
            </td>

            <td>
                <?= htmlspecialchars(
                    $row['product'] ?? ''
                ) ?>
            </td>

            <td>
                <?= htmlspecialchars(
                    $row['creepage'] ?? ''
                ) ?>
            </td>

            <td>
                <?= htmlspecialchars(
                    $row['production_date'] ?? ''
                ) ?>
            </td>

            <td>
                <?= htmlspecialchars(
                    $row['remark'] ?? ''
                ) ?>
            </td>

            <td>
                <?= htmlspecialchars(
                    $row['added_by'] ?? ''
                ) ?>
            </td>

        </tr>

    <?php endwhile; ?>

</table>
