<?php

require "../config.php";
require "../includes/auth_user.php";
require "../includes/security.php";


// Only SSControl user is allowed
if (
    strtolower(trim($_SESSION['user_department']))
    !== 'sscontrol'
) {

    header("Location: ../login.php");
    exit;
}

?>

<?php require "../includes/header.php"; ?>

<?php require "../includes/sidebar_sscontrol.php"; ?>


<div class="content">

    <div class="container-fluid">

        <div class="d-flex justify-content-between align-items-center mb-4">

            <div>

                <h2>
                    SSControl Dashboard
                </h2>

                <p class="text-muted mb-0">

                    Welcome,
                    <?= htmlspecialchars($_SESSION['user_email']) ?>

                </p>

            </div>

        </div>


        <div class="row">


            <!-- Dashboard Card -->

            <div class="col-md-4 mb-4">

                <div class="card shadow-sm">

                    <div class="card-body">

                        <h5 class="card-title">
                            SSControl
                        </h5>

                        <p class="card-text">
                            SSControl dashboard is active.
                        </p>

                    </div>

                </div>

            </div>


        </div>

    </div>

</div>


<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>

<script
    src="../assets/js/script.js">
</script>

</body>

</html>