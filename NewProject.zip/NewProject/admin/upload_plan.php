<?php
require "../config.php";
require "../includes/auth_admin_ais.php";
require "../lib/xlsx_reader.php";

$msg = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['plan_file'])) {

    $tmpPath = $_FILES['plan_file']['tmp_name'];
    $rows = readXLSX($tmpPath);

    if (count($rows) > 0) {

        // First row = header
        $header = array_map(function ($h) {
            return strtolower(trim($h));
        }, $rows[0]);

        // Map expected columns
        $map = [
            'spare'       => array_search('spare', $header),
            'so_no_new'   => array_search('so_no_new', $header),
            'region'      => array_search('region', $header),
            'customer'    => array_search('customer', $header),
            'product'     => array_search('product', $header),
            'creepage'    => array_search('creepage', $header),
            'cb_serial_no'=> array_search('cb_serial_no', $header),
        ];

        $inserted = 0;
        $skipped = 0;

        // Used only for checking non-NA serial numbers
        $stmtCheck = $conn->prepare(
            "SELECT cb_serial_no FROM plans WHERE cb_serial_no = ? LIMIT 1"
        );

        $stmtInsert = $conn->prepare(
            "INSERT INTO plans 
            (cb_serial_no, spare, so_no_new, region, customer, product, creepage) 
            VALUES (?, ?, ?, ?, ?, ?, ?)"
        );

        for ($i = 1; $i < count($rows); $i++) {

            $row = $rows[$i];

            $cb = $map['cb_serial_no'] !== false
                ? trim($row[$map['cb_serial_no']] ?? '')
                : '';

            // Skip completely blank CB serial numbers
            if ($cb === '') {
                continue;
            }

            /*
             * IMPORTANT:
             *
             * If CB serial number is NA:
             *     Allow unlimited NA records.
             *
             * If CB serial number is anything else:
             *     Check database and skip duplicate.
             */
            if (strtoupper($cb) !== 'NA') {

                $stmtCheck->bind_param("s", $cb);
                $stmtCheck->execute();

                $exists = $stmtCheck->get_result()->fetch_assoc();

                if ($exists) {
                    $skipped++;
                    continue;
                }
            }

            // Get remaining Excel values
            $spare = $map['spare'] !== false
                ? ($row[$map['spare']] ?? '')
                : '';

            $so = $map['so_no_new'] !== false
                ? ($row[$map['so_no_new']] ?? '')
                : '';

            $region = $map['region'] !== false
                ? ($row[$map['region']] ?? '')
                : '';

            $customer = $map['customer'] !== false
                ? ($row[$map['customer']] ?? '')
                : '';

            $product = $map['product'] !== false
                ? ($row[$map['product']] ?? '')
                : '';

            $creepage = $map['creepage'] !== false
                ? ($row[$map['creepage']] ?? '')
                : '';

            // Insert record
            $stmtInsert->bind_param(
                "sssssss",
                $cb,
                $spare,
                $so,
                $region,
                $customer,
                $product,
                $creepage
            );

            if ($stmtInsert->execute()) {
                $inserted++;
            }
        }

        $msg = "Upload complete. New records added: $inserted, Skipped (already exist): $skipped";

    } else {
        $msg = "Could not read excel file / file empty.";
    }
}
?>

<?php require "../includes/header.php"; ?>
<?php require "../includes/sidebar_admin.php"; ?>

    <div class="content p-4">

        <h4>Upload Plan (Excel)</h4>

        <?php if ($msg): ?>
            <div class="alert alert-info">
                <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data" class="row g-2">

            <div class="col-md-6">
                <input
                    type="file"
                    name="plan_file"
                    accept=".xlsx"
                    class="form-control"
                    required
                >
            </div>

            <div class="col-md-2">
                <button class="btn btn-success w-100">
                    Upload
                </button>
            </div>

        </form>

    </div>
</div><!-- closes the .d-flex div opened in header.php -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

</body>
</html>