<?php
require "../config.php";
require "../includes/auth_admin_ais.php";
require "../includes/security.php";

$msg = "";
$msgType = "info";
$searchResult = null;


/* =========================================================
   UPDATE SUCCESS MESSAGE
========================================================= */

if (isset($_GET['updated']) && $_GET['updated'] == '1') {

    $msg = "Product updated successfully.";
    $msgType = "success";
}


/* =========================================================
   SEARCH PLAN BY CB SERIAL NUMBER
========================================================= */

if (isset($_GET['search'])) {

    $cb               = trim($_GET['cb_serial_no'] ?? '');
    $hall             = trim($_GET['hall'] ?? '');
    $production_date  = trim($_GET['production_date'] ?? '');

    if ($cb === '') {

        $msg = "Please enter CB Serial No.";
        $msgType = "warning";

    } elseif (!in_array($hall, ['CB1', 'CB2'], true)) {

        $msg = "Please select a valid Hall.";
        $msgType = "warning";

    } elseif ($production_date === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/', $production_date)) {

        $msg = "Please select a valid Production Date.";
        $msgType = "warning";

    } else {

        /* Find plan */

        $stmt = $conn->prepare(
            "SELECT *
             FROM plans
             WHERE cb_serial_no = ?
             LIMIT 1"
        );

        $stmt->bind_param("s", $cb);
        $stmt->execute();

        $searchResult = $stmt->get_result()->fetch_assoc();


        if (!$searchResult) {

            $msg =
                "No plan found for CB Serial No: " .
                htmlspecialchars($cb);

            $msgType = "warning";

        } else {


            /* -----------------------------------------------
               CHECK DUPLICATE
            ------------------------------------------------ */

            $check = $conn->prepare(
                "SELECT id
                 FROM added_products
                 WHERE cb_serial_no = ?
                 LIMIT 1"
            );

            $check->bind_param("s", $cb);
            $check->execute();

            $alreadyAdded =
                $check->get_result()->fetch_assoc();


            if ($alreadyAdded) {

                $msg =
                    "CB Serial No " .
                    htmlspecialchars($cb) .
                    " is already added. Duplicate entry is not allowed.";

                $msgType = "danger";

                $searchResult = null;
            }
        }
    }
}


/* =========================================================
   ADD PRODUCT
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST' &&
    (isset($_POST['add']) || isset($_POST['add_extra']))) {

    csrf_verify($_POST['csrf_token'] ?? '');

    $cb               = trim($_POST['cb_serial_no'] ?? '');
    $hall             = trim($_POST['hall'] ?? '');
    $spare            = trim($_POST['spare'] ?? '');
    $so_no            = trim($_POST['so_no_new'] ?? '');
    $region           = trim($_POST['region'] ?? '');
    $customer         = trim($_POST['customer'] ?? '');
    $product          = trim($_POST['product'] ?? '');
    $creepage         = trim($_POST['creepage'] ?? '');
    $remark           = trim($_POST['remark'] ?? '');
    $production_date  = trim($_POST['production_date'] ?? '');
    $status           = trim($_POST['status'] ?? 'Pending');
    $entry_type       = isset($_POST['add_extra']) ? 'Extra' : 'Plan';

    if (!in_array($status, ['Pending', 'In Progress', 'Completed'], true)) {
        $status = 'Pending';
    }

    $added_by =
        $_SESSION['user_email'] ?? '';


    /* -----------------------------------------------------
       VALIDATE PRODUCTION DATE
    ----------------------------------------------------- */

    if ($production_date === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/', $production_date)) {

        $msg = "Please select a valid Production Date.";
        $msgType = "danger";

    } else {


        /* -------------------------------------------------
           CHECK DUPLICATE AGAIN BEFORE INSERT
        ------------------------------------------------- */

        $check = $conn->prepare(
            "SELECT id
             FROM added_products
             WHERE cb_serial_no = ?
             LIMIT 1"
        );

        $check->bind_param("s", $cb);
        $check->execute();

        $duplicate =
            $check->get_result()->fetch_assoc();


        if ($duplicate) {

            $msg =
                "CB Serial No " .
                htmlspecialchars($cb) .
                " already exists. Duplicate entry is not allowed.";

            $msgType = "danger";

        } else {


            /* ---------------------------------------------
               INSERT
            --------------------------------------------- */

            $stmt = $conn->prepare(
                "INSERT INTO added_products
                (
                    cb_serial_no,
                    hall,
                    spare,
                    so_no_new,
                    region,
                    customer,
                    product,
                    creepage,
                    production_date,
                    remark,
                    added_by,
                    status,
                    entry_type
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );


            $stmt->bind_param(
                "sssssssssssss",
                $cb,
                $hall,
                $spare,
                $so_no,
                $region,
                $customer,
                $product,
                $creepage,
                $production_date,
                $remark,
                $added_by,
                $status,
                $entry_type
            );


            if ($stmt->execute()) {

                $msg =
                    "Product added successfully.";

                $msgType = "success";

                $searchResult = null;

            } else {


                if ($conn->errno == 1062) {

                    $msg =
                        "CB Serial No " .
                        htmlspecialchars($cb) .
                        " already exists. Duplicate entry is not allowed.";

                } else {

                    $msg =
                        "Error while adding product: " .
                        htmlspecialchars($conn->error);
                }

                $msgType = "danger";
            }
        }
    }
}


/* =========================================================
   DELETE PRODUCT
========================================================= */

if (isset($_GET['delete'])) {

    csrf_verify($_GET['csrf_token'] ?? '');

    $id = (int)$_GET['delete'];


    if ($id > 0) {

        $stmt = $conn->prepare(
            "DELETE FROM added_products
             WHERE id = ?"
        );

        $stmt->bind_param("i", $id);
        $stmt->execute();
    }


    header("Location: add_product.php");
    exit;
}


/* =========================================================
   GET RECENT 20 PRODUCTS
========================================================= */

$recent = $conn->query(
    "SELECT *
     FROM added_products
     ORDER BY added_at DESC
     LIMIT 20"
);

?>


<?php require "../includes/header.php"; ?>

<?php require "../includes/sidebar_admin.php"; ?>


<div class="content">


    <!-- =====================================================
         PAGE TITLE
    ====================================================== -->

    <h4 class="mb-3">
        Add Product
    </h4>


    <!-- =====================================================
         MESSAGE
    ====================================================== -->

    <?php if ($msg): ?>

        <div class="alert alert-<?= $msgType ?> alert-dismissible fade show">

            <?= $msg ?>

            <button
                type="button"
                class="btn-close"
                data-bs-dismiss="alert">
            </button>

        </div>

    <?php endif; ?>


    <!-- =====================================================
         SEARCH PLAN
    ====================================================== -->

    <div class="card mb-3">

        <div class="card-body">

            <h6 class="mb-3">
                Search Plan
            </h6>


            <form method="GET" class="row g-2">


                <!-- CB SERIAL -->

                <div class="col-md-4 position-relative">

                    <label class="form-label">
                        CB Serial No
                    </label>

                    <input
                        type="text"
                        id="cb_serial_no"
                        name="cb_serial_no"
                        class="form-control"
                        placeholder="Enter CB Serial No"
                        required
                        autocomplete="off"
                        value="<?= isset($_GET['cb_serial_no'])
                            ? htmlspecialchars($_GET['cb_serial_no'])
                            : '' ?>"
                    >

                    <div
                        id="cb_suggestions"
                        class="list-group position-absolute w-100 shadow-sm"
                        style="z-index:1050; max-height:200px; overflow-y:auto;">
                    </div>

                </div>


                <!-- HALL -->

                <div class="col-md-3">

                    <label class="form-label">
                        Hall
                    </label>

                    <select
                        name="hall"
                        class="form-select"
                        required>

                        <option value="">
                            Select Hall
                        </option>


                        <option
                            value="CB1"
                            <?= (isset($_GET['hall']) &&
                                $_GET['hall'] == 'CB1')
                                ? 'selected'
                                : '' ?>>

                            CB1

                        </option>


                        <option
                            value="CB2"
                            <?= (isset($_GET['hall']) &&
                                $_GET['hall'] == 'CB2')
                                ? 'selected'
                                : '' ?>>

                            CB2

                        </option>

                    </select>

                </div>


                <!-- PRODUCTION DATE (NEW) -->

                <div class="col-md-3">

                    <label class="form-label">
                        Production Date
                    </label>

                    <input
                        type="date"
                        name="production_date"
                        class="form-control"
                        required
                        value="<?= isset($_GET['production_date'])
                            ? htmlspecialchars($_GET['production_date'])
                            : '' ?>"
                    >

                </div>


                <!-- SEARCH BUTTON -->

                <div class="col-md-2 d-flex align-items-end">

                    <button
                        type="submit"
                        name="search"
                        value="1"
                        class="btn btn-primary w-100">

                        Search

                    </button>

                </div>

            </form>

        </div>

    </div>


    <!-- =====================================================
         PLAN FOUND
    ====================================================== -->

    <?php if ($searchResult): ?>

        <div class="card mb-4">


            <div class="card-header">

                <strong>
                    Plan Information
                </strong>


                <span class="badge bg-success float-end">
                    Ready to Add
                </span>

            </div>


            <div class="card-body">


                <form method="POST">

                    <?php csrf_field(); ?>

                    <!-- HIDDEN CB -->

                    <input
                        type="hidden"
                        name="cb_serial_no"
                        value="<?= htmlspecialchars(
                            $searchResult['cb_serial_no']
                        ) ?>"
                    >


                    <!-- HIDDEN HALL -->

                    <input
                        type="hidden"
                        name="hall"
                        value="<?= htmlspecialchars(
                            $_GET['hall'] ?? ''
                        ) ?>"
                    >


                    <div class="row g-3">


                        <!-- CB SERIAL -->

                        <div class="col-md-3">

                            <label class="form-label">
                                CB Serial No
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                value="<?= htmlspecialchars(
                                    $searchResult['cb_serial_no']
                                ) ?>"
                                readonly
                            >

                        </div>


                        <!-- HALL -->

                        <div class="col-md-3">

                            <label class="form-label">
                                Hall
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                value="<?= htmlspecialchars(
                                    $_GET['hall'] ?? ''
                                ) ?>"
                                readonly
                            >

                        </div>


                        <!-- SPARE -->

                        <div class="col-md-3">

                            <label class="form-label">
                                Spare
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                value="<?= htmlspecialchars(
                                    $searchResult['spare'] ?? ''
                                ) ?>"
                                readonly
                            >

                            <input
                                type="hidden"
                                name="spare"
                                value="<?= htmlspecialchars(
                                    $searchResult['spare'] ?? ''
                                ) ?>"
                            >

                        </div>


                        <!-- SO NO NEW -->

                        <div class="col-md-3">

                            <label class="form-label">
                                SO No New
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                value="<?= htmlspecialchars(
                                    $searchResult['so_no_new'] ?? ''
                                ) ?>"
                                readonly
                            >

                            <input
                                type="hidden"
                                name="so_no_new"
                                value="<?= htmlspecialchars(
                                    $searchResult['so_no_new'] ?? ''
                                ) ?>"
                            >

                        </div>


                        <!-- REGION -->

                        <div class="col-md-3">

                            <label class="form-label">
                                Region
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                value="<?= htmlspecialchars(
                                    $searchResult['region'] ?? ''
                                ) ?>"
                                readonly
                            >

                            <input
                                type="hidden"
                                name="region"
                                value="<?= htmlspecialchars(
                                    $searchResult['region'] ?? ''
                                ) ?>"
                            >

                        </div>


                        <!-- CUSTOMER -->

                        <div class="col-md-3">

                            <label class="form-label">
                                Customer
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                value="<?= htmlspecialchars(
                                    $searchResult['customer'] ?? ''
                                ) ?>"
                                readonly
                            >

                            <input
                                type="hidden"
                                name="customer"
                                value="<?= htmlspecialchars(
                                    $searchResult['customer'] ?? ''
                                ) ?>"
                            >

                        </div>


                        <!-- PRODUCT -->

                        <div class="col-md-3">

                            <label class="form-label">
                                Product
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                value="<?= htmlspecialchars(
                                    $searchResult['product'] ?? ''
                                ) ?>"
                                readonly
                            >

                            <input
                                type="hidden"
                                name="product"
                                value="<?= htmlspecialchars(
                                    $searchResult['product'] ?? ''
                                ) ?>"
                            >

                        </div>


                        <!-- CREEPAGE -->

                        <div class="col-md-3">

                            <label class="form-label">
                                Creepage
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                value="<?= htmlspecialchars(
                                    $searchResult['creepage'] ?? ''
                                ) ?>"
                                readonly
                            >

                            <input
                                type="hidden"
                                name="creepage"
                                value="<?= htmlspecialchars(
                                    $searchResult['creepage'] ?? ''
                                ) ?>"
                            >

                        </div>


                        <!-- PRODUCTION DATE (NEW) -->

                        <div class="col-md-3">

                            <label class="form-label">
                                Production Date
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                value="<?= htmlspecialchars(
                                    $_GET['production_date'] ?? ''
                                ) ?>"
                                readonly
                            >

                            <input
                                type="hidden"
                                name="production_date"
                                value="<?= htmlspecialchars(
                                    $_GET['production_date'] ?? ''
                                ) ?>"
                            >

                        </div>


                        <!-- STATUS -->

                        <div class="col-md-4">

                            <label class="form-label">
                                Status
                            </label>

                            <select
                                name="status"
                                class="form-select">

                                <option value="Pending">Not Done</option>
                                <option value="In Progress">In Process</option>
                                <option value="Completed">Completed</option>

                            </select>

                        </div>


                        <!-- REMARK -->

                        <div class="col-md-8">

                            <label class="form-label">
                                Remark
                            </label>

                            <textarea
                                name="remark"
                                class="form-control"
                                rows="2"
                                placeholder="Enter remark..."
                            ></textarea>

                        </div>


                        <!-- ADD -->

                        <div class="col-md-2 d-flex align-items-end">

                            <button
                                type="submit"
                                name="add"
                                class="btn btn-success w-100">

                                Add Product

                            </button>

                        </div>


                    </div>

                </form>

            </div>

        </div>

    <?php endif; ?>


    <!-- =====================================================
         EXTRA ENTRY (no matching plan required)
    ====================================================== -->

    <div class="card mb-4">

        <div class="card-header d-flex justify-content-between align-items-center" role="button" data-bs-toggle="collapse" data-bs-target="#extraEntryForm">

            <strong>Extra Entry <span class="badge bg-warning text-dark">Not linked to a plan</span></strong>

            <span class="text-muted small">Click to expand / collapse</span>

        </div>

        <div class="collapse" id="extraEntryForm">

            <div class="card-body">

                <form method="POST">

                    <?php csrf_field(); ?>

                    <div class="row g-3">

                        <div class="col-md-3">
                            <label class="form-label">CB Serial No</label>
                            <input type="text" name="cb_serial_no" class="form-control" placeholder="Enter CB Serial No" required>
                        </div>

                        <div class="col-md-2">
                            <label class="form-label">Hall</label>
                            <select name="hall" class="form-select" required>
                                <option value="">Select Hall</option>
                                <option value="CB1">CB1</option>
                                <option value="CB2">CB2</option>
                            </select>
                        </div>

                        <div class="col-md-2">
                            <label class="form-label">Production Date</label>
                            <input type="date" name="production_date" class="form-control" required>
                        </div>

                        <div class="col-md-2">
                            <label class="form-label">Status</label>
                            <select name="status" class="form-select">
                                <option value="Pending">Not Done</option>
                                <option value="In Progress">In Process</option>
                                <option value="Completed">Completed</option>
                            </select>
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">Spare</label>
                            <input type="text" name="spare" class="form-control">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">SO No New</label>
                            <input type="text" name="so_no_new" class="form-control">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">Region</label>
                            <input type="text" name="region" class="form-control">
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">Customer</label>
                            <input type="text" name="customer" class="form-control">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Product</label>
                            <input type="text" name="product" class="form-control">
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">Creepage</label>
                            <input type="text" name="creepage" class="form-control">
                        </div>

                        <div class="col-md-8">
                            <label class="form-label">Remark</label>
                            <textarea name="remark" class="form-control" rows="2" placeholder="Enter remark..."></textarea>
                        </div>

                        <div class="col-md-4 d-flex align-items-end">
                            <button type="submit" name="add_extra" class="btn btn-warning w-100">
                                Add Extra Entry
                            </button>
                        </div>

                    </div>

                </form>

            </div>

        </div>

    </div>


    <!-- =====================================================
         RECENT PRODUCTS
    ====================================================== -->

    <div class="d-flex justify-content-between align-items-center mb-2">

        <h5 class="mb-0">
            Recent Added Products
        </h5>


        <small class="text-muted">
            Showing latest 20
        </small>

    </div>


    <div
        class="table-responsive"
        style="
            max-height:500px;
            overflow:auto;
            font-size:12px;
        "
    >


        <table
            class="table table-bordered table-sm table-hover align-middle">


            <thead
                class="table-dark"
                style="
                    position:sticky;
                    top:0;
                    z-index:1;
                "
            >

                <tr>

                    <th>CB Serial No</th>
                    <th>Hall</th>
                    <th>Spare</th>
                    <th>SO No New</th>
                    <th>Region</th>
                    <th>Customer</th>
                    <th>Product</th>
                    <th>Creepage</th>
                    <th>Production Date</th>
                    <th>Status</th>
                    <th>Type</th>
                    <th>Remark</th>
                    <th>Added By</th>
                    <th>Action</th>

                </tr>

            </thead>


            <tbody>


            <?php if ($recent && $recent->num_rows > 0): ?>


                <?php while ($r = $recent->fetch_assoc()): ?>


                    <tr>


                        <!-- CB -->

                        <td>

                            <strong>
                                <?= htmlspecialchars(
                                    $r['cb_serial_no']
                                ) ?>
                            </strong>

                        </td>


                        <!-- HALL -->

                        <td>
                            <?= htmlspecialchars(
                                $r['hall']
                            ) ?>
                        </td>


                        <!-- SPARE -->

                        <td>
                            <?= htmlspecialchars(
                                $r['spare']
                            ) ?>
                        </td>


                        <!-- SO -->

                        <td>
                            <?= htmlspecialchars(
                                $r['so_no_new']
                            ) ?>
                        </td>


                        <!-- REGION -->

                        <td>
                            <?= htmlspecialchars(
                                $r['region']
                            ) ?>
                        </td>


                        <!-- CUSTOMER -->

                        <td>
                            <?= htmlspecialchars(
                                $r['customer']
                            ) ?>
                        </td>


                        <!-- PRODUCT -->

                        <td>
                            <?= htmlspecialchars(
                                $r['product']
                            ) ?>
                        </td>


                        <!-- CREEPAGE -->

                        <td>
                            <?= htmlspecialchars(
                                $r['creepage']
                            ) ?>
                        </td>


                        <!-- PRODUCTION DATE (NEW) -->

                        <td>
                            <?= htmlspecialchars(
                                $r['production_date'] ?? ''
                            ) ?>
                        </td>


                        <!-- STATUS -->

                        <td>
                            <?php
                                $st = $r['status'] ?? 'Pending';
                                $stLabel = ['Pending' => 'Not Done', 'In Progress' => 'In Process', 'Completed' => 'Completed'][$st] ?? $st;
                                $stClass = ['Pending' => 'secondary', 'In Progress' => 'warning', 'Completed' => 'success'][$st] ?? 'secondary';
                            ?>
                            <span class="badge bg-<?= $stClass ?>"><?= htmlspecialchars($stLabel) ?></span>
                        </td>


                        <!-- TYPE -->

                        <td>
                            <?php if (($r['entry_type'] ?? 'Plan') === 'Extra'): ?>
                                <span class="badge bg-dark">Extra</span>
                            <?php else: ?>
                                <span class="badge bg-primary">Plan</span>
                            <?php endif; ?>
                        </td>


                        <!-- REMARK -->

                        <td>
                            <?= htmlspecialchars(
                                $r['remark'] ?? ''
                            ) ?>
                        </td>


                        <!-- ADDED BY -->

                        <td>
                            <?= htmlspecialchars(
                                $r['added_by']
                            ) ?>
                        </td>


                        <!-- ACTION -->

                        <td class="text-nowrap">


                            <!-- =================================
                                 UPDATE

                                 SAME PAGE / SAME TAB
                            ================================== -->

                            <a
                                href="edit_product.php?id=<?= (int)$r['id'] ?>"
                                class="btn btn-sm btn-primary">

                                Update

                            </a>


                            <!-- DELETE -->

                            <a
                                href="?delete=<?= (int)$r['id'] ?>&csrf_token=<?= urlencode(csrf_token()) ?>"
                                class="btn btn-sm btn-danger"
                                onclick="return confirm('Delete this product?')">

                                Delete

                            </a>


                        </td>


                    </tr>


                <?php endwhile; ?>


            <?php else: ?>


                <tr>

                    <td
                        colspan="14"
                        class="text-center text-muted py-3">

                        No products added yet.

                    </td>

                </tr>


            <?php endif; ?>


            </tbody>

        </table>

    </div>


</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="../assets/js/script.js"></script>


<!-- =====================================================
     CB SERIAL NO AUTOCOMPLETE
====================================================== -->

<script>
(function () {
    const input = document.getElementById('cb_serial_no');
    const box   = document.getElementById('cb_suggestions');
    let debounceTimer;

    if (!input || !box) return;

    input.addEventListener('input', function () {
        clearTimeout(debounceTimer);
        const term = this.value.trim();

        if (term.length < 2) {
            box.innerHTML = '';
            return;
        }

        debounceTimer = setTimeout(() => {
            fetch('ajax_suggest_cb.php?term=' + encodeURIComponent(term))
                .then(res => {
                    if (!res.ok) {
                        throw new Error('HTTP ' + res.status);
                    }
                    return res.text();
                })
                .then(text => {
                    let data;

                    try {
                        data = JSON.parse(text);
                    } catch (err) {
                        console.error('CB suggest: invalid JSON response ->', text);
                        box.innerHTML = '';
                        return;
                    }

                    box.innerHTML = '';

                    if (!Array.isArray(data) || data.length === 0) {
                        return;
                    }

                    data.forEach(cb => {
                        const item = document.createElement('a');
                        item.href = '#';
                        item.className = 'list-group-item list-group-item-action';
                        item.textContent = cb;

                        item.addEventListener('click', function (e) {
                            e.preventDefault();
                            input.value = cb;
                            box.innerHTML = '';
                        });

                        box.appendChild(item);
                    });
                })
                .catch(err => {
                    console.error('CB suggest: fetch failed ->', err);
                    box.innerHTML = '';
                });
        }, 250);
    });

    document.addEventListener('click', function (e) {
        if (e.target !== input && !box.contains(e.target)) {
            box.innerHTML = '';
        }
    });
})();
</script>


</body>
</html>