<?php
require "../config.php";
require "../includes/auth_admin_ais.php";

$msg = "";

/* Show flash message after redirect (e.g. from delete_employee.php) */
if (isset($_SESSION['flash_msg'])) {
    $msg = $_SESSION['flash_msg'];
    unset($_SESSION['flash_msg']);
}

/* Pagination setup */
$perPage = 15;
$page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
if ($page < 1) {
    $page = 1;
}
$offset = ($page - 1) * $perPage;

/* Get total record count */
$totalResult = $conn->query("SELECT COUNT(*) AS total FROM employees");
$totalRow = $totalResult->fetch_assoc();
$totalRecords = (int) $totalRow['total'];
$totalPages = (int) ceil($totalRecords / $perPage);

/* Get current page's employees */
$stmt = $conn->prepare("
    SELECT id, factory, employee_code, name
    FROM employees
    ORDER BY id ASC
    LIMIT ? OFFSET ?
");
$stmt->bind_param("ii", $perPage, $offset);
$stmt->execute();
$employees = $stmt->get_result();
?>

<?php require "../includes/header.php"; ?>
<?php require "../includes/sidebar_admin.php"; ?>

<div class="content">

    <div class="container-fluid">

        <h3 class="mb-3">Employee Records</h3>

        <?php if (!empty($msg)) : ?>
            <div class="alert alert-info">
                <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    All Employees
                    <span class="text-muted fw-normal">
                        (<?= $totalRecords; ?> total)
                    </span>
                </h5>
            </div>

            <div class="card-body">

                <div class="table-responsive">

                    <table class="table table-bordered table-hover">

                        <thead>
                            <tr>
                                <th>Employee Code</th>
                                <th>Name</th>
                                <th>Factory</th>
                                <th width="180">Action</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php if ($employees && $employees->num_rows > 0) : ?>

                            <?php while ($e = $employees->fetch_assoc()) : ?>

                                <tr>

                                    <td><?= htmlspecialchars($e['employee_code']); ?></td>

                                    <td><?= htmlspecialchars($e['name']); ?></td>

                                    <td><?= htmlspecialchars($e['factory']); ?></td>

                                    <td>

                                        <a href="edit_employee.php?id=<?= (int) $e['id']; ?>"
                                           class="btn btn-warning btn-sm">
                                            Edit
                                        </a>

                                        <a href="delete_employee.php?id=<?= (int) $e['id']; ?>"
                                           class="btn btn-danger btn-sm"
                                           onclick="return confirm('Are you sure you want to delete this employee?');">
                                            Delete
                                        </a>

                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        <?php else : ?>

                            <tr>
                                <td colspan="4" class="text-center">
                                    No Employees Found
                                </td>
                            </tr>

                        <?php endif; ?>

                        </tbody>

                    </table>

                </div>

                <?php if ($totalPages > 1) : ?>

                    <nav aria-label="Employee pagination">
                        <ul class="pagination justify-content-center mb-0">

                            <li class="page-item <?= $page <= 1 ? 'disabled' : ''; ?>">
                                <a class="page-link"
                                   href="?page=<?= max(1, $page - 1); ?>">
                                    Previous
                                </a>
                            </li>

                            <li class="page-item disabled">
                                <span class="page-link">
                                    Page <?= $page; ?> of <?= $totalPages; ?>
                                </span>
                            </li>

                            <li class="page-item <?= $page >= $totalPages ? 'disabled' : ''; ?>">
                                <a class="page-link"
                                   href="?page=<?= min($totalPages, $page + 1); ?>">
                                    Next
                                </a>
                            </li>

                        </ul>
                    </nav>

                <?php endif; ?>

            </div>
        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

</body>
</html>