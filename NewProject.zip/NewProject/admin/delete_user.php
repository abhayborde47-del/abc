<?php
require "../config.php";
require "../includes/auth_admin_ais.php";
require "../includes/security.php";

csrf_verify($_GET['csrf_token'] ?? '');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $conn->prepare("DELETE FROM users WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();

header("Location: add_user.php");
exit;
?>