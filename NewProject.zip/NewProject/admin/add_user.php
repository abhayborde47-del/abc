<?php
require "../config.php";
require "../includes/auth_admin_ais.php";
require "../includes/security.php";
require "../includes/crypto.php";

$msg = "";

/* Add User */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {

    csrf_verify($_POST['csrf_token'] ?? '');

    $email = trim($_POST['email'] ?? '');
    $raw_password = $_POST['password'] ?? '';
    $department = trim($_POST['department'] ?? '');

    // Allow only these departments
    // 'adi' added here: ADI is now a user department that the AIS Admin
    // manages directly (ADI is no longer a separate admin role).
    $allowed_departments = ['AIS', 'SSControl', 'adi'];

    if (!in_array($department, $allowed_departments, true)) {

        $msg = "Invalid department selected.";

    } elseif (empty($email) || empty($raw_password)) {

        $msg = "Email and password are required.";

    } else {

        $password     = password_hash($raw_password, PASSWORD_BCRYPT);
        $password_enc = pw_encrypt($raw_password);

        $stmt = $conn->prepare("
            INSERT INTO users (email, password, password_enc, department)
            VALUES (?, ?, ?, ?)
        ");

        $stmt->bind_param("ssss", $email, $password, $password_enc, $department);

        if ($stmt->execute()) {
            $msg = "User added successfully.";
        } else {
            $msg = "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}

/* Get Users - AIS, SSControl and ADI (adi) */
$users = $conn->query("
    SELECT id, email, department, created_at
    FROM users
    WHERE department IN ('AIS', 'SSControl', 'adi')
    ORDER BY id DESC
");
?>

<?php require "../includes/header.php"; ?>
<?php require "../includes/sidebar_admin.php"; ?>

<div class="content">

    <div class="container-fluid">

        <h3 class="mb-3">Add User</h3>

        <?php if (!empty($msg)) : ?>
            <div class="alert alert-info">
                <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <!-- Add User Form -->
        <div class="card mb-4">
            <div class="card-body">

                <form method="POST">

                    <?php csrf_field(); ?>

                    <div class="row">

                        <div class="col-md-4 mb-3">
                            <label class="form-label">Email</label>

                            <input type="email"
                                   name="email"
                                   class="form-control"
                                   placeholder="Enter Email"
                                   required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label">Password</label>

                            <input type="password"
                                   name="password"
                                   class="form-control"
                                   placeholder="Enter Password"
                                   required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label">Department</label>

                            <select name="department"
                                    class="form-select"
                                    required>

                                

                                <option value="AIS">
                                    AIS
                                </option>

                                <option value="SSControl">
                                    SSControl
                                </option>

                                <option value="adi">
                                    ADI User
                                </option>

                            </select>
                        </div>

                    </div>

                    <button type="submit"
                            name="add_user"
                            class="btn btn-success">
                        Add User
                    </button>

                </form>

            </div>
        </div>


        <!-- User List -->
        <div class="card">

            <div class="card-header">
                <h5 class="mb-0">
                    AIS, SSControl & ADI Users
                </h5>
            </div>

            <div class="card-body">

                <div class="table-responsive">

                    <table class="table table-bordered table-hover">

                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Email</th>
                                <th>Password</th>
                                <th>Department</th>
                                <th>Created At</th>
                                <th width="180">Action</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php if ($users && $users->num_rows > 0) : ?>

                            <?php while ($u = $users->fetch_assoc()) : ?>

                                <tr>

                                    <td>
                                        <?= htmlspecialchars($u['id']); ?>
                                    </td>

                                    <td>
                                        <?= htmlspecialchars($u['email']); ?>
                                    </td>

                                    <td>
                                        <span class="js-password-cell text-muted">••••••••</span>
                                        <button type="button"
                                                class="btn btn-outline-secondary btn-sm ms-1 js-view-password"
                                                data-type="user"
                                                data-id="<?= (int)$u['id']; ?>">
                                            View
                                        </button>
                                    </td>

                                    <td>
                                        <?php
                                            $deptLabels = ['AIS' => 'AIS', 'SSControl' => 'SSControl', 'adi' => 'ADI User'];
                                            echo htmlspecialchars($deptLabels[$u['department']] ?? $u['department']);
                                        ?>
                                    </td>

                                    <td>
                                        <?= htmlspecialchars($u['created_at']); ?>
                                    </td>

                                    <td>

                                        <a href="edit_user.php?id=<?= $u['id']; ?>"
                                           class="btn btn-warning btn-sm">
                                            Edit
                                        </a>

                                        <a href="delete_user.php?id=<?= $u['id']; ?>&csrf_token=<?= urlencode(csrf_token()); ?>"
                                           class="btn btn-danger btn-sm"
                                           onclick="return confirm('Are you sure you want to delete this user?');">
                                            Delete
                                        </a>

                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        <?php else : ?>

                            <tr>
                                <td colspan="6" class="text-center">
                                    No Users Found
                                </td>
                            </tr>

                        <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>

</div>

<?php require "../includes/reveal_password_modal.php"; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
<script>
    window.CSRF_TOKEN = <?= json_encode(csrf_token()) ?>;
    window.REVEAL_PASSWORD_URL = "../includes/reveal_password.php";
</script>
<script src="../assets/js/reveal_password.js"></script>

</body>
</html>