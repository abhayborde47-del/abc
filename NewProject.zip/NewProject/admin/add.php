<?php

require "../config.php";
require "../includes/auth_user.php";
require "../includes/security.php";


/*
|--------------------------------------------------------------------------
| ONLY SSCONTROL USERS
|--------------------------------------------------------------------------
*/

if (
    strtolower(trim($_SESSION['user_department']))
    !== 'sscontrol'
) {
    header("Location: ../login.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| GET SO NUMBERS FROM PLANS
|--------------------------------------------------------------------------
*/

$sql = "
    SELECT DISTINCT so_no_new
    FROM plans
    WHERE so_no_new IS NOT NULL
    AND TRIM(so_no_new) <> ''
    ORDER BY so_no_new ASC
";

$result = $conn->query($sql);

if (!$result) {
    die("Database error: " . $conn->error);
}

$so_numbers = [];

while ($row = $result->fetch_assoc()) {

    $so_numbers[] = $row['so_no_new'];

}

?>

<?php require "../includes/header.php"; ?>

<?php require "../includes/sidebar_admin.php"; ?>


<div class="content">

    <div class="container-fluid">


        <!-- HEADER -->

        <div class="d-flex justify-content-between align-items-center mb-4">

            <div>

                <h2>
                    Add SSControl Entry
                </h2>

                <p class="text-muted mb-0">
                    Enter SSControl inspection details.
                </p>

            </div>

        </div>


        <!-- SUCCESS -->

        <?php if (isset($_GET['success'])): ?>

            <div class="alert alert-success">
                Entry saved successfully.
            </div>

        <?php endif; ?>


        <!-- FORM CARD -->

        <div class="card shadow-sm">

            <div class="card-body">


                <form
                    action="save.php"
                    method="POST"
                    id="sscontrolForm"
                >


                    <!-- ENTRY TYPE -->

                    <div class="mb-4">

                        <label
                            class="form-label fw-semibold"
                        >
                            Entry Type
                        </label>


                        <select
                            name="entry_type"
                            id="entry_type"
                            class="form-select"
                            required
                        >

                            <option value="">
                                Select Entry Type
                            </option>

                            <option value="plan">
                                Select SO No. from Plan
                            </option>

                            <option value="manual">
                                Manual Entry
                            </option>

                        </select>

                    </div>


                    <!-- PLAN SO NUMBER -->

                    <div
                        class="mb-4"
                        id="plan_so_section"
                        style="display:none;"
                    >

                        <label
                            for="so_no_plan"
                            class="form-label fw-semibold"
                        >
                            SO No.
                        </label>


                        <select
                            name="so_no_plan"
                            id="so_no_plan"
                            class="form-select"
                        >

                            <option value="">
                                Select SO No.
                            </option>


                            <?php foreach ($so_numbers as $so): ?>

                                <option
                                    value="<?= htmlspecialchars($so) ?>"
                                >

                                    <?= htmlspecialchars($so) ?>

                                </option>

                            <?php endforeach; ?>


                        </select>

                    </div>


                    <!-- MANUAL ENTRY DESCRIPTION -->

                    <div
                        class="mb-4"
                        id="manual_so_section"
                        style="display:none;"
                    >

                        <label
                            for="manual_description"
                            class="form-label fw-semibold"
                        >
                            Description
                        </label>


                        <textarea
                            name="manual_description"
                            id="manual_description"
                            class="form-control"
                            rows="4"
                            placeholder="Enter description"
                        ></textarea>

                    </div>


                    <div class="row" id="status_row">


                        <!-- PANEL -->

                        <div class="col-md-3 mb-4">

                            <label
                                class="form-label fw-semibold"
                            >
                                Panel
                            </label>


                            <select
                                name="panel_status"
                                id="panel_status"
                                class="form-select status-select"
                                data-target="panel_other_section"
                                required
                            >

                                <option value="">
                                    Select
                                </option>

                                <option value="Yes">
                                    Yes
                                </option>

                                <option value="No">
                                    No
                                </option>

                                <option value="Not Applicable">
                                    Not Applicable
                                </option>

                                <option value="Other">
                                    Other
                                </option>

                            </select>


                            <div
                                class="mt-2"
                                id="panel_other_section"
                                style="display:none;"
                            >

                                <input
                                    type="text"
                                    name="panel_other_desc"
                                    id="panel_other_desc"
                                    class="form-control"
                                    placeholder="Enter Panel description"
                                >

                            </div>

                        </div>


                        <!-- MB -->

                        <div class="col-md-3 mb-4">

                            <label
                                class="form-label fw-semibold"
                            >
                                MB
                            </label>


                            <select
                                name="mb_status"
                                id="mb_status"
                                class="form-select status-select"
                                data-target="mb_other_section"
                                required
                            >

                                <option value="">
                                    Select
                                </option>

                                <option value="Yes">
                                    Yes
                                </option>

                                <option value="No">
                                    No
                                </option>

                                <option value="Not Applicable">
                                    Not Applicable
                                </option>

                                <option value="Other">
                                    Other
                                </option>

                            </select>


                            <div
                                class="mt-2"
                                id="mb_other_section"
                                style="display:none;"
                            >

                                <input
                                    type="text"
                                    name="mb_other_desc"
                                    id="mb_other_desc"
                                    class="form-control"
                                    placeholder="Enter MB description"
                                >

                            </div>

                        </div>


                        <!-- CABLE -->

                        <div class="col-md-3 mb-4">

                            <label
                                class="form-label fw-semibold"
                            >
                                Cable
                            </label>


                            <select
                                name="cable_status"
                                id="cable_status"
                                class="form-select status-select"
                                data-target="cable_other_section"
                                required
                            >

                                <option value="">
                                    Select
                                </option>

                                <option value="Yes">
                                    Yes
                                </option>

                                <option value="No">
                                    No
                                </option>

                                <option value="Not Applicable">
                                    Not Applicable
                                </option>

                                <option value="Other">
                                    Other
                                </option>

                            </select>


                            <div
                                class="mt-2"
                                id="cable_other_section"
                                style="display:none;"
                            >

                                <input
                                    type="text"
                                    name="cable_other_desc"
                                    id="cable_other_desc"
                                    class="form-control"
                                    placeholder="Enter Cable description"
                                >

                            </div>

                        </div>


                        <!-- RATING PLATE -->

                        <div class="col-md-3 mb-4">

                            <label
                                class="form-label fw-semibold"
                            >
                                Rating Plate
                            </label>


                            <select
                                name="rating_plate_status"
                                id="rating_plate_status"
                                class="form-select status-select"
                                data-target="rating_plate_other_section"
                                required
                            >

                                <option value="">
                                    Select
                                </option>

                                <option value="Yes">
                                    Yes
                                </option>

                                <option value="No">
                                    No
                                </option>

                                <option value="Not Applicable">
                                    Not Applicable
                                </option>

                                <option value="Other">
                                    Other
                                </option>

                            </select>


                            <div
                                class="mt-2"
                                id="rating_plate_other_section"
                                style="display:none;"
                            >

                                <input
                                    type="text"
                                    name="rating_plate_other_desc"
                                    id="rating_plate_other_desc"
                                    class="form-control"
                                    placeholder="Enter Rating Plate description"
                                >

                            </div>

                        </div>


                    </div>


                    <!-- REMARK -->

                    <div class="mb-4" id="remark_section">

                        <label
                            for="remark"
                            class="form-label fw-semibold"
                        >
                            Remark
                        </label>


                        <textarea
                            name="remark"
                            id="remark"
                            class="form-control"
                            rows="3"
                            placeholder="Enter remark"
                        ></textarea>

                    </div>


                    <!-- BUTTONS -->

                    <button
                        type="submit"
                        class="btn btn-primary"
                    >

                        Submit

                    </button>


                    <a
                        href="view.php"
                        class="btn btn-secondary"
                    >

                        View Entries

                    </a>


                </form>


            </div>

        </div>

    </div>

</div>


<!-- JAVASCRIPT -->

<script>

document.addEventListener(
    "DOMContentLoaded",
    function () {


        const entryType =
            document.getElementById("entry_type");


        const planSection =
            document.getElementById("plan_so_section");


        const manualSection =
            document.getElementById("manual_so_section");


        const planSO =
            document.getElementById("so_no_plan");


        const manualDescription =
            document.getElementById("manual_description");


        const statusRow =
            document.getElementById("status_row");


        const remarkSection =
            document.getElementById("remark_section");


        const statusSelectEls =
            document.querySelectorAll(".status-select");


        /*
        |--------------------------------------------------------------------------
        | SHOW "OTHER" DESCRIPTION BOX ONLY WHEN STATUS = OTHER
        |--------------------------------------------------------------------------
        */

        statusSelectEls.forEach(function (select) {


            const targetId =
                select.getAttribute("data-target");


            const targetDiv =
                document.getElementById(targetId);


            const targetInput =
                targetDiv.querySelector("input");


            function updateOtherField() {

                if (select.value === "Other") {

                    targetDiv.style.display =
                        "block";

                    targetInput.required =
                        true;

                } else {

                    targetDiv.style.display =
                        "none";

                    targetInput.required =
                        false;

                    targetInput.value =
                        "";

                }

            }


            select.addEventListener(
                "change",
                updateOtherField
            );


            // run once on load in case of validation re-render
            updateOtherField();


        });


        function updateSOFields() {


            if (entryType.value === "plan") {


                planSection.style.display =
                    "block";


                manualSection.style.display =
                    "none";


                statusRow.style.display =
                    "flex";


                remarkSection.style.display =
                    "block";


                planSO.required =
                    true;


                manualDescription.required =
                    false;


                manualDescription.value =
                    "";


                statusSelectEls.forEach(function (select) {

                    select.required = true;

                });


            }


            else if (
                entryType.value === "manual"
            ) {


                planSection.style.display =
                    "none";


                manualSection.style.display =
                    "block";


                statusRow.style.display =
                    "none";


                remarkSection.style.display =
                    "none";


                planSO.required =
                    false;


                planSO.value =
                    "";


                manualDescription.required =
                    true;


                statusSelectEls.forEach(function (select) {

                    select.required = false;

                    select.value = "";

                    select.dispatchEvent(new Event("change"));

                });


            }


            else {


                planSection.style.display =
                    "none";


                manualSection.style.display =
                    "none";


                statusRow.style.display =
                    "none";


                remarkSection.style.display =
                    "none";


                planSO.required =
                    false;


                manualDescription.required =
                    false;


                statusSelectEls.forEach(function (select) {

                    select.required = false;

                });


            }

        }


        entryType.addEventListener(
            "change",
            updateSOFields
        );


        // set initial visibility state on page load
        updateSOFields();


    }

);

</script>


<script
    src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js">
</script>

<script
    src="../assets/js/script.js">
</script>


</body>
</html>