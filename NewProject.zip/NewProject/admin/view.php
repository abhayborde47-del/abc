<?php

require "../config.php";
require "../includes/auth_user.php";
require "../includes/security.php";


/*
|--------------------------------------------------------------------------
| ACCESS CONTROL
|--------------------------------------------------------------------------
*/

if (
    strtolower(trim($_SESSION['user_department']))
    !== 'sscontrol'
) {
    header("Location: ../login.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/

$entry_type =
    isset($_GET['entry_type']) &&
    in_array($_GET['entry_type'], ['plan', 'manual'], true)
        ? $_GET['entry_type']
        : '';

$so_search =
    trim($_GET['so_search'] ?? '');


$allowed_fields = [
    'panel_status'        => 'Panel',
    'mb_status'           => 'MB',
    'cable_status'        => 'Cable',
    'rating_plate_status' => 'Rating Plate'
];


$field_name =
    isset($_GET['field_name']) &&
    array_key_exists($_GET['field_name'], $allowed_fields)
        ? $_GET['field_name']
        : '';


$allowed_values = [
    'Yes',
    'No',
    'Not Applicable',
    'Other'
];


$field_value =
    isset($_GET['field_value']) &&
    in_array($_GET['field_value'], $allowed_values, true)
        ? $_GET['field_value']
        : '';


$date_search =
    trim($_GET['date_search'] ?? '');


/*
|--------------------------------------------------------------------------
| PAGINATION
|--------------------------------------------------------------------------
*/

$per_page = 15;

$so_page =
    max(1, (int)($_GET['page'] ?? 1));

$so_offset =
    ($so_page - 1) * $per_page;


$manual_page =
    max(1, (int)($_GET['mpage'] ?? 1));

$manual_offset =
    ($manual_page - 1) * $per_page;


/*
|--------------------------------------------------------------------------
| SO BASED WHERE
|--------------------------------------------------------------------------
*/

$so_where = [];
$so_params = [];
$so_types = '';


if ($so_search !== '') {

    $so_where[] =
        "so_no_new LIKE ?";

    $so_params[] =
        '%' . $so_search . '%';

    $so_types .= 's';
}


if (
    $field_name !== '' &&
    $field_value !== ''
) {

    $so_where[] =
        "$field_name = ?";

    $so_params[] =
        $field_value;

    $so_types .= 's';
}


if ($date_search !== '') {

    $so_where[] =
        "DATE(created_at) = ?";

    $so_params[] =
        $date_search;

    $so_types .= 's';
}


$so_where_sql =
    count($so_where) > 0
        ? 'WHERE ' . implode(' AND ', $so_where)
        : '';


/*
|--------------------------------------------------------------------------
| SO COUNT
|--------------------------------------------------------------------------
*/

$so_count_sql = "
    SELECT COUNT(*) AS total
    FROM sscontrol_entries
    $so_where_sql
";


$so_count_stmt =
    $conn->prepare($so_count_sql);


if (!$so_count_stmt) {
    die(
        "SO count prepare failed: "
        . $conn->error
    );
}


if ($so_types !== '') {

    $so_count_stmt->bind_param(
        $so_types,
        ...$so_params
    );

}


$so_count_stmt->execute();


$so_count_result =
    $so_count_stmt->get_result();


$so_total =
    (int)(
        $so_count_result
            ->fetch_assoc()['total']
        ?? 0
    );


$so_count_stmt->close();


$so_total_pages =
    max(
        1,
        (int)ceil(
            $so_total / $per_page
        )
    );


if ($so_page > $so_total_pages) {

    $so_page =
        $so_total_pages;

    $so_offset =
        ($so_page - 1) * $per_page;

}


/*
|--------------------------------------------------------------------------
| SO DATA
|--------------------------------------------------------------------------
*/

$so_sql = "
    SELECT
        id,
        so_no_new,
        panel_status,
        panel_other_desc,
        mb_status,
        mb_other_desc,
        cable_status,
        cable_other_desc,
        rating_plate_status,
        rating_plate_other_desc,
        remark,
        entered_by,
        created_at
    FROM sscontrol_entries
    $so_where_sql
    ORDER BY id DESC
    LIMIT ? OFFSET ?
";


$so_stmt =
    $conn->prepare($so_sql);


if (!$so_stmt) {
    die(
        "SO query prepare failed: "
        . $conn->error
    );
}


$so_all_types =
    $so_types . 'ii';

$so_all_params =
    $so_params;

$so_all_params[] =
    $per_page;

$so_all_params[] =
    $so_offset;


$so_stmt->bind_param(
    $so_all_types,
    ...$so_all_params
);


$so_stmt->execute();


$result =
    $so_stmt->get_result();


/*
|--------------------------------------------------------------------------
| MANUAL WHERE
|--------------------------------------------------------------------------
*/

$manual_where = [];
$manual_params = [];
$manual_types = '';


if ($date_search !== '') {

    $manual_where[] =
        "DATE(created_at) = ?";

    $manual_params[] =
        $date_search;

    $manual_types .= 's';
}


$manual_where_sql =
    count($manual_where) > 0
        ? 'WHERE ' . implode(' AND ', $manual_where)
        : '';


/*
|--------------------------------------------------------------------------
| MANUAL COUNT
|--------------------------------------------------------------------------
*/

$manual_count_sql = "
    SELECT COUNT(*) AS total
    FROM sscontrol_manual_entries
    $manual_where_sql
";


$manual_count_stmt =
    $conn->prepare(
        $manual_count_sql
    );


if (!$manual_count_stmt) {
    die(
        "Manual count prepare failed: "
        . $conn->error
    );
}


if ($manual_types !== '') {

    $manual_count_stmt->bind_param(
        $manual_types,
        ...$manual_params
    );

}


$manual_count_stmt->execute();


$manual_count_result =
    $manual_count_stmt->get_result();


$manual_total =
    (int)(
        $manual_count_result
            ->fetch_assoc()['total']
        ?? 0
    );


$manual_count_stmt->close();


$manual_total_pages =
    max(
        1,
        (int)ceil(
            $manual_total / $per_page
        )
    );


if ($manual_page > $manual_total_pages) {

    $manual_page =
        $manual_total_pages;

    $manual_offset =
        ($manual_page - 1) * $per_page;

}


/*
|--------------------------------------------------------------------------
| MANUAL DATA
|--------------------------------------------------------------------------
*/

$manual_sql = "
    SELECT
        id,
        description,
        entered_by,
        created_at
    FROM sscontrol_manual_entries
    $manual_where_sql
    ORDER BY id DESC
    LIMIT ? OFFSET ?
";


$manual_stmt =
    $conn->prepare(
        $manual_sql
    );


if (!$manual_stmt) {
    die(
        "Manual query prepare failed: "
        . $conn->error
    );
}


$manual_all_types =
    $manual_types . 'ii';

$manual_all_params =
    $manual_params;

$manual_all_params[] =
    $per_page;

$manual_all_params[] =
    $manual_offset;


$manual_stmt->bind_param(
    $manual_all_types,
    ...$manual_all_params
);


$manual_stmt->execute();


$manual_result =
    $manual_stmt->get_result();


/*
|--------------------------------------------------------------------------
| STATUS DISPLAY
|--------------------------------------------------------------------------
*/

function render_status(
    $status,
    $other_desc
) {

    $status =
        $status ?? '';

    $other_desc =
        $other_desc ?? '';


    if (
        $status === 'Other' &&
        $other_desc !== ''
    ) {

        return
            htmlspecialchars($status)
            . ' - '
            . htmlspecialchars($other_desc);

    }


    return htmlspecialchars($status);
}


/*
|--------------------------------------------------------------------------
| QUERY STRING
|--------------------------------------------------------------------------
*/

function build_query(
    $overrides = []
) {

    $params =
        $_GET;

    foreach (
        $overrides as $key => $value
    ) {

        $params[$key] =
            $value;

    }


    return htmlspecialchars(
        '?' . http_build_query($params)
    );
}

?>

<?php require "../includes/header.php"; ?>

<?php require "../includes/sidebar_admin.php"; ?>


<div class="content">

    <div class="container-fluid">


        <!-- HEADER -->

        <div class="d-flex justify-content-between align-items-center mb-4">

            <div>

                <h2>
                    SSControl Entries
                </h2>

                <p class="text-muted mb-0">
                    Submitted SSControl information
                </p>

            </div>


            <a
                href="add.php"
                class="btn btn-primary"
            >
                + Add Entry
            </a>

        </div>


        <!-- SUCCESS MESSAGES -->

        <?php if (isset($_GET['success'])): ?>

            <div class="alert alert-success alert-dismissible fade show">

                Entry saved successfully.

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                ></button>

            </div>

        <?php endif; ?>


        <?php if (isset($_GET['updated'])): ?>

            <div class="alert alert-success alert-dismissible fade show">

                Entry updated successfully.

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                ></button>

            </div>

        <?php endif; ?>


        <?php if (isset($_GET['manual_updated'])): ?>

            <div class="alert alert-success alert-dismissible fade show">

                Manual entry updated successfully.

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                ></button>

            </div>

        <?php endif; ?>


        <?php if (isset($_GET['deleted'])): ?>

            <div class="alert alert-success alert-dismissible fade show">

                Entry deleted successfully.

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"
                ></button>

            </div>

        <?php endif; ?>


        <!-- FILTERS -->

        <div class="card shadow-sm mb-4">

            <div class="card-body">

                <form
                    method="GET"
                    action="view.php"
                    class="row g-3 align-items-end"
                >

                    <!-- ENTRY TYPE -->

                    <div class="col-md-3">

                        <label class="form-label fw-semibold">
                            Entry Type
                        </label>

                        <select
                            name="entry_type"
                            class="form-select"
                        >

                            <option
                                value=""
                                <?= $entry_type === ''
                                    ? 'selected'
                                    : '' ?>
                            >
                                All
                            </option>

                            <option
                                value="plan"
                                <?= $entry_type === 'plan'
                                    ? 'selected'
                                    : '' ?>
                            >
                                SO Based
                            </option>

                            <option
                                value="manual"
                                <?= $entry_type === 'manual'
                                    ? 'selected'
                                    : '' ?>
                            >
                                Manual
                            </option>

                        </select>

                    </div>


                    <!-- SO SEARCH -->

                    <div class="col-md-2">

                        <label class="form-label fw-semibold">
                            SO No.
                        </label>

                        <input
                            type="text"
                            name="so_search"
                            class="form-control"
                            placeholder="Search SO No."
                            value="<?= htmlspecialchars($so_search) ?>"
                        >

                    </div>


                    <!-- FIELD -->

                    <div class="col-md-2">

                        <label class="form-label fw-semibold">
                            Field
                        </label>

                        <select
                            name="field_name"
                            class="form-select"
                        >

                            <option value="">
                                Select Field
                            </option>

                            <?php foreach (
                                $allowed_fields as $col => $label
                            ): ?>

                                <option
                                    value="<?= htmlspecialchars($col) ?>"
                                    <?= $field_name === $col
                                        ? 'selected'
                                        : '' ?>
                                >
                                    <?= htmlspecialchars($label) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <!-- VALUE -->

                    <div class="col-md-2">

                        <label class="form-label fw-semibold">
                            Value
                        </label>

                        <select
                            name="field_value"
                            class="form-select"
                        >

                            <option value="">
                                Select Value
                            </option>

                            <?php foreach (
                                $allowed_values as $val
                            ): ?>

                                <option
                                    value="<?= htmlspecialchars($val) ?>"
                                    <?= $field_value === $val
                                        ? 'selected'
                                        : '' ?>
                                >
                                    <?= htmlspecialchars($val) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>


                    <!-- DATE -->

                    <div class="col-md-2">

                        <label class="form-label fw-semibold">
                            Date
                        </label>

                        <input
                            type="date"
                            name="date_search"
                            class="form-control"
                            value="<?= htmlspecialchars($date_search) ?>"
                        >

                    </div>


                    <!-- SEARCH -->

                    <div class="col-md-1">

                        <button
                            type="submit"
                            class="btn btn-primary w-100"
                        >
                            Search
                        </button>

                    </div>


                    <!-- RESET -->

                    <div class="col-12">

                        <a
                            href="view.php"
                            class="btn btn-sm btn-outline-secondary"
                        >
                            Reset Filters
                        </a>

                    </div>

                </form>

            </div>

        </div>


        <!-- DOWNLOAD -->

        <div class="card shadow-sm mb-4">

            <div class="card-body">

                <form
                    method="GET"
                    action="download.php"
                    class="row g-3 align-items-end"
                >

                    <input
                        type="hidden"
                        name="entry_type"
                        value="<?= htmlspecialchars($entry_type) ?>"
                    >

                    <input
                        type="hidden"
                        name="so_search"
                        value="<?= htmlspecialchars($so_search) ?>"
                    >

                    <input
                        type="hidden"
                        name="field_name"
                        value="<?= htmlspecialchars($field_name) ?>"
                    >

                    <input
                        type="hidden"
                        name="field_value"
                        value="<?= htmlspecialchars($field_value) ?>"
                    >

                    <div class="col-md-3">

                        <label class="form-label fw-semibold">
                            Download Month
                        </label>

                        <input
                            type="month"
                            name="month"
                            class="form-control"
                        >

                    </div>


                    <div class="col-md-3">

                        <button
                            type="submit"
                            class="btn btn-success"
                        >
                            Download CSV
                        </button>

                    </div>


                    <div class="col-md-6 text-muted small align-self-center">

                        Downloads respect the current
                        Entry Type / SO No. / Status filters
                        plus the selected month.

                    </div>

                </form>

            </div>

        </div>


        <!-- =========================================================
             SO BASED TABLE
        ========================================================== -->

        <?php if (
            $entry_type === '' ||
            $entry_type === 'plan'
        ): ?>


        <div class="card shadow-sm mb-4">

            <div class="card-body">


                <div class="d-flex justify-content-between align-items-center mb-3">

                    <h5 class="mb-0">
                        SO Based Entries
                    </h5>

                    <span class="badge bg-secondary">
                        Total: <?= $so_total ?>
                    </span>

                </div>


                <div class="table-responsive">

                    <table class="table table-bordered table-hover align-middle">

                        <thead class="table-light">

                            <tr>

                                <th>SO No.</th>

                                <th>Panel</th>

                                <th>MB</th>

                                <th>Cable</th>

                                <th>Rating Plate</th>

                                <th>Remark</th>

                                <th>Entered By</th>

                                <th>Date</th>

                                <th>Action</th>

                            </tr>

                        </thead>


                        <tbody>


                        <?php if ($result->num_rows > 0): ?>


                            <?php while (
                                $row =
                                $result->fetch_assoc()
                            ): ?>

                                <tr>


                                    <td>
                                        <?= htmlspecialchars(
                                            $row['so_no_new']
                                        ) ?>
                                    </td>


                                    <td>
                                        <?= render_status(
                                            $row['panel_status'],
                                            $row['panel_other_desc']
                                        ) ?>
                                    </td>


                                    <td>
                                        <?= render_status(
                                            $row['mb_status'],
                                            $row['mb_other_desc']
                                        ) ?>
                                    </td>


                                    <td>
                                        <?= render_status(
                                            $row['cable_status'],
                                            $row['cable_other_desc']
                                        ) ?>
                                    </td>


                                    <td>
                                        <?= render_status(
                                            $row['rating_plate_status'],
                                            $row['rating_plate_other_desc']
                                        ) ?>
                                    </td>


                                    <td style="min-width:200px;">

                                        <?= nl2br(
                                            htmlspecialchars(
                                                $row['remark'] ?? ''
                                            )
                                        ) ?>

                                    </td>


                                    <td>
                                        <?= htmlspecialchars(
                                            $row['entered_by'] ?? ''
                                        ) ?>
                                    </td>


                                    <td>
                                        <?= htmlspecialchars(
                                            $row['created_at'] ?? ''
                                        ) ?>
                                    </td>


                                    <!-- ACTION -->

                                    <td>

                                        <div class="d-flex gap-1">


                                            <a
                                                href="edit.php?id=<?= (int)$row['id'] ?>"
                                                class="btn btn-sm btn-warning"
                                            >
                                                Edit
                                            </a>


                                            <a
                                                href="delete.php?id=<?= (int)$row['id'] ?>&type=plan"
                                                class="btn btn-sm btn-danger"
                                                onclick="return confirm('Are you sure you want to delete this entry?');"
                                            >
                                                Delete
                                            </a>


                                        </div>

                                    </td>


                                </tr>

                            <?php endwhile; ?>


                        <?php else: ?>

                            <tr>

                                <td
                                    colspan="9"
                                    class="text-center text-muted py-4"
                                >
                                    No SSControl entries found.
                                </td>

                            </tr>

                        <?php endif; ?>


                        </tbody>

                    </table>

                </div>


                <!-- SO PAGINATION -->

                <?php if ($so_total > 0): ?>

                <nav>

                    <ul class="pagination mb-0">


                        <li
                            class="page-item
                            <?= $so_page <= 1
                                ? 'disabled'
                                : '' ?>"
                        >

                            <a
                                class="page-link"
                                href="<?= $so_page <= 1
                                    ? '#'
                                    : build_query([
                                        'page' =>
                                            $so_page - 1
                                    ]) ?>"
                            >
                                Previous
                            </a>

                        </li>


                        <li class="page-item disabled">

                            <span class="page-link">

                                Page
                                <?= $so_page ?>
                                of
                                <?= $so_total_pages ?>

                            </span>

                        </li>


                        <li
                            class="page-item
                            <?= $so_page >= $so_total_pages
                                ? 'disabled'
                                : '' ?>"
                        >

                            <a
                                class="page-link"
                                href="<?= $so_page >= $so_total_pages
                                    ? '#'
                                    : build_query([
                                        'page' =>
                                            $so_page + 1
                                    ]) ?>"
                            >
                                Next
                            </a>

                        </li>


                    </ul>

                </nav>

                <?php endif; ?>


            </div>

        </div>

        <?php endif; ?>


        <!-- =========================================================
             MANUAL TABLE
        ========================================================== -->

        <?php if (
            $entry_type === '' ||
            $entry_type === 'manual'
        ): ?>


        <div class="card shadow-sm">

            <div class="card-body">


                <div class="d-flex justify-content-between align-items-center mb-3">

                    <h5 class="mb-0">
                        Manual Entries
                    </h5>

                    <span class="badge bg-secondary">
                        Total: <?= $manual_total ?>
                    </span>

                </div>


                <div class="table-responsive">

                    <table class="table table-bordered table-hover align-middle">

                        <thead class="table-light">

                            <tr>

                                <th>Description</th>

                                <th>Entered By</th>

                                <th>Date</th>

                                <th>Action</th>

                            </tr>

                        </thead>


                        <tbody>


                        <?php if (
                            $manual_result->num_rows > 0
                        ): ?>


                            <?php while (
                                $row =
                                $manual_result->fetch_assoc()
                            ): ?>


                                <tr>


                                    <td style="min-width:300px;">

                                        <?= nl2br(
                                            htmlspecialchars(
                                                $row['description'] ?? ''
                                            )
                                        ) ?>

                                    </td>


                                    <td>

                                        <?= htmlspecialchars(
                                            $row['entered_by'] ?? ''
                                        ) ?>

                                    </td>


                                    <td>

                                        <?= htmlspecialchars(
                                            $row['created_at'] ?? ''
                                        ) ?>

                                    </td>


                                    <!-- MANUAL ACTION -->

                                    <td>

                                        <div class="d-flex gap-1">


                                            <!-- EDIT MANUAL -->

                                            <a
                                                href="edit_manual.php?id=<?= (int)$row['id'] ?>"
                                                class="btn btn-sm btn-warning"
                                            >
                                                Edit
                                            </a>


                                            <!-- DELETE MANUAL -->

                                            <a
                                                href="delete.php?id=<?= (int)$row['id'] ?>&type=manual"
                                                class="btn btn-sm btn-danger"
                                                onclick="return confirm('Are you sure you want to delete this manual entry?');"
                                            >
                                                Delete
                                            </a>


                                        </div>

                                    </td>


                                </tr>


                            <?php endwhile; ?>


                        <?php else: ?>


                            <tr>

                                <td
                                    colspan="4"
                                    class="text-center text-muted py-4"
                                >
                                    No manual entries found.
                                </td>

                            </tr>


                        <?php endif; ?>


                        </tbody>

                    </table>

                </div>


                <!-- MANUAL PAGINATION -->

                <?php if ($manual_total > 0): ?>

                <nav>

                    <ul class="pagination mb-0">


                        <li
                            class="page-item
                            <?= $manual_page <= 1
                                ? 'disabled'
                                : '' ?>"
                        >

                            <a
                                class="page-link"
                                href="<?= $manual_page <= 1
                                    ? '#'
                                    : build_query([
                                        'mpage' =>
                                            $manual_page - 1
                                    ]) ?>"
                            >
                                Previous
                            </a>

                        </li>


                        <li class="page-item disabled">

                            <span class="page-link">

                                Page
                                <?= $manual_page ?>
                                of
                                <?= $manual_total_pages ?>

                            </span>

                        </li>


                        <li
                            class="page-item
                            <?= $manual_page >= $manual_total_pages
                                ? 'disabled'
                                : '' ?>"
                        >

                            <a
                                class="page-link"
                                href="<?= $manual_page >= $manual_total_pages
                                    ? '#'
                                    : build_query([
                                        'mpage' =>
                                            $manual_page + 1
                                    ]) ?>"
                            >
                                Next
                            </a>

                        </li>


                    </ul>

                </nav>

                <?php endif; ?>


            </div>

        </div>

        <?php endif; ?>


    </div>

</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="../assets/js/script.js"></script>


</body>

</html>