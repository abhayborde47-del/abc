<?php
require "../config.php";
require "../includes/auth_admin_ais.php";
require "../includes/security.php";
require "../includes/crypto.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

$stmt = $conn->prepare("SELECT * FROM users WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
    die("User not found");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    csrf_verify($_POST['csrf_token'] ?? '');

    $email = trim($_POST['email']);
    $department = trim($_POST['department']);

    if (!empty($_POST['password'])) {

        $password     = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $password_enc = pw_encrypt($_POST['password']);

        $stmt = $conn->prepare(
            "UPDATE users
             SET email=?, password=?, password_enc=?, department=?
             WHERE id=?"
        );

        $stmt->bind_param(
            "ssssi",
            $email,
            $password,
            $password_enc,
            $department,
            $id
        );

    } else {

        $stmt = $conn->prepare(
            "UPDATE users
             SET email=?, department=?
             WHERE id=?"
        );

        $stmt->bind_param(
            "ssi",
            $email,
            $department,
            $id
        );
    }

    if ($stmt->execute()) {
        header("Location: add_user.php");
        exit;
    }
}
?>

<?php require "../includes/header.php"; ?>
<?php require "../includes/sidebar_admin.php"; ?>

<div class="content">
    <h3>Edit User</h3>

    <form method="post">

        <?php csrf_field(); ?>

        <div class="mb-3">
            <label>Email</label>
            <input type="email"
                   name="email"
                   class="form-control"
                   value="<?= htmlspecialchars($user['email']) ?>"
                   required>
        </div>

        <div class="mb-3">
            <label>New Password (Optional)</label>
            <input type="password"
                   name="password"
                   class="form-control">
        </div>

        <div class="mb-3">
            <label>Department</label>
            <select name="department" class="form-select" required>
                <?php
                    $deptOptions = ['AIS' => 'AIS', 'SSControl' => 'SSControl', 'adi' => 'ADI User'];
                    // If this user somehow has a department outside the managed
                    // list, keep it selectable so saving the form doesn't change it by accident.
                    if (!array_key_exists($user['department'], $deptOptions)) {
                        $deptOptions[$user['department']] = $user['department'] . ' (current)';
                    }
                ?>
                <?php foreach ($deptOptions as $value => $label): ?>
                    <option value="<?= htmlspecialchars($value) ?>" <?= $value === $user['department'] ? 'selected' : '' ?>>
                        <?= htmlspecialchars($label) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <button class="btn btn-success">
            Update User
        </button>

        <a href="add_user.php" class="btn btn-secondary">
            Back
        </a>

    </form>
</div>