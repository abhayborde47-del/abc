<?php
require "../config.php";
require "../includes/auth_admin_ais.php";
require "../includes/security.php";

$actor_email     = $_SESSION['admin_email'];
$panel           = 'admin';
$sidebar_include = "sidebar_admin.php";

require "../includes/day_plan_shared.php";
