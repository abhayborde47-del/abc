<?php
require "../config.php";
require "../includes/auth_admin_ais.php";

$msg = "";
$msgType = "info";

/* =========================================================
   FILTERS — date (single day, defaults to today) + optional factory
   + optional employee name search
========================================================= */

$date    = trim($_GET['date']    ?? date('Y-m-d'));
$factory = trim($_GET['factory'] ?? '');
$search  = trim($_GET['search']  ?? '');

$factories = [];
$fRes = $conn->query("SELECT DISTINCT factory FROM employees WHERE factory <> '' ORDER BY factory");
if ($fRes) {
    while ($row = $fRes->fetch_assoc()) {
        $factories[] = $row['factory'];
    }
}


/* =========================================================
   DELETE
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_entry'])) {

    $id = (int) ($_POST['id'] ?? 0);

    if ($id > 0) {
        $stmt = $conn->prepare("DELETE FROM plan_vs_actual WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $msg = "Entry #$id deleted.";
        $msgType = "success";
    }
}


/* =========================================================
   PAGINATION
========================================================= */

$limit = 20;
$page  = isset($_GET['page']) ? (int) $_GET['page'] : 1;
if ($page < 1) {
    $page = 1;
}
$offset = ($page - 1) * $limit;


/* =========================================================
   BUILD QUERY
========================================================= */

$where  = ["p.entry_date = ?"];
$params = [$date];
$types  = "s";

if ($factory !== '') {
    $where[]  = "p.factory = ?";
    $params[] = $factory;
    $types   .= "s";
}

if ($search !== '') {
    $where[]  = "(e.name LIKE ? OR e.employee_code LIKE ?)";
    $searchTerm = "%$search%";
    $params[] = $searchTerm;
    $params[] = $searchTerm;
    $types   .= "ss";
}

$whereSql = "WHERE " . implode(" AND ", $where);

/* Count (needs the employees join since search filters on it) */
$countStmt = $conn->prepare("
    SELECT COUNT(*) AS total
    FROM plan_vs_actual p
    LEFT JOIN employees e ON e.id = p.employee_id
    $whereSql
");
$countStmt->bind_param($types, ...$params);
$countStmt->execute();
$totalRecords = (int) $countStmt->get_result()->fetch_assoc()['total'];
$totalPages   = max(1, ceil($totalRecords / $limit));

if ($page > $totalPages) {
    $page   = $totalPages;
    $offset = ($page - 1) * $limit;
}

/* Fetch */
$sql = "
    SELECT p.id, p.entry_date, p.factory, p.station, p.sub_option, p.shift,
           p.breaker_rating, p.plan_qty, p.actual_qty, p.loss_category,
           p.loss_time_hr, p.remark,
           e.employee_code, e.name AS employee_name
    FROM plan_vs_actual p
    LEFT JOIN employees e ON e.id = p.employee_id
    $whereSql
    ORDER BY p.factory ASC, p.station ASC
    LIMIT ? OFFSET ?
";

$params2 = $params;
$types2  = $types . "ii";
$params2[] = $limit;
$params2[] = $offset;

$stmt = $conn->prepare($sql);
$stmt->bind_param($types2, ...$params2);
$stmt->execute();
$entries = $stmt->get_result();

/* Day totals for a quick summary strip (respects the same filters, including search) */
$sumStmt = $conn->prepare("
    SELECT COALESCE(SUM(p.plan_qty),0) AS total_plan,
           COALESCE(SUM(p.actual_qty),0) AS total_actual,
           COALESCE(SUM(p.loss_time_hr),0) AS total_loss_hr
    FROM plan_vs_actual p
    LEFT JOIN employees e ON e.id = p.employee_id
    $whereSql
");
$sumStmt->bind_param($types, ...$params);
$sumStmt->execute();
$sums = $sumStmt->get_result()->fetch_assoc();
?>

<?php require "../includes/header.php"; ?>
<?php require "../includes/sidebar_admin.php"; ?>

<div class="content">

    <div class="container-fluid">

        <div class="d-flex justify-content-between align-items-center mb-3">
            <h3 class="mb-0">Plan vs Actual — View Entries</h3>
            <a href="add_plan_actual.php" class="btn btn-success">Add Entry</a>
        </div>

        <?php if ($msg) : ?>
            <div class="alert alert-<?= $msgType ?>">
                <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <!-- Filters -->
        <div class="card mb-4">
            <div class="card-body">

                <form method="GET" class="row g-2 align-items-end">

                    <div class="col-md-3">
                        <label class="form-label">Date</label>
                        <input type="date"
                               name="date"
                               class="form-control"
                               value="<?= htmlspecialchars($date) ?>"
                               required>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">Factory (optional)</label>
                        <select name="factory" class="form-control">
                            <option value="">All Factories</option>
                            <?php foreach ($factories as $f) : ?>
                                <option value="<?= htmlspecialchars($f) ?>"
                                    <?= $f === $factory ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($f) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">Employee (name or code)</label>
                        <input type="text"
                               name="search"
                               class="form-control"
                               placeholder="Search employee..."
                               value="<?= htmlspecialchars($search) ?>">
                    </div>

                    <div class="col-md-1">
                        <button type="submit" class="btn btn-primary w-100">View</button>
                    </div>

                    <div class="col-md-2">
                        <a class="btn btn-outline-success w-100"
                           href="download_plan_actual.php?month=<?= urlencode(substr($date, 0, 7)) ?>">
                            Download Month (Excel)
                        </a>
                    </div>

                </form>

            </div>
        </div>

        <!-- Day summary -->
        <div class="row text-center g-2 mb-4">
            <div class="col-6 col-md-3">
                <div class="border rounded p-2">
                    <div class="fw-bold fs-5"><?= (int) $sums['total_plan'] ?></div>
                    <div class="small text-muted">Total Plan Qty</div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="border rounded p-2">
                    <div class="fw-bold fs-5"><?= (int) $sums['total_actual'] ?></div>
                    <div class="small text-muted">Total Actual Qty</div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="border rounded p-2">
                    <div class="fw-bold fs-5"><?= htmlspecialchars($sums['total_loss_hr']) ?></div>
                    <div class="small text-muted">Total Loss Hr</div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="border rounded p-2">
                    <div class="fw-bold fs-5"><?= $totalRecords ?></div>
                    <div class="small text-muted">Entries</div>
                </div>
            </div>
        </div>

        <!-- Entries table -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <?= htmlspecialchars($date) ?><?= $factory !== '' ? ' — ' . htmlspecialchars($factory) : '' ?><?= $search !== '' ? ' — "' . htmlspecialchars($search) . '"' : '' ?>
                </h5>
            </div>

            <div class="card-body">

                <div class="table-responsive">
                    <table class="table table-bordered table-sm table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Factory</th>
                                <th>Employee</th>
                                <th>Station</th>
                                <th>Work</th>
                                <th>Shift</th>
                                <th>Rating</th>
                                <th width="80">Plan</th>
                                <th width="80">Actual</th>
                                <th width="100">Loss Cat.</th>
                                <th width="80">Loss Hr</th>
                                <th>Remark</th>
                                <th width="160">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                        <?php if ($entries->num_rows === 0) : ?>

                            <tr>
                                <td colspan="12" class="text-center text-muted py-3">
                                    No entries for this date<?= $factory !== '' ? ' / factory' : '' ?><?= $search !== '' ? ' / search' : '' ?>.
                                </td>
                            </tr>

                        <?php else : ?>

                            <?php while ($r = $entries->fetch_assoc()) :
                                $hasLoss = (int) $r['actual_qty'] < (int) $r['plan_qty'];
                            ?>
                                <tr>
                                    <td><?= htmlspecialchars($r['factory']) ?></td>
                                    <td>
                                        <?= htmlspecialchars($r['employee_name'] ?? '—') ?>
                                        <?php if ($r['employee_code']) : ?>
                                            <div class="text-muted small"><?= htmlspecialchars($r['employee_code']) ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td><?= htmlspecialchars($r['station']) ?></td>
                                    <td><?= htmlspecialchars($r['sub_option']) ?></td>
                                    <td><?= htmlspecialchars($r['shift']) ?></td>
                                    <td><?= htmlspecialchars($r['breaker_rating']) ?></td>
                                    <td><?= (int) $r['plan_qty'] ?></td>
                                    <td class="<?= $hasLoss ? 'text-danger fw-bold' : 'text-success fw-bold' ?>">
                                        <?= (int) $r['actual_qty'] ?>
                                    </td>
                                    <td><?= htmlspecialchars($r['loss_category']) ?></td>
                                    <td><?= htmlspecialchars($r['loss_time_hr']) ?></td>
                                    <td><?= htmlspecialchars($r['remark'] ?? '') ?></td>
                                    <td class="d-flex gap-1">
                                        <a href="edit_plan_actual.php?id=<?= (int) $r['id'] ?>&date=<?= urlencode($date) ?>"
                                           class="btn btn-sm btn-outline-primary">
                                            Edit
                                        </a>
                                        <form method="POST" onsubmit="return confirm('Delete this entry?');" class="d-inline">
                                            <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                                            <button type="submit" name="delete_entry"
                                                    class="btn btn-sm btn-outline-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endwhile; ?>

                        <?php endif; ?>

                        </tbody>
                    </table>
                </div>

            </div>
        </div>

        <!-- Pagination -->
        <?php if ($totalPages > 1) : ?>

            <div class="d-flex justify-content-center mt-3">
                <nav>
                    <ul class="pagination pagination-sm">

                        <li class="page-item <?= ($page <= 1) ? 'disabled' : '' ?>">
                            <a class="page-link" href="?date=<?= urlencode($date) ?>&factory=<?= urlencode($factory) ?>&search=<?= urlencode($search) ?>&page=<?= $page - 1 ?>">
                                Previous
                            </a>
                        </li>

                        <?php
                        $startPage = max(1, $page - 2);
                        $endPage   = min($totalPages, $page + 2);
                        ?>

                        <?php for ($p = $startPage; $p <= $endPage; $p++) : ?>
                            <li class="page-item <?= ($p == $page) ? 'active' : '' ?>">
                                <a class="page-link" href="?date=<?= urlencode($date) ?>&factory=<?= urlencode($factory) ?>&search=<?= urlencode($search) ?>&page=<?= $p ?>">
                                    <?= $p ?>
                                </a>
                            </li>
                        <?php endfor; ?>

                        <li class="page-item <?= ($page >= $totalPages) ? 'disabled' : '' ?>">
                            <a class="page-link" href="?date=<?= urlencode($date) ?>&factory=<?= urlencode($factory) ?>&search=<?= urlencode($search) ?>&page=<?= $page + 1 ?>">
                                Next
                            </a>
                        </li>

                    </ul>
                </nav>
            </div>

        <?php endif; ?>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

</body>
</html>