<?php
require "../config.php";
require "../includes/auth_admin_ais.php";

$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($id > 0) {

    $stmt = $conn->prepare("DELETE FROM employees WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        $_SESSION['flash_msg'] = "Employee deleted successfully.";
    } else {
        $_SESSION['flash_msg'] = "Employee not found or already deleted.";
    }

} else {
    $_SESSION['flash_msg'] = "Invalid employee ID.";
}

header("Location: employees.php");
exit;