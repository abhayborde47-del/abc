<?php

require "../config.php";
require "../includes/auth_user.php";
require "../includes/security.php";


if (
    strtolower(trim($_SESSION['user_department']))
    !== 'sscontrol'
) {
    header("Location: ../login.php");
    exit;
}


$entry_type =
    isset($_GET['entry_type']) && in_array($_GET['entry_type'], ['plan', 'manual'], true)
        ? $_GET['entry_type']
        : '';

$so_search =
    trim($_GET['so_search'] ?? '');

$month =
    trim($_GET['month'] ?? ''); // format: YYYY-MM


header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="sscontrol_entries_' . date('Y-m-d_His') . '.csv"');

$out = fopen('php://output', 'w');


/*
|--------------------------------------------------------------------------
| SO BASED ENTRIES
|--------------------------------------------------------------------------
*/

if ($entry_type === '' || $entry_type === 'plan') {

    $where = [];
    $params = [];
    $types = '';

    if ($so_search !== '') {
        $where[] = "so_no_new LIKE ?";
        $params[] = '%' . $so_search . '%';
        $types .= 's';
    }

    if ($month !== '') {
        $where[] = "DATE_FORMAT(created_at, '%Y-%m') = ?";
        $params[] = $month;
        $types .= 's';
    }

    $where_sql = count($where) > 0 ? 'WHERE ' . implode(' AND ', $where) : '';

    $sql = "
        SELECT
            id,
            so_no_new,
            panel_status,
            panel_other_desc,
            mb_status,
            mb_other_desc,
            cable_status,
            cable_other_desc,
            rating_plate_status,
            rating_plate_other_desc,
            remark,
            entered_by,
            created_at
        FROM sscontrol_entries
        $where_sql
        ORDER BY id DESC
    ";

    $stmt = $conn->prepare($sql);

    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    fputcsv($out, ['SO Based Entries']);
    fputcsv($out, [
        'ID', 'SO No.', 'Panel', 'Panel Other', 'MB', 'MB Other',
        'Cable', 'Cable Other', 'Rating Plate', 'Rating Plate Other',
        'Remark', 'Entered By', 'Date'
    ]);

    while ($row = $result->fetch_assoc()) {
        fputcsv($out, [
            $row['id'],
            $row['so_no_new'],
            $row['panel_status'],
            $row['panel_other_desc'],
            $row['mb_status'],
            $row['mb_other_desc'],
            $row['cable_status'],
            $row['cable_other_desc'],
            $row['rating_plate_status'],
            $row['rating_plate_other_desc'],
            $row['remark'],
            $row['entered_by'],
            $row['created_at'],
        ]);
    }

    fputcsv($out, []); // blank line separator

}


/*
|--------------------------------------------------------------------------
| MANUAL ENTRIES
|--------------------------------------------------------------------------
*/

if ($entry_type === '' || $entry_type === 'manual') {

    $where = [];
    $params = [];
    $types = '';

    if ($month !== '') {
        $where[] = "DATE_FORMAT(created_at, '%Y-%m') = ?";
        $params[] = $month;
        $types .= 's';
    }

    $where_sql = count($where) > 0 ? 'WHERE ' . implode(' AND ', $where) : '';

    $sql = "
        SELECT id, description, entered_by, created_at
        FROM sscontrol_manual_entries
        $where_sql
        ORDER BY id DESC
    ";

    $stmt = $conn->prepare($sql);

    if ($types !== '') {
        $stmt->bind_param($types, ...$params);
    }

    $stmt->execute();
    $result = $stmt->get_result();

    fputcsv($out, ['Manual Entries']);
    fputcsv($out, ['ID', 'Description', 'Entered By', 'Date']);

    while ($row = $result->fetch_assoc()) {
        fputcsv($out, [
            $row['id'],
            $row['description'],
            $row['entered_by'],
            $row['created_at'],
        ]);
    }

}


fclose($out);
exit;