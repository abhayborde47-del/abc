<?php
require "../config.php";
require "../includes/auth_admin_ais.php";


// =====================================================
// DELETE
// =====================================================

if (isset($_GET['delete'])) {

    $cb = $_GET['delete'];

    $stmt = $conn->prepare("
        DELETE FROM plans
        WHERE cb_serial_no = ?
    ");

    $stmt->bind_param("s", $cb);
    $stmt->execute();

    $search = isset($_GET['search']) ? $_GET['search'] : '';

    if (!empty($search)) {
        header("Location: view_plan.php?search=" . urlencode($search));
    } else {
        header("Location: view_plan.php");
    }

    exit;
}


// =====================================================
// SEARCH
// =====================================================

$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : '';


// =====================================================
// PAGINATION
// =====================================================

$limit = 20;

$page = isset($_GET['page'])
    ? (int)$_GET['page']
    : 1;

if ($page < 1) {
    $page = 1;
}

$offset = ($page - 1) * $limit;


// =====================================================
// COUNT RECORDS
// =====================================================

if (!empty($search)) {

    $countStmt = $conn->prepare("
        SELECT COUNT(*) AS total
        FROM plans
        WHERE cb_serial_no LIKE ?
    ");

    $searchParam = "%" . $search . "%";

    $countStmt->bind_param(
        "s",
        $searchParam
    );

    $countStmt->execute();

    $countResult = $countStmt->get_result();

} else {

    $countResult = $conn->query("
        SELECT COUNT(*) AS total
        FROM plans
    ");
}


$totalRows = $countResult->fetch_assoc()['total'];

$totalPages = ceil($totalRows / $limit);


// =====================================================
// GET RECORDS
// =====================================================

if (!empty($search)) {

    $stmt = $conn->prepare("
        SELECT *
        FROM plans
        WHERE cb_serial_no LIKE ?
        ORDER BY uploaded_at DESC
        LIMIT ? OFFSET ?
    ");

    $stmt->bind_param(
        "sii",
        $searchParam,
        $limit,
        $offset
    );

    $stmt->execute();

    $plans = $stmt->get_result();

} else {

    $stmt = $conn->prepare("
        SELECT *
        FROM plans
        ORDER BY uploaded_at DESC
        LIMIT ? OFFSET ?
    ");

    $stmt->bind_param(
        "ii",
        $limit,
        $offset
    );

    $stmt->execute();

    $plans = $stmt->get_result();
}

?>

<?php require "../includes/header.php"; ?>
<?php require "../includes/sidebar_admin.php"; ?>


<style>

/* =====================================================
   IMPORTANT: DO NOT IMPACT SIDEBAR
===================================================== */

.content {
    max-width: 100%;
    width: 100%;
    overflow-x: hidden;
    box-sizing: border-box;
}


/* =====================================================
   PAGE CONTAINER
===================================================== */

.plan-page {
    width: 100%;
    max-width: 100%;
    box-sizing: border-box;
}


/* =====================================================
   SEARCH BOX
===================================================== */

.plan-search {
    background: #ffffff;
    border: 1px solid #dee2e6;
    border-radius: 6px;
    padding: 10px;
    margin-bottom: 12px;
}


/* =====================================================
   TABLE WRAPPER
   ONLY TABLE CAN SCROLL
===================================================== */

.plan-table-wrapper {
    width: 100%;
    max-width: 100%;
    overflow-x: auto;
    overflow-y: hidden;
    border: 1px solid #dee2e6;
    border-radius: 5px;
}


/* =====================================================
   SMALL TABLE
===================================================== */

.plan-table {
    width: 100%;
    min-width: 900px;
    margin-bottom: 0;
    font-size: 12px;
}


/* Table cells */

.plan-table th,
.plan-table td {
    padding: 5px 6px !important;
    vertical-align: middle;
    white-space: nowrap;
}


/* Header */

.plan-table thead th {
    font-size: 11px;
    font-weight: 600;
}


/* =====================================================
   ACTION BUTTONS
===================================================== */

.plan-btn {
    font-size: 11px !important;
    padding: 3px 7px !important;
    line-height: 1.2;
}


/* =====================================================
   PAGINATION
===================================================== */

.plan-pagination {
    margin-top: 10px;
}

.plan-pagination .page-link {
    font-size: 12px;
    padding: 4px 8px;
}


/* =====================================================
   PAGE INFORMATION
===================================================== */

.plan-info {
    font-size: 11px;
    margin-top: 6px;
}


/* =====================================================
   MOBILE
===================================================== */

@media (max-width: 768px) {

    .content {
        padding: 10px !important;
        overflow-x: hidden;
    }

    .plan-table {
        font-size: 11px;
    }

    .plan-table th,
    .plan-table td {
        padding: 4px !important;
    }

}

</style>


<div class="content">

    <div class="plan-page">


        <!-- =================================================
             HEADER
        ================================================== -->

        <div class="d-flex justify-content-between align-items-center mb-2">

            <h5 class="mb-0">
                View Plan
            </h5>

            <span class="text-muted" style="font-size:11px;">

                Total:
                <strong><?= $totalRows ?></strong>

            </span>

        </div>


        <!-- =================================================
             SEARCH
        ================================================== -->

        <div class="plan-search">

            <form method="GET">

                <div class="row g-2 align-items-center">

                    <div class="col">

                        <input
                            type="text"
                            name="search"
                            class="form-control form-control-sm"
                            placeholder="Search CB Serial Number..."
                            value="<?= htmlspecialchars($search) ?>"
                        >

                    </div>


                    <div class="col-auto">

                        <button
                            type="submit"
                            class="btn btn-primary btn-sm">

                            Search

                        </button>

                    </div>


                    <?php if (!empty($search)): ?>

                    <div class="col-auto">

                        <a
                            href="view_plan.php"
                            class="btn btn-secondary btn-sm">

                            Clear

                        </a>

                    </div>

                    <?php endif; ?>

                </div>

            </form>

        </div>


        <!-- =================================================
             TABLE
        ================================================== -->

        <div class="plan-table-wrapper">

            <table class="table table-bordered table-sm plan-table">

                <thead class="table-dark">

                    <tr>

                        <th>CB Serial</th>
                        <th>Spare</th>
                        <th>SO No</th>
                        <th>Region</th>
                        <th>Customer</th>
                        <th>Product</th>
                        <th>Creepage</th>
                        <th>Action</th>

                    </tr>

                </thead>


                <tbody>


                <?php if ($plans->num_rows > 0): ?>


                    <?php while ($p = $plans->fetch_assoc()): ?>

                    <tr>

                        <!-- CB SERIAL -->

                        <td>
                            <?= htmlspecialchars($p['cb_serial_no']) ?>
                        </td>


                        <!-- SPARE -->

                        <td>
                            <?= htmlspecialchars($p['spare']) ?>
                        </td>


                        <!-- SO -->

                        <td>
                            <?= htmlspecialchars($p['so_no_new']) ?>
                        </td>


                        <!-- REGION -->

                        <td>
                            <?= htmlspecialchars($p['region']) ?>
                        </td>


                        <!-- CUSTOMER -->

                        <td>
                            <?= htmlspecialchars($p['customer']) ?>
                        </td>


                        <!-- PRODUCT -->

                        <td>
                            <?= htmlspecialchars($p['product']) ?>
                        </td>


                        <!-- CREEPAGE -->

                        <td>
                            <?= htmlspecialchars($p['creepage']) ?>
                        </td>


                        <!-- ACTION -->

                        <td>

                            <div class="d-flex gap-1">


                                <!-- UPDATE -->

                                <a
                                    href="edit_plan.php?cb=<?= urlencode($p['cb_serial_no']) ?>"
                                    target="_blank"
                                    class="btn btn-primary plan-btn">

                                    Update

                                </a>


                                <!-- DELETE -->

                                <a
                                    href="?delete=<?= urlencode($p['cb_serial_no']) ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>&page=<?= $page ?>"
                                    class="btn btn-danger plan-btn"
                                    onclick="return confirm('Delete this record?')">

                                    Delete

                                </a>


                            </div>

                        </td>


                    </tr>

                    <?php endwhile; ?>


                <?php else: ?>


                    <tr>

                        <td
                            colspan="8"
                            class="text-center text-muted"
                            style="padding:15px !important;">

                            <?php if (!empty($search)): ?>

                                No records found for
                                <strong>
                                    <?= htmlspecialchars($search) ?>
                                </strong>

                            <?php else: ?>

                                No plans found.

                            <?php endif; ?>

                        </td>

                    </tr>


                <?php endif; ?>


                </tbody>

            </table>

        </div>


        <!-- =================================================
             PAGINATION
        ================================================== -->

        <?php if ($totalPages > 1): ?>

        <nav class="plan-pagination">

            <ul class="pagination pagination-sm justify-content-center mb-1">


                <!-- PREVIOUS -->

                <?php if ($page > 1): ?>

                    <li class="page-item">

                        <a
                            class="page-link"
                            href="?page=<?= $page - 1 ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>">

                            Previous

                        </a>

                    </li>

                <?php endif; ?>


                <!-- PAGE NUMBERS -->

                <?php

                $startPage = max(1, $page - 2);
                $endPage = min($totalPages, $page + 2);

                ?>


                <?php if ($startPage > 1): ?>

                    <li class="page-item">

                        <a
                            class="page-link"
                            href="?page=1<?= !empty($search) ? '&search=' . urlencode($search) : '' ?>">

                            1

                        </a>

                    </li>


                    <?php if ($startPage > 2): ?>

                        <li class="page-item disabled">

                            <span class="page-link">
                                ...
                            </span>

                        </li>

                    <?php endif; ?>

                <?php endif; ?>


                <?php for ($i = $startPage; $i <= $endPage; $i++): ?>

                    <li
                        class="page-item <?= ($i == $page) ? 'active' : '' ?>">

                        <a
                            class="page-link"
                            href="?page=<?= $i ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>">

                            <?= $i ?>

                        </a>

                    </li>

                <?php endfor; ?>


                <?php if ($endPage < $totalPages): ?>

                    <?php if ($endPage < $totalPages - 1): ?>

                        <li class="page-item disabled">

                            <span class="page-link">
                                ...
                            </span>

                        </li>

                    <?php endif; ?>


                    <li class="page-item">

                        <a
                            class="page-link"
                            href="?page=<?= $totalPages ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>">

                            <?= $totalPages ?>

                        </a>

                    </li>

                <?php endif; ?>


                <!-- NEXT -->

                <?php if ($page < $totalPages): ?>

                    <li class="page-item">

                        <a
                            class="page-link"
                            href="?page=<?= $page + 1 ?><?= !empty($search) ? '&search=' . urlencode($search) : '' ?>">

                            Next

                        </a>

                    </li>

                <?php endif; ?>


            </ul>

        </nav>

        <?php endif; ?>


        <!-- =================================================
             RECORD INFORMATION
        ================================================== -->

        <?php if ($totalRows > 0): ?>

            <div class="text-center text-muted plan-info">

                Showing

                <strong>
                    <?= $offset + 1 ?>
                </strong>

                -

                <strong>
                    <?= min($offset + $limit, $totalRows) ?>
                </strong>

                of

                <strong>
                    <?= $totalRows ?>
                </strong>

                records

            </div>

        <?php endif; ?>


    </div>

</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="../assets/js/script.js"></script>

</body>
</html>