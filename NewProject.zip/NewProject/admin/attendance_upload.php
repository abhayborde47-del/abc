<?php
require "../config.php";
require "../includes/auth_admin_ais.php";
require "../lib/xlsx_reader.php";

$msg = "";

// Shared insert statement builder (reused by both flows)
function insertEmployee($conn, $factory, $empCode, $name) {
    $stmt = $conn->prepare(
        "INSERT INTO employees (factory, employee_code, name) VALUES (?, ?, ?)"
    );
    $stmt->bind_param("sss", $factory, $empCode, $name);
    $ok = $stmt->execute();
    $errno = $conn->errno;
    $stmt->close();
    return [$ok, $errno];
}

/* ------------------------------------------------------------
   FLOW 1: Excel upload
------------------------------------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['attendance_file'])) {

    $tmpPath = $_FILES['attendance_file']['tmp_name'];
    $rows = readXLSX($tmpPath);

    if (count($rows) > 0) {

        $header = array_map(function ($h) {
            return strtolower(trim($h));
        }, $rows[0]);

        $map = [
            'factory'       => array_search('factory', $header),
            'employee_code' => array_search('employee code', $header),
            'name'          => array_search('name', $header),
        ];

        $inserted = 0;
        $skipped  = 0;
        $invalid  = 0;

        for ($i = 1; $i < count($rows); $i++) {

            $row = $rows[$i];

            $factory = $map['factory'] !== false
                ? trim($row[$map['factory']] ?? '')
                : '';
            $empCode = $map['employee_code'] !== false
                ? trim($row[$map['employee_code']] ?? '')
                : '';
            $name = $map['name'] !== false
                ? trim($row[$map['name']] ?? '')
                : '';

            if ($empCode === '') {
                $invalid++;
                continue;
            }

            [$ok, $errno] = insertEmployee($conn, $factory, $empCode, $name);

            if ($ok) {
                $inserted++;
            } elseif ($errno === 1062) {
                $skipped++;
            } else {
                $invalid++;
            }
        }

        $msg = "Upload complete. New records added: $inserted, Skipped (already exist): $skipped, Invalid rows: $invalid";

    } else {
        $msg = "Could not read excel file / file empty.";
    }
}

/* ------------------------------------------------------------
   FLOW 2: Manual single-employee entry
------------------------------------------------------------ */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['manual_add'])) {

    $factory = trim($_POST['factory'] ?? '');
    $empCode = trim($_POST['employee_code'] ?? '');
    $name    = trim($_POST['name'] ?? '');

    if ($empCode === '' || $name === '') {
        $msg = "Employee Code and Name are required.";
    } else {
        [$ok, $errno] = insertEmployee($conn, $factory, $empCode, $name);

        if ($ok) {
            $msg = "Employee \"$name\" ($empCode) added successfully.";
        } elseif ($errno === 1062) {
            $msg = "Employee Code \"$empCode\" already exists. Not added.";
        } else {
            $msg = "Could not add employee. Please try again.";
        }
    }
}
?>

<?php require "../includes/header.php"; ?>
<?php require "../includes/sidebar_admin.php"; ?>

<div class="content">

    <div class="container-fluid">

        <h3 class="mb-3">Upload Attendance / Employee Master (Excel)</h3>

        <?php if (!empty($msg)) : ?>
            <div class="alert alert-info">
                <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <!-- Excel upload card -->
        <div class="card mb-4">
            <div class="card-body">

                <h5 class="card-title mb-3">Bulk Upload via Excel</h5>

                <form method="POST" enctype="multipart/form-data" class="row g-2">

                    <div class="col-md-6">
                        <input
                            type="file"
                            name="attendance_file"
                            accept=".xlsx"
                            class="form-control"
                            required
                        >
                    </div>

                    <div class="col-md-2">
                        <button class="btn btn-success w-100">
                            Upload
                        </button>
                    </div>

                </form>

            </div>
        </div>

        <!-- Manual entry card -->
        <div class="card mb-4">
            <div class="card-body">

                <h5 class="card-title mb-3">Add Employee Manually</h5>

                <form method="POST" class="row g-2">

                    <div class="col-md-3">
                        <input
                            type="text"
                            name="factory"
                            class="form-control"
                            placeholder="Factory"
                        >
                    </div>

                    <div class="col-md-3">
                        <input
                            type="text"
                            name="employee_code"
                            class="form-control"
                            placeholder="Employee Code"
                            required
                        >
                    </div>

                    <div class="col-md-4">
                        <input
                            type="text"
                            name="name"
                            class="form-control"
                            placeholder="Name"
                            required
                        >
                    </div>

                    <div class="col-md-2">
                        <button type="submit" name="manual_add" value="1" class="btn btn-primary w-100">
                            Add
                        </button>
                    </div>

                </form>

            </div>
        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

</body>
</html>