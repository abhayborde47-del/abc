<?php
require "../config.php";
require "../includes/auth_admin_ais.php";

$month = $_GET['month'] ?? date('Y-m');

// Validate format (YYYY-MM) — fall back to current month if malformed
if (!preg_match('/^\d{4}-\d{2}$/', $month)) {
    $month = date('Y-m');
}

$stmt = $conn->prepare("
    SELECT p.entry_date, p.factory, p.station, p.sub_option, p.shift,
           p.breaker_rating, p.plan_qty, p.actual_qty, p.loss_category,
           p.loss_time_hr, p.remark,
           e.employee_code, e.name AS employee_name
    FROM plan_vs_actual p
    LEFT JOIN employees e ON e.id = p.employee_id
    WHERE DATE_FORMAT(p.entry_date, '%Y-%m') = ?
    ORDER BY p.entry_date ASC, p.factory ASC, p.station ASC
");
$stmt->bind_param("s", $month);
$stmt->execute();
$result = $stmt->get_result();

// Readable month name, e.g. "August 2026"
$monthLabel = DateTime::createFromFormat('Y-m-d', $month . '-01')->format('F Y');

$filename = "Plan_vs_Actual_" . str_replace(' ', '_', $monthLabel) . ".xls";

header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
header('Content-Disposition: attachment;filename="' . $filename . '"');
header('Cache-Control: max-age=0');

// UTF-8 BOM so Excel doesn't mangle special characters
echo "\xEF\xBB\xBF";
?>
<table border="1" cellspacing="0" cellpadding="4">
    <thead>
        <tr>
            <th colspan="13" style="background-color:#1B5E20; color:#FFFFFF; font-weight:bold; text-align:center; font-size:14px; padding:8px;">
                Plan vs Actual — <?= htmlspecialchars($monthLabel) ?>
            </th>
        </tr>
        <tr style="background-color:#2E7D32; color:#FFFFFF; font-weight:bold; text-align:center;">
            <th>Date</th>
            <th>Factory</th>
            <th>Employee</th>
            <th>GID</th>
            <th>Station</th>
            <th>Work</th>
            <th>Shift</th>
            <th>Rating</th>
            <th>Plan Qty</th>
            <th>Actual Qty</th>
            <th>Loss Category</th>
            <th>Loss Hr</th>
            <th>Remark</th>
        </tr>
    </thead>
    <tbody>
    <?php $i = 0; while ($r = $result->fetch_assoc()) :
        $i++;
        $rowBg = ($i % 2 === 0) ? '#E8F5E9' : '#FFFFFF';

        $date = (new DateTime($r['entry_date']))->format('n/j/Y');

        $planQty   = (int) $r['plan_qty'];
        $actualQty = (int) $r['actual_qty'];
        $hasLoss   = $actualQty < $planQty;
        $actualColor = $hasLoss ? '#C62828' : '#2E7D32';
    ?>
        <tr style="background-color:<?= $rowBg ?>;">
            <td><?= htmlspecialchars($date) ?></td>
            <td><?= htmlspecialchars($r['factory']) ?></td>
            <td><?= htmlspecialchars($r['employee_name'] ?? '—') ?></td>
            <td><?= htmlspecialchars($r['employee_code'] ?? '') ?></td>
            <td><?= htmlspecialchars($r['station']) ?></td>
            <td><?= htmlspecialchars($r['sub_option']) ?></td>
            <td><?= htmlspecialchars($r['shift']) ?></td>
            <td><?= htmlspecialchars($r['breaker_rating']) ?></td>
            <td style="text-align:center;"><?= $planQty ?></td>
            <td style="text-align:center; font-weight:bold; color:<?= $actualColor ?>;"><?= $actualQty ?></td>
            <td><?= htmlspecialchars($r['loss_category']) ?></td>
            <td><?= htmlspecialchars($r['loss_time_hr']) ?></td>
            <td><?= htmlspecialchars($r['remark'] ?? '') ?></td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>
