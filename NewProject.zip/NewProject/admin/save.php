<?php

require "../config.php";
require "../includes/auth_user.php";
require "../includes/security.php";


/*
|--------------------------------------------------------------------------
| ONLY SSCONTROL USERS
|--------------------------------------------------------------------------
*/

if (
    strtolower(trim($_SESSION['user_department']))
    !== 'sscontrol'
) {

    header("Location: ../login.php");

    exit;

}


/*
|--------------------------------------------------------------------------
| ONLY POST REQUEST
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header("Location: add.php");

    exit;

}


/*
|--------------------------------------------------------------------------
| GET ENTRY TYPE
|--------------------------------------------------------------------------
*/

$entry_type =
    trim($_POST['entry_type'] ?? '');


/*
|--------------------------------------------------------------------------
| GET SO NUMBER
|--------------------------------------------------------------------------
*/

$so_no_new = '';


/*
|--------------------------------------------------------------------------
| PLAN SO NUMBER
|--------------------------------------------------------------------------
*/

if ($entry_type === 'plan') {


    $so_no_new =
        trim($_POST['so_no_plan'] ?? '');


    if ($so_no_new === '') {

        die("Please select SO No.");

    }


    /*
    |--------------------------------------------------------------------------
    | VERIFY SO NUMBER EXISTS IN PLANS
    |--------------------------------------------------------------------------
    */

    $stmt = $conn->prepare("
        SELECT COUNT(*)
        FROM plans
        WHERE so_no_new = ?
    ");


    if (!$stmt) {

        die(
            "Prepare failed: "
            . $conn->error
        );

    }


    $stmt->bind_param(
        "s",
        $so_no_new
    );


    $stmt->execute();

    $stmt->bind_result($count);

    $stmt->fetch();

    $stmt->close();


    if ($count == 0) {

        die("Invalid SO No.");

    }

}


/*
|--------------------------------------------------------------------------
| MANUAL ENTRY - DESCRIPTION ONLY, SAVED TO A DIFFERENT TABLE
|--------------------------------------------------------------------------
*/

elseif ($entry_type === 'manual') {


    $manual_description =
        trim($_POST['manual_description'] ?? '');


    if ($manual_description === '') {

        die("Please enter description.");

    }


    $entered_by =
        $_SESSION['user_email'] ?? '';


    $stmt = $conn->prepare("

        INSERT INTO sscontrol_manual_entries
        (
            description,
            entered_by
        )

        VALUES
        (
            ?,
            ?
        )

    ");


    if (!$stmt) {

        die(
            "Prepare failed: "
            . $conn->error
        );

    }


    $stmt->bind_param(

        "ss",

        $manual_description,

        $entered_by

    );


    if (!$stmt->execute()) {

        die(

            "Failed to save entry: "

            . $stmt->error

        );

    }


    $stmt->close();


    header(
        "Location: add.php?success=1"
    );

    exit;

}


/*
|--------------------------------------------------------------------------
| INVALID ENTRY TYPE
|--------------------------------------------------------------------------
*/

else {

    die("Please select Entry Type.");

}


/*
|--------------------------------------------------------------------------
| STATUS FIELDS
|--------------------------------------------------------------------------
*/

$panel_status =
    trim($_POST['panel_status'] ?? '');


$mb_status =
    trim($_POST['mb_status'] ?? '');


$cable_status =
    trim($_POST['cable_status'] ?? '');


$rating_plate_status =
    trim(
        $_POST['rating_plate_status'] ?? ''
    );


$remark =
    trim($_POST['remark'] ?? '');


$entered_by =
    $_SESSION['user_email'] ?? '';


/*
|--------------------------------------------------------------------------
| VALIDATION - STATUS VALUES
|--------------------------------------------------------------------------
*/

$allowed_status = [

    'Yes',

    'No',

    'Not Applicable',

    'Other'

];


if (
    !in_array(
        $panel_status,
        $allowed_status,
        true
    )
) {

    die("Invalid Panel status.");

}


if (
    !in_array(
        $mb_status,
        $allowed_status,
        true
    )
) {

    die("Invalid MB status.");

}


if (
    !in_array(
        $cable_status,
        $allowed_status,
        true
    )
) {

    die("Invalid Cable status.");

}


if (
    !in_array(
        $rating_plate_status,
        $allowed_status,
        true
    )
) {

    die("Invalid Rating Plate status.");

}


/*
|--------------------------------------------------------------------------
| "OTHER" DESCRIPTIONS - ONLY TAKEN WHEN STATUS = OTHER
|--------------------------------------------------------------------------
*/

$panel_other_desc = '';

$mb_other_desc = '';

$cable_other_desc = '';

$rating_plate_other_desc = '';


if ($panel_status === 'Other') {

    $panel_other_desc =
        trim($_POST['panel_other_desc'] ?? '');


    if ($panel_other_desc === '') {

        die("Please enter Panel description.");

    }

}


if ($mb_status === 'Other') {

    $mb_other_desc =
        trim($_POST['mb_other_desc'] ?? '');


    if ($mb_other_desc === '') {

        die("Please enter MB description.");

    }

}


if ($cable_status === 'Other') {

    $cable_other_desc =
        trim($_POST['cable_other_desc'] ?? '');


    if ($cable_other_desc === '') {

        die("Please enter Cable description.");

    }

}


if ($rating_plate_status === 'Other') {

    $rating_plate_other_desc =
        trim($_POST['rating_plate_other_desc'] ?? '');


    if ($rating_plate_other_desc === '') {

        die("Please enter Rating Plate description.");

    }

}


/*
|--------------------------------------------------------------------------
| INSERT INTO DATABASE
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("

    INSERT INTO sscontrol_entries
    (
        so_no_new,
        panel_status,
        panel_other_desc,
        mb_status,
        mb_other_desc,
        cable_status,
        cable_other_desc,
        rating_plate_status,
        rating_plate_other_desc,
        remark,
        entered_by
    )

    VALUES
    (
        ?,
        ?,
        ?,
        ?,
        ?,
        ?,
        ?,
        ?,
        ?,
        ?,
        ?
    )

");


if (!$stmt) {

    die(
        "Prepare failed: "
        . $conn->error
    );

}


$stmt->bind_param(

    "sssssssssss",

    $so_no_new,

    $panel_status,

    $panel_other_desc,

    $mb_status,

    $mb_other_desc,

    $cable_status,

    $cable_other_desc,

    $rating_plate_status,

    $rating_plate_other_desc,

    $remark,

    $entered_by

);


if (!$stmt->execute()) {

    die(

        "Failed to save entry: "

        . $stmt->error

    );

}


$stmt->close();


/*
|--------------------------------------------------------------------------
| REDIRECT BACK TO ADD PAGE (NOT DIRECTLY TO VIEW PAGE)
|--------------------------------------------------------------------------
*/

header(
    "Location: add.php?success=1"
);

exit;

?>