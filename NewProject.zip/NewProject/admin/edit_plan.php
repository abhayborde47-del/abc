<?php
require "../config.php";
require "../includes/auth_admin_ais.php";

// Check CB serial number
if (!isset($_GET['cb']) || empty($_GET['cb'])) {
    header("Location: view_plan.php");
    exit;
}

$cb = $_GET['cb'];


// ==============================
// HANDLE UPDATE
// ==============================

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {

    $spare    = $_POST['spare'];
    $so       = $_POST['so_no_new'];
    $region   = $_POST['region'];
    $customer = $_POST['customer'];
    $product  = $_POST['product'];
    $creepage = $_POST['creepage'];

    $stmt = $conn->prepare("
        UPDATE plans
        SET
            spare = ?,
            so_no_new = ?,
            region = ?,
            customer = ?,
            product = ?,
            creepage = ?
        WHERE cb_serial_no = ?
    ");

    $stmt->bind_param(
        "sssssss",
        $spare,
        $so,
        $region,
        $customer,
        $product,
        $creepage,
        $cb
    );

    if ($stmt->execute()) {

        // After update go back to view plan
        header("Location: view_plan.php");
        exit;

    } else {

        $error = "Failed to update record.";
    }
}


// ==============================
// GET EXISTING RECORD
// ==============================

$stmt = $conn->prepare("
    SELECT *
    FROM plans
    WHERE cb_serial_no = ?
");

$stmt->bind_param("s", $cb);
$stmt->execute();

$result = $stmt->get_result();

$plan = $result->fetch_assoc();


// Record not found
if (!$plan) {
    header("Location: view_plan.php");
    exit;
}

?>

<?php require "../includes/header.php"; ?>
<?php require "../includes/sidebar_admin.php"; ?>

<div class="content">

    <div class="container-fluid">

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-3">

            <h4>
                Update Plan
            </h4>

            <a href="view_plan.php"
               class="btn btn-secondary">
                ← Back
            </a>

        </div>


        <!-- Error -->
        <?php if (isset($error)): ?>

            <div class="alert alert-danger">
                <?= htmlspecialchars($error) ?>
            </div>

        <?php endif; ?>


        <!-- Update Card -->
        <div class="card shadow-sm">

            <div class="card-header">

                <strong>
                    Update CB:
                    <?= htmlspecialchars($plan['cb_serial_no']) ?>
                </strong>

            </div>


            <div class="card-body">

                <form method="POST">


                    <div class="row">


                        <!-- CB Serial No -->
                        <div class="col-md-6 mb-3">

                            <label class="form-label">
                                CB Serial No
                            </label>

                            <input
                                type="text"
                                class="form-control"
                                value="<?= htmlspecialchars($plan['cb_serial_no']) ?>"
                                readonly
                            >

                        </div>


                        <!-- Spare -->
                        <div class="col-md-6 mb-3">

                            <label class="form-label">
                                Spare
                            </label>

                            <input
                                type="text"
                                name="spare"
                                class="form-control"
                                value="<?= htmlspecialchars($plan['spare']) ?>"
                            >

                        </div>


                        <!-- SO No New -->
                        <div class="col-md-6 mb-3">

                            <label class="form-label">
                                SO No New
                            </label>

                            <input
                                type="text"
                                name="so_no_new"
                                class="form-control"
                                value="<?= htmlspecialchars($plan['so_no_new']) ?>"
                            >

                        </div>


                        <!-- Region -->
                        <div class="col-md-6 mb-3">

                            <label class="form-label">
                                Region
                            </label>

                            <input
                                type="text"
                                name="region"
                                class="form-control"
                                value="<?= htmlspecialchars($plan['region']) ?>"
                            >

                        </div>


                        <!-- Customer -->
                        <div class="col-md-6 mb-3">

                            <label class="form-label">
                                Customer
                            </label>

                            <input
                                type="text"
                                name="customer"
                                class="form-control"
                                value="<?= htmlspecialchars($plan['customer']) ?>"
                            >

                        </div>


                        <!-- Product -->
                        <div class="col-md-6 mb-3">

                            <label class="form-label">
                                Product
                            </label>

                            <input
                                type="text"
                                name="product"
                                class="form-control"
                                value="<?= htmlspecialchars($plan['product']) ?>"
                            >

                        </div>


                        <!-- Creepage -->
                        <div class="col-md-6 mb-3">

                            <label class="form-label">
                                Creepage
                            </label>

                            <input
                                type="text"
                                name="creepage"
                                class="form-control"
                                value="<?= htmlspecialchars($plan['creepage']) ?>"
                            >

                        </div>


                    </div>


                    <hr>


                    <!-- Buttons -->
                    <div class="d-flex gap-2">

                        <button
                            type="submit"
                            name="update"
                            class="btn btn-primary">
                            Update Plan
                        </button>


                        <a
                            href="view_plan.php"
                            class="btn btn-secondary">
                            Cancel
                        </a>

                    </div>


                </form>

            </div>

        </div>

    </div>

</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="../assets/js/script.js"></script>

</body>
</html>