<?php

require "../config.php";
require "../includes/auth_user.php";
require "../includes/security.php";


/*
|--------------------------------------------------------------------------
| ACCESS CONTROL
|--------------------------------------------------------------------------
*/

if (
    strtolower(trim($_SESSION['user_department']))
    !== 'sscontrol'
) {
    header("Location: ../login.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| ID
|--------------------------------------------------------------------------
*/

$id =
    (int)($_GET['id'] ?? 0);


if ($id <= 0) {

    require "../includes/header.php";
    require "../includes/sidebar_sscontrol.php";

    echo '
    <div class="content">
        <div class="container-fluid">

            <div class="alert alert-danger mt-4">
                Invalid manual entry ID.
            </div>

            <a href="view.php" class="btn btn-secondary">
                Back to Entries
            </a>

        </div>
    </div>';

    exit;
}


/*
|--------------------------------------------------------------------------
| FETCH
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    SELECT
        id,
        description,
        entered_by,
        created_at
    FROM sscontrol_manual_entries
    WHERE id = ?
    LIMIT 1
");


if (!$stmt) {

    die(
        "Prepare failed: "
        . $conn->error
    );
}


$stmt->bind_param(
    "i",
    $id
);


$stmt->execute();


$result =
    $stmt->get_result();


$row =
    $result->fetch_assoc();


$stmt->close();


if (!$row) {

    require "../includes/header.php";
    require "../includes/sidebar_sscontrol.php";

    echo '
    <div class="content">
        <div class="container-fluid">

            <div class="alert alert-danger mt-4">
                Manual entry not found.
            </div>

            <a href="view.php" class="btn btn-secondary">
                Back to Entries
            </a>

        </div>
    </div>';

    exit;
}


$description =
    $row['description'] ?? '';

?>

<?php require "../includes/header.php"; ?>

<?php require "../includes/sidebar_sscontrol.php"; ?>


<div class="content">

    <div class="container-fluid">


        <div class="d-flex justify-content-between align-items-center mb-4">

            <div>

                <h2>
                    Edit Manual Entry
                </h2>

                <p class="text-muted mb-0">
                    Update manual SSControl information
                </p>

            </div>


            <a
                href="view.php"
                class="btn btn-secondary"
            >
                ← Back to Entries
            </a>

        </div>


        <div class="card shadow-sm">

            <div class="card-body">


                <form
                    method="POST"
                    action="update_manual.php"
                >


                    <input
                        type="hidden"
                        name="id"
                        value="<?= (int)$id ?>"
                    >


                    <!-- DESCRIPTION -->

                    <div class="mb-4">

                        <label class="form-label fw-semibold">

                            Description

                        </label>


                        <textarea
                            name="description"
                            class="form-control"
                            rows="7"
                            placeholder="Enter description"
                            required
                        ><?= htmlspecialchars($description) ?></textarea>

                    </div>


                    <!-- ENTERED BY -->

                    <div class="mb-3">

                        <label class="form-label fw-semibold">

                            Entered By

                        </label>


                        <input
                            type="text"
                            class="form-control"
                            value="<?= htmlspecialchars($row['entered_by'] ?? '') ?>"
                            readonly
                        >

                    </div>


                    <!-- DATE -->

                    <div class="mb-4">

                        <label class="form-label fw-semibold">

                            Created Date

                        </label>


                        <input
                            type="text"
                            class="form-control"
                            value="<?= htmlspecialchars($row['created_at'] ?? '') ?>"
                            readonly
                        >

                    </div>


                    <!-- BUTTONS -->

                    <div class="d-flex gap-2">

                        <button
                            type="submit"
                            class="btn btn-success"
                        >
                            Update Manual Entry
                        </button>


                        <a
                            href="view.php"
                            class="btn btn-secondary"
                        >
                            Cancel
                        </a>

                    </div>


                </form>


            </div>

        </div>


    </div>

</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="../assets/js/script.js"></script>


</body>
</html>