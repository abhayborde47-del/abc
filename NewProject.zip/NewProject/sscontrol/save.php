<?php

require "../config.php";
require "../includes/auth_user.php";
require "../includes/security.php";


/*
|--------------------------------------------------------------------------
| ONLY SSCONTROL USERS
|--------------------------------------------------------------------------
*/

if (
    strtolower(trim($_SESSION['user_department']))
    !== 'sscontrol'
) {

    header("Location: ../login.php");

    exit;

}


/*
|--------------------------------------------------------------------------
| ONLY POST REQUEST
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header("Location: add.php");

    exit;

}


/*
|--------------------------------------------------------------------------
| GET ENTRY TYPE
|--------------------------------------------------------------------------
*/

$entry_type =
    trim($_POST['entry_type'] ?? '');


/*
|--------------------------------------------------------------------------
| GET SO NUMBER
|--------------------------------------------------------------------------
*/

$so_no_new = '';


/*
|--------------------------------------------------------------------------
| PLAN SO NUMBER
|--------------------------------------------------------------------------
*/

if ($entry_type === 'plan') {


    $so_no_new =
        trim($_POST['so_no_plan'] ?? '');


    if ($so_no_new === '') {

        die("Please select SO No.");

    }


    /*
    |--------------------------------------------------------------------------
    | VERIFY SO NUMBER EXISTS IN PLANS
    |--------------------------------------------------------------------------
    */

    $stmt = $conn->prepare("
        SELECT COUNT(*)
        FROM plans
        WHERE so_no_new = ?
    ");


    if (!$stmt) {

        die(
            "Prepare failed: "
            . $conn->error
        );

    }


    $stmt->bind_param(
        "s",
        $so_no_new
    );


    $stmt->execute();

    $stmt->bind_result($count);

    $stmt->fetch();

    $stmt->close();


    if ($count == 0) {

        die("Invalid SO No.");

    }

}


/*
|--------------------------------------------------------------------------
| MANUAL SO NUMBER
|--------------------------------------------------------------------------
*/

elseif ($entry_type === 'manual') {


    $so_no_new =
        trim($_POST['so_no_manual'] ?? '');


    if ($so_no_new === '') {

        die("Please enter SO No. manually.");

    }

}


/*
|--------------------------------------------------------------------------
| INVALID ENTRY TYPE
|--------------------------------------------------------------------------
*/

else {

    die("Please select Entry Type.");

}


/*
|--------------------------------------------------------------------------
| OTHER DATA
|--------------------------------------------------------------------------
*/

$panel_status =
    trim($_POST['panel_status'] ?? '');


$mb_cable_status =
    trim($_POST['mb_cable_status'] ?? '');


$rating_plate_status =
    trim(
        $_POST['rating_plate_status'] ?? ''
    );


$other =
    trim($_POST['other'] ?? '');


$remark =
    trim($_POST['remark'] ?? '');


$entered_by =
    $_SESSION['user_email'] ?? '';


/*
|--------------------------------------------------------------------------
| VALIDATION
|--------------------------------------------------------------------------
*/

$allowed_status = [

    'Yes',

    'No',

    'Not Applicable'

];


if (
    !in_array(
        $panel_status,
        $allowed_status,
        true
    )
) {

    die("Invalid Panel status.");

}


if (
    !in_array(
        $mb_cable_status,
        $allowed_status,
        true
    )
) {

    die("Invalid MB Cable status.");

}


if (
    !in_array(
        $rating_plate_status,
        $allowed_status,
        true
    )
) {

    die("Invalid Rating Plate status.");

}


/*
|--------------------------------------------------------------------------
| INSERT INTO DATABASE
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("

    INSERT INTO sscontrol_entries
    (
        so_no_new,
        panel_status,
        mb_cable_status,
        rating_plate_status,
        other,
        remark,
        entered_by
    )

    VALUES
    (
        ?,
        ?,
        ?,
        ?,
        ?,
        ?,
        ?
    )

");


if (!$stmt) {

    die(
        "Prepare failed: "
        . $conn->error
    );

}


$stmt->bind_param(

    "sssssss",

    $so_no_new,

    $panel_status,

    $mb_cable_status,

    $rating_plate_status,

    $other,

    $remark,

    $entered_by

);


if (!$stmt->execute()) {

    die(

        "Failed to save entry: "

        . $stmt->error

    );

}


$stmt->close();


/*
|--------------------------------------------------------------------------
| REDIRECT
|--------------------------------------------------------------------------
*/

header(
    "Location: view.php?success=1"
);

exit;

?>