<?php

require "../config.php";
require "../includes/auth_user.php";
require "../includes/security.php";


if (
    strtolower(trim($_SESSION['user_department']))
    !== 'sscontrol'
) {
    header("Location: ../login.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| HELPER - SHOW ERROR WITH ADMIN LAYOUT INSTEAD OF BARE die()
|--------------------------------------------------------------------------
*/

function show_error($message) {

    require "../includes/header.php";
    require "../includes/sidebar_sscontrol.php";

    echo '<div class="content"><div class="container-fluid">';
    echo '<div class="alert alert-danger mt-4">' . htmlspecialchars($message) . '</div>';
    echo '<a href="view.php" class="btn btn-secondary">Back to Entries</a>';
    echo '</div></div>';

    exit;

}


$id =
    isset($_GET['id'])
        ? (int)$_GET['id']
        : 0;


/*
|--------------------------------------------------------------------------
| TYPE - "plan" (SO based, sscontrol_entries) OR "manual" (sscontrol_manual_entries)
| DEFAULTS TO "plan" FOR BACKWARD COMPATIBILITY
|--------------------------------------------------------------------------
*/

$type =
    isset($_GET['type']) && $_GET['type'] === 'manual'
        ? 'manual'
        : 'plan';


if ($id <= 0) {
    header("Location: view.php");
    exit;
}


if ($type === 'manual') {

    $stmt = $conn->prepare("
        DELETE FROM sscontrol_manual_entries
        WHERE id = ?
    ");

} else {

    $stmt = $conn->prepare("
        DELETE FROM sscontrol_entries
        WHERE id = ?
    ");

}


if (!$stmt) {
    show_error("Prepare failed: " . $conn->error);
}


$stmt->bind_param(
    "i",
    $id
);


if (!$stmt->execute()) {
    show_error("Delete failed: " . $stmt->error);
}


$stmt->close();


header("Location: view.php?deleted=1");
exit;