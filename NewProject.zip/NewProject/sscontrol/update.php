<?php

require "../config.php";
require "../includes/auth_user.php";
require "../includes/security.php";


/*
|--------------------------------------------------------------------------
| ACCESS CONTROL
|--------------------------------------------------------------------------
*/

if (
    strtolower(trim($_SESSION['user_department']))
    !== 'sscontrol'
) {
    header("Location: ../login.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| ERROR FUNCTION
|--------------------------------------------------------------------------
*/

function show_error($message)
{

    require "../includes/header.php";
    require "../includes/sidebar_sscontrol.php";

    echo '
    <div class="content">
        <div class="container-fluid">

            <div class="alert alert-danger mt-4">
                ' . htmlspecialchars($message) . '
            </div>

            <a href="view.php" class="btn btn-secondary">
                Back to Entries
            </a>

        </div>
    </div>';

    exit;
}


/*
|--------------------------------------------------------------------------
| POST ONLY
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header("Location: view.php");

    exit;
}


/*
|--------------------------------------------------------------------------
| DATA
|--------------------------------------------------------------------------
*/

$id =
    (int)($_POST['id'] ?? 0);


$so_no_new =
    trim($_POST['so_no_new'] ?? '');


$panel_status =
    trim($_POST['panel_status'] ?? '');


$mb_status =
    trim($_POST['mb_status'] ?? '');


$cable_status =
    trim($_POST['cable_status'] ?? '');


$rating_plate_status =
    trim($_POST['rating_plate_status'] ?? '');


$remark =
    trim($_POST['remark'] ?? '');


/*
|--------------------------------------------------------------------------
| ALLOWED STATUS
|--------------------------------------------------------------------------
*/

$allowed_status = [
    'Yes',
    'No',
    'Not Applicable',
    'Other'
];


if ($id <= 0) {
    show_error("Invalid ID.");
}


if ($so_no_new === '') {
    show_error("SO No. is required.");
}


if (!in_array(
    $panel_status,
    $allowed_status,
    true
)) {
    show_error("Invalid Panel status.");
}


if (!in_array(
    $mb_status,
    $allowed_status,
    true
)) {
    show_error("Invalid MB status.");
}


if (!in_array(
    $cable_status,
    $allowed_status,
    true
)) {
    show_error("Invalid Cable status.");
}


if (!in_array(
    $rating_plate_status,
    $allowed_status,
    true
)) {
    show_error("Invalid Rating Plate status.");
}


/*
|--------------------------------------------------------------------------
| OTHER DESCRIPTIONS
|--------------------------------------------------------------------------
*/

$panel_other_desc = '';
$mb_other_desc = '';
$cable_other_desc = '';
$rating_plate_other_desc = '';


if ($panel_status === 'Other') {

    $panel_other_desc =
        trim($_POST['panel_other_desc'] ?? '');

    if ($panel_other_desc === '') {
        show_error(
            "Please enter Panel description."
        );
    }
}


if ($mb_status === 'Other') {

    $mb_other_desc =
        trim($_POST['mb_other_desc'] ?? '');

    if ($mb_other_desc === '') {
        show_error(
            "Please enter MB description."
        );
    }
}


if ($cable_status === 'Other') {

    $cable_other_desc =
        trim($_POST['cable_other_desc'] ?? '');

    if ($cable_other_desc === '') {
        show_error(
            "Please enter Cable description."
        );
    }
}


if ($rating_plate_status === 'Other') {

    $rating_plate_other_desc =
        trim(
            $_POST['rating_plate_other_desc']
            ?? ''
        );

    if ($rating_plate_other_desc === '') {
        show_error(
            "Please enter Rating Plate description."
        );
    }
}


/*
|--------------------------------------------------------------------------
| CHECK ENTRY
|--------------------------------------------------------------------------
*/

$check_stmt = $conn->prepare("
    SELECT id
    FROM sscontrol_entries
    WHERE id = ?
    LIMIT 1
");


if (!$check_stmt) {

    show_error(
        "Prepare failed: "
        . $conn->error
    );
}


$check_stmt->bind_param(
    "i",
    $id
);


$check_stmt->execute();


$check_result =
    $check_stmt->get_result();


if ($check_result->num_rows === 0) {

    $check_stmt->close();

    show_error(
        "Entry not found."
    );
}


$check_stmt->close();


/*
|--------------------------------------------------------------------------
| UPDATE
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    UPDATE sscontrol_entries

    SET

        so_no_new = ?,

        panel_status = ?,
        panel_other_desc = ?,

        mb_status = ?,
        mb_other_desc = ?,

        cable_status = ?,
        cable_other_desc = ?,

        rating_plate_status = ?,
        rating_plate_other_desc = ?,

        remark = ?

    WHERE id = ?
");


if (!$stmt) {

    show_error(
        "Update prepare failed: "
        . $conn->error
    );
}


$stmt->bind_param(
    "ssssssssssi",

    $so_no_new,

    $panel_status,
    $panel_other_desc,

    $mb_status,
    $mb_other_desc,

    $cable_status,
    $cable_other_desc,

    $rating_plate_status,
    $rating_plate_other_desc,

    $remark,

    $id
);


if (!$stmt->execute()) {

    show_error(
        "Update failed: "
        . $stmt->error
    );
}


$stmt->close();


header(
    "Location: view.php?updated=1"
);

exit;