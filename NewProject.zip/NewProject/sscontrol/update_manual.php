<?php

require "../config.php";
require "../includes/auth_user.php";
require "../includes/security.php";


/*
|--------------------------------------------------------------------------
| ACCESS CONTROL
|--------------------------------------------------------------------------
*/

if (
    strtolower(trim($_SESSION['user_department']))
    !== 'sscontrol'
) {
    header("Location: ../login.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| ERROR FUNCTION
|--------------------------------------------------------------------------
*/

function show_error($message)
{

    require "../includes/header.php";
    require "../includes/sidebar_sscontrol.php";

    echo '
    <div class="content">
        <div class="container-fluid">

            <div class="alert alert-danger mt-4">
                ' . htmlspecialchars($message) . '
            </div>

            <a href="view.php" class="btn btn-secondary">
                Back to Entries
            </a>

        </div>
    </div>';

    exit;
}


/*
|--------------------------------------------------------------------------
| POST ONLY
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {

    header("Location: view.php");

    exit;
}


/*
|--------------------------------------------------------------------------
| DATA
|--------------------------------------------------------------------------
*/

$id =
    (int)($_POST['id'] ?? 0);


$description =
    trim(
        $_POST['description'] ?? ''
    );


/*
|--------------------------------------------------------------------------
| VALIDATION
|--------------------------------------------------------------------------
*/

if ($id <= 0) {

    show_error(
        "Invalid manual entry ID."
    );
}


if ($description === '') {

    show_error(
        "Description is required."
    );
}


/*
|--------------------------------------------------------------------------
| CHECK ENTRY
|--------------------------------------------------------------------------
*/

$check_stmt = $conn->prepare("
    SELECT id
    FROM sscontrol_manual_entries
    WHERE id = ?
    LIMIT 1
");


if (!$check_stmt) {

    show_error(
        "Prepare failed: "
        . $conn->error
    );
}


$check_stmt->bind_param(
    "i",
    $id
);


$check_stmt->execute();


$check_result =
    $check_stmt->get_result();


if ($check_result->num_rows === 0) {

    $check_stmt->close();

    show_error(
        "Manual entry not found."
    );
}


$check_stmt->close();


/*
|--------------------------------------------------------------------------
| UPDATE
|--------------------------------------------------------------------------
*/

$stmt = $conn->prepare("
    UPDATE sscontrol_manual_entries

    SET
        description = ?

    WHERE id = ?
");


if (!$stmt) {

    show_error(
        "Update prepare failed: "
        . $conn->error
    );
}


$stmt->bind_param(
    "si",
    $description,
    $id
);


if (!$stmt->execute()) {

    show_error(
        "Update failed: "
        . $stmt->error
    );
}


$stmt->close();


/*
|--------------------------------------------------------------------------
| SUCCESS
|--------------------------------------------------------------------------
*/

header(
    "Location: view.php?manual_updated=1"
);

exit;