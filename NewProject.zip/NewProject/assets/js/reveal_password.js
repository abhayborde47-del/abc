/**
 * reveal_password.js
 * ---------------------------------------------------------------
 * Wires up ".js-view-password" buttons to the re-auth modal and the
 * includes/reveal_password.php AJAX endpoint.
 *
 * Expects each page to set, before loading this file:
 *   window.CSRF_TOKEN         - current CSRF token
 *   window.REVEAL_PASSWORD_URL - path to includes/reveal_password.php
 *
 * Each "View" button needs:
 *   class="js-view-password"
 *   data-type="user" | "admin"
 *   data-id="<row id>"
 * and should sit in a row that also contains an element with
 * class="js-password-cell" (where the revealed password is shown).
 */
(function () {
    let currentType = null;
    let currentTargetId = null;
    let currentCell = null;
    let currentButton = null;

    function showModal() {
        const el = document.getElementById('revealPasswordModal');
        if (!el || typeof bootstrap === 'undefined') return;
        document.getElementById('revealPasswordInput').value = '';
        document.getElementById('revealPasswordError').classList.add('d-none');
        new bootstrap.Modal(el).show();
    }

    function hideModal() {
        const el = document.getElementById('revealPasswordModal');
        const instance = bootstrap.Modal.getInstance(el);
        if (instance) instance.hide();
    }

    document.addEventListener('click', function (e) {
        const btn = e.target.closest('.js-view-password');
        if (!btn) return;

        currentType = btn.dataset.type;
        currentTargetId = btn.dataset.id;
        currentButton = btn;
        const row = btn.closest('tr');
        currentCell = row ? row.querySelector('.js-password-cell') : null;

        showModal();
    });

    document.addEventListener('DOMContentLoaded', function () {
        const confirmBtn = document.getElementById('revealPasswordConfirmBtn');
        if (!confirmBtn) return;

        confirmBtn.addEventListener('click', function () {
            const input = document.getElementById('revealPasswordInput');
            const errorBox = document.getElementById('revealPasswordError');
            const confirmPassword = input.value;

            errorBox.classList.add('d-none');

            if (!confirmPassword) {
                errorBox.textContent = 'Please enter your password.';
                errorBox.classList.remove('d-none');
                return;
            }

            confirmBtn.disabled = true;

            const formData = new FormData();
            formData.append('csrf_token', window.CSRF_TOKEN || '');
            formData.append('type', currentType || '');
            formData.append('target_id', currentTargetId || '');
            formData.append('confirm_password', confirmPassword);

            fetch(window.REVEAL_PASSWORD_URL, { method: 'POST', body: formData })
                .then(function (r) { return r.json(); })
                .then(function (data) {
                    confirmBtn.disabled = false;
                    if (data.ok) {
                        if (currentCell) {
                            currentCell.textContent = data.password;
                        }
                        if (currentButton) {
                            currentButton.remove();
                        }
                        hideModal();
                    } else {
                        errorBox.textContent = data.error || 'Something went wrong.';
                        errorBox.classList.remove('d-none');
                    }
                })
                .catch(function () {
                    confirmBtn.disabled = false;
                    errorBox.textContent = 'Network error. Please try again.';
                    errorBox.classList.remove('d-none');
                });
        });
    });
})();
