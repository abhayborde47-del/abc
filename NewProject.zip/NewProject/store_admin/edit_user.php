<?php
require "../config.php";
require "../includes/auth_admin_store.php";

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$msg = "";
$row = null;

if ($id <= 0) {
    header("Location: add_user.php");
    exit;
}

/* Handle update submission */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_user'])) {

    $email      = trim($_POST['email']);
    $department = trim($_POST['department']);
    $newPassword = trim($_POST['password']);

    $allowedDepartments = ['storeemp', 'supervisor'];
    if (!in_array($department, $allowedDepartments)) {
        $msg = "Invalid department selected.";
    } else {
        if ($newPassword !== '') {
            // Password field filled in -> update password too
            $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("UPDATE users SET email = ?, password = ?, department = ? WHERE id = ?");
            $stmt->bind_param("sssi", $email, $hashedPassword, $department, $id);
        } else {
            // Leave password unchanged
            $stmt = $conn->prepare("UPDATE users SET email = ?, department = ? WHERE id = ?");
            $stmt->bind_param("ssi", $email, $department, $id);
        }

        if ($stmt->execute()) {
            header("Location: add_user.php");
            exit;
        } else {
            $msg = "Error updating user: " . $conn->error;
        }
        $stmt->close();
    }
}

/* Fetch current record to prefill the form */
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$stmt->close();

if (!$row) {
    header("Location: add_user.php");
    exit;
}
?>
<?php include "../includes/header.php"; ?>

  <?php include "../includes/storesidebar_admin.php"; ?>

  <!-- Main content -->
  <div class="flex-grow-1 p-4">
    <h3>Edit User</h3>

    <?php if (!empty($msg)): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <form method="POST" class="card p-4 shadow-sm" style="max-width: 500px;">

      <div class="mb-3">
        <label class="form-label">Email</label>
        <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($row['email']) ?>" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Password <small class="text-muted">(leave blank to keep current password)</small></label>
        <input type="password" name="password" class="form-control" placeholder="Enter new password to change it">
      </div>

      <div class="mb-3">
        <label class="form-label">Department</label>
        <select name="department" class="form-select" required>
          <option value="storeemp" <?= $row['department'] === 'storeemp' ? 'selected' : '' ?>>Store Employee</option>
          <option value="supervisor" <?= $row['department'] === 'supervisor' ? 'selected' : '' ?>>Supervisor</option>
        </select>
      </div>

      <button type="submit" name="update_user" class="btn btn-primary">Update</button>
      <a href="add_user.php" class="btn btn-secondary">Cancel</a>

    </form>
  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarToggle')?.addEventListener('click', function () {
    document.getElementById('sidebar').classList.toggle('d-none');
});
</script>
</body>
</html>