<?php
require "../config.php";
require "../includes/auth_admin_store.php";

$redirect = $_POST['redirect'] ?? '../store/view_shortage.php';
$planIds  = $_POST['plan_ids'] ?? [];
$fullMap  = $_POST['full'] ?? [];          // full[$id] = '1' when checkbox checked
$receivedMap = $_POST['received_qty'] ?? []; // received_qty[$id] = qty received THIS submission

// Add Shortage (admin) now saves each row instantly via fetch() instead of a
// page form submit. When ajax=1 is sent we respond with JSON for the one
// row involved instead of doing a redirect.
$isAjax = ($_POST['ajax'] ?? '') === '1';
$ajaxResult = null;

// FIX: this page is guarded by auth_admin.php, which stores the logged-in
// person's email as $_SESSION['admin_email'] (login.php sets admin_email /
// admin_id / admin_type / store_id for admins, and a separate user_email /
// user_id / user_department set for the non-admin "user" role) - so
// admin_email is the correct key here, not user_email.
$currentUser = $_SESSION['admin_email'] ?? null;
if (!$currentUser) {
    if ($isAjax) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'error' => 'Session expired. Please refresh and log in again.']);
        exit;
    } else {
        header("Location: ../login.php");
        exit;
    }
}

if (!empty($planIds)) {

    // Pull totals for every submitted plan row in one go.
    $placeholders = implode(',', array_fill(0, count($planIds), '?'));
    $types        = str_repeat('i', count($planIds));

    $totalsStmt = $conn->prepare("SELECT id, total FROM plansstore WHERE id IN ($placeholders)");
    $totalsStmt->bind_param($types, ...$planIds);
    $totalsStmt->execute();
    $totalsRes = $totalsStmt->get_result();
    $totals = [];
    while ($row = $totalsRes->fetch_assoc()) {
        $totals[(int)$row['id']] = (int)$row['total'];
    }
    $totalsStmt->close();

    // Pull any existing plan_status rows so we know the CURRENT remaining shortage
    // before applying this submission's received qty.
    $existingStmt = $conn->prepare("SELECT plan_id, status, shortage_qty FROM plan_status WHERE plan_id IN ($placeholders)");
    $existingStmt->bind_param($types, ...$planIds);
    $existingStmt->execute();
    $existingRes = $existingStmt->get_result();
    $existing = [];
    while ($row = $existingRes->fetch_assoc()) {
        $existing[(int)$row['plan_id']] = $row;
    }
    $existingStmt->close();

    // created_by is only ever written on the initial INSERT (it is left out
    // of the ON DUPLICATE KEY UPDATE clause below), so it always reflects
    // whoever first saved the row. updated_by is refreshed on every save.
    $upsertStmt = $conn->prepare("
        INSERT INTO plan_status (plan_id, status, shortage_qty, created_by, updated_by, updated_at)
        VALUES (?, ?, ?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE
            status = VALUES(status),
            shortage_qty = VALUES(shortage_qty),
            updated_by = VALUES(updated_by),
            updated_at = NOW()
    ");

    foreach ($planIds as $id) {
        $id = (int)$id;
        if (!isset($totals[$id])) {
            if ($isAjax) {
                $ajaxResult = ['success' => false, 'error' => 'Unknown plan id.'];
            }
            continue; // unknown plan id, skip
        }

        $total = $totals[$id];
        $markedFull = isset($fullMap[$id]) && $fullMap[$id] === '1';

        if ($markedFull) {
            $status = 'full';
            $newShortage = 0;

        } else {
            // Current remaining shortage before this submission.
            // If there's no plan_status row yet, nothing has been received before,
            // so the starting shortage is the full total.
            $currentShortage = isset($existing[$id]) ? (int)$existing[$id]['shortage_qty'] : $total;

            $received = isset($receivedMap[$id]) ? (int)trim($receivedMap[$id]) : 0;
            $received = max(0, $received);

            $newShortage = $currentShortage - $received;

            if ($newShortage <= 0) {
                $status = 'full';
                $newShortage = 0;
            } else {
                $status = 'shortage';
            }
        }

        $upsertStmt->bind_param("isiss", $id, $status, $newShortage, $currentUser, $currentUser);
        $ok = $upsertStmt->execute();

        // FIX: previously the script assumed success even if execute() failed
        // (e.g. DB constraint error), so the browser was told "success" was
        // never actually checked here. Now we surface the real DB error.
        if ($isAjax) {
            if ($ok) {
                $ajaxResult = [
                    'success'      => true,
                    'plan_id'      => $id,
                    'status'       => $status,          // 'full' or 'shortage'
                    'shortage_qty' => $newShortage,
                    'total'        => $total,
                    'updated_by'   => $currentUser,
                ];
            } else {
                $ajaxResult = [
                    'success' => false,
                    'plan_id' => $id,
                    'error'   => 'Database error: ' . $upsertStmt->error,
                ];
            }
        }
    }

    $upsertStmt->close();
} elseif ($isAjax) {
    $ajaxResult = ['success' => false, 'error' => 'No plan_ids submitted.'];
}

if ($isAjax) {
    header('Content-Type: application/json');
    echo json_encode($ajaxResult ?? ['success' => false, 'error' => 'No matching plan row.']);
    exit;
}

header("Location: " . $redirect);
exit;