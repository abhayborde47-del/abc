<?php
require "../config.php"; // config.php already calls session_start()

// --- Auth guard: only logged-in store admins allowed here ---
if (!isset($_SESSION['admin_email']) || !in_array($_SESSION['admin_type'] ?? '', ['store','owner'], true)) {
    header("Location: ../index.php");
    exit;
}

$kitNoSearch    = trim($_GET['kit_no'] ?? '');
$poSearch       = trim($_GET['production_order'] ?? '');
$results        = [];
$resultMode     = '';   // 'kitno' | 'po' | 'none' | ''
$searchedKitNo  = '';
$searchTermUsed = '';

// --- Search by KITNO: show ALL rows for that KITNO ---
if ($kitNoSearch !== '') {
    $searchTermUsed = $kitNoSearch;

    $stmt = $conn->prepare("SELECT * FROM plansstore WHERE kit_no = ? ORDER BY id ASC");
    $stmt->bind_param("s", $kitNoSearch);
    $stmt->execute();
    $res = $stmt->get_result();

    while ($r = $res->fetch_assoc()) {
        $results[] = $r;
    }
    $stmt->close();

    $searchedKitNo = $kitNoSearch;
    $resultMode = !empty($results) ? 'kitno' : 'none';

// --- Search by Production Order: find its KITNO, then show ALL rows for that KITNO ---
} elseif ($poSearch !== '') {
    $searchTermUsed = $poSearch;

    $stmt = $conn->prepare("SELECT kit_no FROM plansstore WHERE production_order = ? LIMIT 1");
    $stmt->bind_param("s", $poSearch);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $searchedKitNo = $row['kit_no'];
        $stmt->close();

        $stmt2 = $conn->prepare("SELECT * FROM plansstore WHERE kit_no = ? ORDER BY id ASC");
        $stmt2->bind_param("s", $searchedKitNo);
        $stmt2->execute();
        $res2 = $stmt2->get_result();
        while ($r = $res2->fetch_assoc()) {
            $results[] = $r;
        }
        $stmt2->close();

        $resultMode = 'po';
    } else {
        $stmt->close();
        $resultMode = 'none';
    }
}
?>
<?php include "../includes/header.php"; ?>

  <?php include "../includes/storesidebar_admin.php"; ?>

  <!-- Main content -->
  <div class="flex-grow-1 p-4">
    <h3>Search Plan</h3>

    <div class="row mb-4">
      <!-- KITNO search -->
      <div class="col-md-6">
        <form action="search_plan.php" method="GET" class="d-flex">
          <input
            type="text"
            name="kit_no"
            class="form-control me-2"
            placeholder="Search by KITNO"
            value="<?= htmlspecialchars($kitNoSearch) ?>"
            required
          >
          <button type="submit" class="btn btn-primary text-nowrap">Search KITNO</button>
        </form>
      </div>

      <!-- Production Order search -->
      <div class="col-md-6 mt-3 mt-md-0">
        <form action="search_plan.php" method="GET" class="d-flex">
          <input
            type="text"
            name="production_order"
            class="form-control me-2"
            placeholder="Search by Production Order"
            value="<?= htmlspecialchars($poSearch) ?>"
            required
          >
          <button type="submit" class="btn btn-success text-nowrap">Search Order</button>
        </form>
      </div>
    </div>

    <?php if ($resultMode === 'none'): ?>
      <div class="alert alert-warning">
        No records found for "<?= htmlspecialchars($searchTermUsed) ?>".
      </div>

    <?php elseif ($resultMode === 'kitno'): ?>
      <div class="alert alert-info">
        Showing all info for KITNO <strong><?= htmlspecialchars($searchedKitNo) ?></strong>.
      </div>

    <?php elseif ($resultMode === 'po'): ?>
      <div class="alert alert-info">
        Production Order matched — showing all info for KITNO
        <strong><?= htmlspecialchars($searchedKitNo) ?></strong>.
      </div>
    <?php endif; ?>

    <?php if (!empty($results)): ?>
      <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle">
          <thead class="table-success">
            <tr>
              <th>KITNO</th>
              <th>Rating</th>
              <th>Kit Size</th>
              <th>Date</th>
              <th>Variant Details</th>
              <th>Production Order</th>
              <th>Material</th>
              <th>Material Description</th>
              <th>Total</th>
              <th width="150">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($results as $r): ?>
              <tr>
                <td><?= htmlspecialchars($r['kit_no']) ?></td>
                <td><?= htmlspecialchars($r['rating']) ?></td>
                <td><?= htmlspecialchars($r['kit_size']) ?></td>
                <td><?= htmlspecialchars($r['plan_date']) ?></td>
                <td><?= htmlspecialchars($r['variant_details']) ?></td>
                <td><?= htmlspecialchars($r['production_order']) ?></td>
                <td><?= htmlspecialchars($r['material']) ?></td>
                <td><?= htmlspecialchars($r['material_description']) ?></td>
                <td><?= htmlspecialchars($r['total']) ?></td>
                <td>
                  <a href="edit_plan.php?id=<?= $r['id'] ?>" class="btn btn-warning btn-sm">Edit</a>
                  <a href="delete_plan.php?id=<?= $r['id'] ?>"
                     class="btn btn-danger btn-sm"
                     onclick="return confirm('Are you sure you want to delete this row?');">
                    Delete
                  </a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>

  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarToggle')?.addEventListener('click', function () {
    document.getElementById('sidebar').classList.toggle('d-none');
});
</script>
</body>
</html>