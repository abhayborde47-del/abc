<?php
require "../config.php";
require "../includes/auth_admin_store.php";

$view = $_GET['view'] ?? 'shortage';
if (!in_array($view, ['shortage', 'full'])) {
    $view = 'shortage';
}

// CHANGED: view_shortage.php's "Download Excel" link now passes the current
// kit_no / production_order search straight through, so a filtered view
// downloads exactly what's on screen with no extra step. The standalone
// filter_type/filter_value form (kit_no / production_order / month) still
// works as a fallback for visiting this page directly.
$kitNoSearch = trim($_GET['kit_no'] ?? '');
$poSearch    = trim($_GET['production_order'] ?? '');

$filterType  = $_GET['filter_type'] ?? '';
$filterValue = trim($_GET['filter_value'] ?? '');
$allowedFilterTypes = ['kit_no', 'production_order', 'month'];

$kitFilter   = '';
$monthFilter = '';
$searchError = '';

// Production order (from either source) is resolved to its KITNO, then every
// remaining row for that KITNO downloads - matching view_shortage.php's
// behaviour, instead of the old exact-match-one-row filter.
function resolveProductionOrder($conn, $po) {
    $stmt = $conn->prepare("SELECT kit_no FROM plansstore WHERE production_order = ? LIMIT 1");
    $stmt->bind_param("s", $po);
    $stmt->execute();
    $res = $stmt->get_result();
    $kit = ($res && $res->num_rows > 0) ? $res->fetch_assoc()['kit_no'] : null;
    $stmt->close();
    return $kit;
}

if ($kitNoSearch !== '') {
    $kitFilter = $kitNoSearch;
} elseif ($poSearch !== '') {
    $resolved = resolveProductionOrder($conn, $poSearch);
    if ($resolved !== null) {
        $kitFilter = $resolved;
    } else {
        $searchError = 'No record found for Production Order "' . $poSearch . '".';
    }
} elseif (in_array($filterType, $allowedFilterTypes, true) && $filterValue !== '') {
    if ($filterType === 'kit_no') {
        $kitFilter = $filterValue;
    } elseif ($filterType === 'production_order') {
        $resolved = resolveProductionOrder($conn, $filterValue);
        if ($resolved !== null) {
            $kitFilter = $resolved;
        } else {
            $searchError = 'No record found for Production Order "' . $filterValue . '".';
        }
    } else { // month
        $monthFilter = $filterValue;
    }
}

$hasFilter = $searchError === '' && ($kitFilter !== '' || $monthFilter !== '');

// ---------------------------------------------------------------
// No usable filter yet -> show the filter-selection form (also used to
// surface $searchError if a passed-in search didn't resolve to anything).
// ---------------------------------------------------------------
if (!$hasFilter) {
?>
<?php include "../includes/header.php"; ?>

  <?php include "../includes/storesidebar_admin.php"; ?>

  <div class="flex-grow-1 p-4">
    <h3>Download <?= $view === 'shortage' ? 'Shortage' : 'Full' ?> Report</h3>

    <?php if ($searchError !== ''): ?>
      <div class="alert alert-warning"><?= htmlspecialchars($searchError) ?></div>
    <?php endif; ?>

    <form action="download_shortage.php" method="GET" class="row g-3" style="max-width:500px;">
      <input type="hidden" name="view" value="<?= htmlspecialchars($view) ?>">

      <div class="col-12">
        <label class="form-label">Filter by</label>
        <select name="filter_type" id="filter_type" class="form-select" required>
          <option value="">-- Select --</option>
          <option value="kit_no">KITNO</option>
          <option value="production_order">Production Order</option>
          <option value="month">Month</option>
        </select>
      </div>

      <div class="col-12">
        <label class="form-label" id="filter_value_label">Value</label>
        <input type="text" name="filter_value" id="filter_value" class="form-control"
               placeholder="Enter KITNO or Production Order" required>
      </div>

      <div class="col-12">
        <button type="submit" class="btn btn-primary">Download Excel</button>
      </div>
    </form>
  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarToggle')?.addEventListener('click', function () {
    document.getElementById('sidebar').classList.toggle('d-none');
});

// Swap the value field to a month picker when "Month" is selected.
const filterType = document.getElementById('filter_type');
const valueLabel = document.getElementById('filter_value_label');
let valueInput = document.getElementById('filter_value');

filterType.addEventListener('change', function () {
    const wantsMonth = filterType.value === 'month';
    const newInput = document.createElement('input');
    newInput.name = 'filter_value';
    newInput.id = 'filter_value';
    newInput.className = 'form-control';
    newInput.required = true;

    if (wantsMonth) {
        newInput.type = 'month';
        valueLabel.textContent = 'Month';
    } else {
        newInput.type = 'text';
        newInput.placeholder = filterType.value === 'kit_no'
            ? 'Enter KITNO'
            : (filterType.value === 'production_order' ? 'Enter Production Order' : 'Enter value');
        valueLabel.textContent = 'Value';
    }

    valueInput.replaceWith(newInput);
    valueInput = newInput;
});
</script>
</body>
</html>
<?php
    exit;
}

// ---------------------------------------------------------------
// Filter resolved -> build the query and stream the Excel file.
// ---------------------------------------------------------------
if ($view === 'shortage') {
    $sql = "
        SELECT p.*, COALESCE(ps.status,'shortage') AS status, ps.shortage_qty, ps.created_by, ps.updated_by
        FROM plansstore p
        LEFT JOIN plan_status ps ON ps.plan_id = p.id
        WHERE COALESCE(ps.status,'shortage') = 'shortage'
    ";
} else {
    $sql = "
        SELECT p.*, ps.status, ps.shortage_qty, ps.created_by, ps.updated_by
        FROM plansstore p
        INNER JOIN plan_status ps ON ps.plan_id = p.id
        WHERE ps.status = 'full'
    ";
}

if ($kitFilter !== '') {
    $sql .= " AND p.kit_no = ?";
    $bindValue = $kitFilter;
    $labelType = 'kit_no';
    $labelValue = $kitFilter;
} else {
    // filterValue comes from <input type="month"> as YYYY-MM
    $sql .= " AND DATE_FORMAT(p.plan_date, '%Y-%m') = ?";
    $bindValue = $monthFilter;
    $labelType = 'month';
    $labelValue = $monthFilter;
}

$sql .= " ORDER BY p.id ASC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $bindValue);
$stmt->execute();
$result = $stmt->get_result();

$safeValue = preg_replace('/[^A-Za-z0-9_-]/', '_', $labelValue);
$filename = ($view === 'shortage' ? 'shortage_report' : 'full_report') . '_' . $labelType . '_' . $safeValue . '.xls';

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=\"$filename\"");
?>
<table border="1">
  <tr>
    <th>KITNO</th>
    <th>Rating</th>
    <th>Kit Size</th>
    <th>Date</th>
    <th>Variant Details</th>
    <th>Production Order</th>
    <th>Material</th>
    <th>Material Description</th>
    <th>Total</th>
    <?php if ($view === 'shortage'): ?><th>Shortage Qty</th><?php endif; ?>
    <th>Created By</th>
    <th>Updated By</th>
  </tr>
  <?php while ($r = $result->fetch_assoc()): ?>
    <tr>
      <td><?= htmlspecialchars($r['kit_no']) ?></td>
      <td><?= htmlspecialchars($r['rating']) ?></td>
      <td><?= htmlspecialchars($r['kit_size']) ?></td>
      <td><?= htmlspecialchars($r['plan_date']) ?></td>
      <td><?= htmlspecialchars($r['variant_details']) ?></td>
      <td><?= htmlspecialchars($r['production_order']) ?></td>
      <td><?= htmlspecialchars($r['material']) ?></td>
      <td><?= htmlspecialchars($r['material_description']) ?></td>
      <td><?= htmlspecialchars($r['total']) ?></td>
      <?php if ($view === 'shortage'): ?>
        <td><?= htmlspecialchars($r['shortage_qty'] ?? '') ?></td>
      <?php endif; ?>
      <td><?= htmlspecialchars($r['created_by'] ?? '') ?></td>
      <td><?= htmlspecialchars($r['updated_by'] ?? '') ?></td>
    </tr>
  <?php endwhile; ?>
</table>
<?php $stmt->close(); ?>