<?php
require "../config.php"; // config.php already calls session_start()
require "../lib/xlsx_reader_plan.php"; // dedicated reader for plan uploads

// --- Auth guard: only logged-in store admins allowed here ---
if (!isset($_SESSION['admin_email']) || !in_array($_SESSION['admin_type'] ?? '', ['store','owner'], true)) {
    header("Location: ../index.php");
    exit;
}

$message = "";
$messageType = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['plan_file'])) {

    $file = $_FILES['plan_file'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $message = "Upload failed. Please try again.";
        $messageType = "danger";
    } else {
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

        if ($ext !== 'xlsx') {
            $message = "Only .xlsx files are supported (please save .xls files as .xlsx first).";
            $messageType = "danger";
        } else {
            try {
                $rows = readXLSXPlan($file['tmp_name']);

                if (empty($rows)) {
                    throw new Exception("No data found in the uploaded file.");
                }

                $conn->begin_transaction();

                $stmt = $conn->prepare("
                    INSERT INTO plansstore
                        (kit_no, rating, kit_size, plan_date, variant_details, production_order, material, material_description, total, uploaded_by)
                    VALUES
                        (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");

                if (!$stmt) {
                    throw new Exception("Database prepare failed: " . $conn->error);
                }

                $insertedCount = 0;

                foreach ($rows as $rowIndex => $row) {
                    if ($rowIndex === 0) continue; // skip header row (first row in the file)

                    // Column order: A=0 KITNO, B=1 RATING, C=2 Kit Size, D=3 Date,
                    // E=4 Variant Details, F=5 Production Order, G=6 Material,
                    // H=7 Material Description, I=8 Total
                    $kitNo               = trim($row[0] ?? '');
                    $rating              = trim($row[1] ?? '');
                    $kitSize             = trim($row[2] ?? '');
                    $rawDate             = trim($row[3] ?? '');
                    $variantDetails      = trim($row[4] ?? '');
                    $productionOrder     = trim($row[5] ?? '');
                    $material            = trim($row[6] ?? '');
                    $materialDescription = trim($row[7] ?? '');
                    $total               = trim($row[8] ?? '');

                    // Skip completely empty rows
                    if ($kitNo === '' && $rating === '' && $kitSize === '') continue;

                    // Date may arrive as an Excel serial number (e.g. 46601) or text like "18.08.2026"
                    $planDate = null;
                    if ($rawDate !== '') {
                        if (is_numeric($rawDate)) {
                            $planDate = excelDateToYmdPlan($rawDate);
                        } else {
                            $dateObj = DateTime::createFromFormat('d.m.Y', $rawDate);
                            $planDate = $dateObj ? $dateObj->format('Y-m-d') : date('Y-m-d');
                        }
                    }

                    $kitSizeInt = $kitSize !== '' ? (int)$kitSize : 0;
                    $totalInt   = $total !== '' ? (int)$total : 0;
                    $uploadedBy = $_SESSION['admin_email'];

                    $stmt->bind_param(
                        "ssisssssis",
                        $kitNo,
                        $rating,
                        $kitSizeInt,
                        $planDate,
                        $variantDetails,
                        $productionOrder,
                        $material,
                        $materialDescription,
                        $totalInt,
                        $uploadedBy
                    );
                    $stmt->execute();

                    $insertedCount++;
                }

                $stmt->close();
                $conn->commit();

                $message = "$insertedCount plan(s) uploaded successfully.";
                $messageType = "success";

            } catch (Exception $e) {
                if (isset($conn)) {
                    $conn->rollback();
                }
                $message = "Error processing file: " . $e->getMessage();
                $messageType = "danger";
            }
        }
    }
}
?>
<?php include "../includes/header.php"; ?>

  <?php include "../includes/storesidebar_admin.php"; ?>

  <!-- Main content -->
  <div class="flex-grow-1 p-4">
    <h3>Add Plan</h3>

    <?php if ($message): ?>
      <div class="alert alert-<?= $messageType ?>" role="alert">
        <?= htmlspecialchars($message) ?>
      </div>
    <?php endif; ?>

    <form action="upload_plan.php" method="POST" enctype="multipart/form-data" class="card p-4 shadow-sm" style="max-width: 500px;">
      <div class="mb-3">
        <label for="plan_file" class="form-label">Select Excel File (.xlsx)</label>
        <input type="file" class="form-control" id="plan_file" name="plan_file" accept=".xlsx" required>
      </div>
      <button type="submit" class="btn btn-primary">Upload Plan</button>
    </form>

    <small class="text-muted d-block mt-3">
      Expected columns: KITNO, RATING, Kit Size, Date, Variant Details, Production Order, Material, Material Description, Total.
    </small>
  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarToggle')?.addEventListener('click', function () {
    document.getElementById('sidebar').classList.toggle('d-none');
});
</script>
</body>
</html>