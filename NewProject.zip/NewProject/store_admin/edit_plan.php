<?php
require "../config.php";

if (!isset($_SESSION['admin_email']) || !in_array($_SESSION['admin_type'] ?? '', ['store','owner'], true)) {
    header("Location: ../index.php");
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$msg = "";
$row = null;

if ($id <= 0) {
    header("Location: search_plan.php");
    exit;
}

/* Handle update submission */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_plan'])) {

    $kitNo               = trim($_POST['kit_no']);
    $rating              = trim($_POST['rating']);
    $kitSize             = (int) $_POST['kit_size'];
    $planDate            = trim($_POST['plan_date']);
    $variantDetails      = trim($_POST['variant_details']);
    $productionOrder     = trim($_POST['production_order']);
    $material            = trim($_POST['material']);
    $materialDescription = trim($_POST['material_description']);
    $total               = (int) $_POST['total'];

    $stmt = $conn->prepare("
        UPDATE plansstore SET
            kit_no = ?, rating = ?, kit_size = ?, plan_date = ?, variant_details = ?,
            production_order = ?, material = ?, material_description = ?, total = ?
        WHERE id = ?
    ");
    $stmt->bind_param(
        "ssissssiii",
        $kitNo, $rating, $kitSize, $planDate, $variantDetails,
        $productionOrder, $material, $materialDescription, $total, $id
    );

    if ($stmt->execute()) {
        header("Location: search_plan.php?kit_no=" . urlencode($kitNo));
        exit;
    } else {
        $msg = "Error updating record: " . $conn->error;
    }
    $stmt->close();
}

/* Fetch current record to prefill the form */
$stmt = $conn->prepare("SELECT * FROM plansstore WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$res = $stmt->get_result();
$row = $res->fetch_assoc();
$stmt->close();

if (!$row) {
    header("Location: search_plan.php");
    exit;
}
?>
<?php include "../includes/header.php"; ?>

  <?php include "../includes/storesidebar_admin.php"; ?>

  <!-- Main content -->
  <div class="flex-grow-1 p-4">
    <h3>Edit Plan</h3>

    <?php if (!empty($msg)): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>

    <form method="POST" class="card p-4 shadow-sm" style="max-width: 700px;">
      <div class="row">
        <div class="col-md-6 mb-3">
          <label class="form-label">KITNO</label>
          <input type="text" name="kit_no" class="form-control" value="<?= htmlspecialchars($row['kit_no']) ?>" required>
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label">Rating</label>
          <input type="text" name="rating" class="form-control" value="<?= htmlspecialchars($row['rating']) ?>" required>
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label">Kit Size</label>
          <input type="number" name="kit_size" class="form-control" value="<?= htmlspecialchars($row['kit_size']) ?>" required>
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label">Date</label>
          <input type="date" name="plan_date" class="form-control" value="<?= htmlspecialchars($row['plan_date']) ?>" required>
        </div>
        <div class="col-md-12 mb-3">
          <label class="form-label">Variant Details</label>
          <input type="text" name="variant_details" class="form-control" value="<?= htmlspecialchars($row['variant_details']) ?>">
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label">Production Order</label>
          <input type="text" name="production_order" class="form-control" value="<?= htmlspecialchars($row['production_order']) ?>">
        </div>
        <div class="col-md-6 mb-3">
          <label class="form-label">Material</label>
          <input type="text" name="material" class="form-control" value="<?= htmlspecialchars($row['material']) ?>" required>
        </div>
        <div class="col-md-8 mb-3">
          <label class="form-label">Material Description</label>
          <input type="text" name="material_description" class="form-control" value="<?= htmlspecialchars($row['material_description']) ?>" required>
        </div>
        <div class="col-md-4 mb-3">
          <label class="form-label">Total</label>
          <input type="number" name="total" class="form-control" value="<?= htmlspecialchars($row['total']) ?>" required>
        </div>
      </div>

      <button type="submit" name="update_plan" class="btn btn-primary">Update</button>
      <a href="search_plan.php?kit_no=<?= urlencode($row['kit_no']) ?>" class="btn btn-secondary">Cancel</a>
    </form>
  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarToggle')?.addEventListener('click', function () {
    document.getElementById('sidebar').classList.toggle('d-none');
});
</script>
</body>
</html>