<?php
require "../config.php";

if (!isset($_SESSION['admin_email']) || !in_array($_SESSION['admin_type'] ?? '', ['store','owner'], true)) {
    header("Location: ../index.php");
    exit;
}

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id > 0) {
    $stmt = $conn->prepare("DELETE FROM plansstore WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}

// Redirect back to where the user came from, preserving their search
$redirect = $_SERVER['HTTP_REFERER'] ?? 'search_plan.php';
header("Location: " . $redirect);
exit;