<?php
require "../config.php";
require "../includes/auth_admin_store.php";

$msg = "";

/* Add User */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_user'])) {

    $email = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $department = trim($_POST['department']);

    // Restrict department to allowed values only, even if form is tampered with
    $allowedDepartments = ['storeemp', 'supervisor'];
    if (!in_array($department, $allowedDepartments)) {
        $msg = "Invalid department selected.";
    } else {
        $stmt = $conn->prepare("INSERT INTO users (email, password, department) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $email, $password, $department);

        if ($stmt->execute()) {
            $msg = "User added successfully";
        } else {
            $msg = "Error: " . $conn->error;
        }
    }
}

/* Get Users - only storeemp and supervisor */
$users = $conn->query("
    SELECT id, email, department, created_at
    FROM users
    WHERE department IN ('storeemp', 'supervisor')
    ORDER BY id DESC
");
?>

<?php include "../includes/header.php"; ?>

  <?php include "../includes/storesidebar_admin.php"; ?>

  <!-- Main content -->
  <div class="flex-grow-1 p-4">

        <h3 class="mb-3">Add User</h3>

        <?php if (!empty($msg)) : ?>
            <div class="alert alert-info">
                <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <!-- Add User Form -->
        <div class="card mb-4">
            <div class="card-body">

                <form method="POST">

                    <div class="row">

                        <div class="col-md-4 mb-3">
                            <label class="form-label">Email</label>
                            <input type="email"
                                   name="email"
                                   class="form-control"
                                   required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label">Password</label>
                            <input type="password"
                                   name="password"
                                   class="form-control"
                                   required>
                        </div>

                        <div class="col-md-4 mb-3">
                            <label class="form-label">Department</label>
                            <select name="department" class="form-select" required>
                                <option value="" disabled selected>Select department</option>
                                <option value="storeemp">Store Employee</option>
                                <option value="supervisor">Supervisor</option>
                            </select>
                        </div>

                    </div>

                    <button type="submit"
                            name="add_user"
                            class="btn btn-success">
                        Add User
                    </button>

                </form>

            </div>
        </div>

        <!-- User List -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">All Users (Admin Only)</h5>
            </div>

            <div class="card-body">

                <div class="table-responsive">

                    <table class="table table-bordered table-hover">

                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Email</th>
                                <th>Password</th>
                                <th>Department</th>
                                <th>Created At</th>
                                <th width="180">Action</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php if ($users && $users->num_rows > 0) : ?>

                            <?php while ($u = $users->fetch_assoc()) : ?>

                                <tr>

                                    <td><?= $u['id']; ?></td>

                                    <td>
                                        <?= htmlspecialchars($u['email']); ?>
                                    </td>

                                    <td>
                                        <span class="text-muted">
                                            Encrypted (bcrypt)
                                        </span>
                                    </td>

                                    <td>
                                        <?php
                                        $deptLabels = [
                                            'storeemp' => 'Store Employee',
                                            'supervisor' => 'Supervisor'
                                        ];
                                        echo htmlspecialchars($deptLabels[$u['department']] ?? $u['department']);
                                        ?>
                                    </td>

                                    <td>
                                        <?= htmlspecialchars($u['created_at']); ?>
                                    </td>

                                    <td>

                                        <a href="edit_user.php?id=<?= $u['id']; ?>"
                                           class="btn btn-warning btn-sm">
                                            Edit
                                        </a>

                                        <a href="delete_user.php?id=<?= $u['id']; ?>"
                                           class="btn btn-danger btn-sm"
                                           onclick="return confirm('Are you sure you want to delete this user?');">
                                            Delete
                                        </a>

                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        <?php else : ?>

                            <tr>
                                <td colspan="6" class="text-center">
                                    No Users Found
                                </td>
                            </tr>

                        <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </div>
        </div>

  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarToggle')?.addEventListener('click', function () {
    document.getElementById('sidebar').classList.toggle('d-none');
});
</script>
</body>
</html>