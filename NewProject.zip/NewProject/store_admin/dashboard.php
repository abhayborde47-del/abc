<?php
require "../config.php"; // config.php already calls session_start()
require "../includes/security.php";

// --- Auth guard: only logged-in store admins allowed here ---
if (!isset($_SESSION['admin_email']) || !in_array($_SESSION['admin_type'] ?? '', ['store','owner'], true)) {
    header("Location: ../index.php");
    exit;
}

$msg = "";
$msgType = "info";

/* Make sure the table exists even on a fresh install */
$conn->query("
    CREATE TABLE IF NOT EXISTS queries (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_email VARCHAR(150) NOT NULL,
        subject VARCHAR(200) NOT NULL,
        message TEXT NOT NULL,
        status ENUM('Open','In Progress','Resolved') NOT NULL DEFAULT 'Open',
        admin_reply TEXT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_user_email (user_email),
        INDEX idx_status (status)
    )
");


/* =========================================================
   REPLY / UPDATE STATUS
========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['respond'])) {

    csrf_verify($_POST['csrf_token'] ?? '');

    $id          = (int)($_POST['id'] ?? 0);
    $status      = $_POST['status'] ?? 'Open';
    $admin_reply = trim($_POST['admin_reply'] ?? '');

    $allowedStatus = ['Open', 'In Progress', 'Resolved'];
    if (!in_array($status, $allowedStatus, true)) {
        $status = 'Open';
    }

    // Only allow responding to queries that actually belong to a
    // store user (supervisor / storeemp), not AIS users.
    $stmt = $conn->prepare(
        "UPDATE queries q
         JOIN users u ON u.email = q.user_email
         SET q.status = ?, q.admin_reply = ?
         WHERE q.id = ? AND u.department IN ('supervisor', 'storeemp')"
    );
    $stmt->bind_param("ssi", $status, $admin_reply, $id);

    if ($stmt->execute()) {
        $msg = "Query updated.";
        $msgType = "success";
    } else {
        $msg = "Error: " . htmlspecialchars($conn->error);
        $msgType = "danger";
    }
}


/* =========================================================
   DELETE QUERY
========================================================= */
if (isset($_GET['delete'])) {

    csrf_verify($_GET['csrf_token'] ?? '');

    $id = (int)$_GET['delete'];

    $stmt = $conn->prepare(
        "DELETE q FROM queries q
         JOIN users u ON u.email = q.user_email
         WHERE q.id = ? AND u.department IN ('supervisor', 'storeemp')"
    );
    $stmt->bind_param("i", $id);
    $stmt->execute();

    header("Location: dashboard.php?deleted=1");
    exit;
}

if (isset($_GET['deleted'])) {
    $msg = "Query deleted.";
    $msgType = "success";
}


/* =========================================================
   FILTER + FETCH
   Only queries submitted by store users - supervisor or storeemp -
   are shown here, never AIS (main admin) queries.
========================================================= */
$statusFilter = $_GET['status'] ?? '';
$roleFilter   = $_GET['role'] ?? '';
$allowedStatus = ['Open', 'In Progress', 'Resolved'];
$allowedRoles  = ['supervisor', 'storeemp'];

$where  = "u.department IN ('supervisor', 'storeemp')";
$params = [];
$types  = "";

if ($statusFilter !== '' && in_array($statusFilter, $allowedStatus, true)) {
    $where .= " AND q.status = ?";
    $params[] = $statusFilter;
    $types .= "s";
}

if ($roleFilter !== '' && in_array($roleFilter, $allowedRoles, true)) {
    $where .= " AND u.department = ?";
    $params[] = $roleFilter;
    $types .= "s";
}

$sql = "
    SELECT q.*, u.department
    FROM queries q
    JOIN users u ON u.email = q.user_email
    WHERE $where
    ORDER BY q.created_at DESC
";

if ($params) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $queries = $stmt->get_result();
} else {
    $queries = $conn->query($sql);
}

$openCount = $conn->query("
    SELECT COUNT(*) c
    FROM queries q
    JOIN users u ON u.email = q.user_email
    WHERE u.department IN ('supervisor', 'storeemp') AND q.status = 'Open'
")->fetch_assoc()['c'] ?? 0;

function query_status_badge($status) {
    $map = [
        'Open'        => 'bg-warning text-dark',
        'In Progress' => 'bg-info text-dark',
        'Resolved'    => 'bg-success',
    ];
    $class = $map[$status] ?? 'bg-secondary';
    return '<span class="badge ' . $class . '">' . htmlspecialchars($status) . '</span>';
}

function role_label($department) {
    return $department === 'supervisor' ? 'Supervisor' : 'Store Employee';
}
?>

<?php include "../includes/header.php"; ?>

  <?php include "../includes/storesidebar_admin.php"; ?>

  <!-- Main content -->
  <div class="flex-grow-1 p-4">

    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
        <h3 class="mb-0">
            Store Dashboard - User Queries
            <?php if ($openCount > 0): ?><span class="badge bg-danger"><?= (int)$openCount ?> open</span><?php endif; ?>
        </h3>

        <form method="GET" class="d-flex gap-2">
            <select name="role" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All Roles</option>
                <option value="supervisor" <?= $roleFilter === 'supervisor' ? 'selected' : '' ?>>Supervisor</option>
                <option value="storeemp" <?= $roleFilter === 'storeemp' ? 'selected' : '' ?>>Store Employee</option>
            </select>
            <select name="status" class="form-select form-select-sm" onchange="this.form.submit()">
                <option value="">All Statuses</option>
                <?php foreach ($allowedStatus as $s): ?>
                    <option value="<?= $s ?>" <?= $statusFilter === $s ? 'selected' : '' ?>><?= $s ?></option>
                <?php endforeach; ?>
            </select>
        </form>
    </div>

    <?php if (!empty($msg)) : ?>
        <div class="alert alert-<?= $msgType ?> alert-dismissible fade show">
            <?= htmlspecialchars($msg) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>User</th>
                            <th>Role</th>
                            <th>Subject</th>
                            <th>Message</th>
                            <th>Status</th>
                            <th>Admin Reply</th>
                            <th>Submitted</th>
                            <th width="90">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($queries && $queries->num_rows > 0): ?>
                        <?php while ($q = $queries->fetch_assoc()): ?>
                            <tr>
                                <td><?= htmlspecialchars($q['user_email']) ?></td>
                                <td><span class="badge bg-secondary"><?= role_label($q['department']) ?></span></td>
                                <td><?= htmlspecialchars($q['subject']) ?></td>
                                <td style="max-width:240px; white-space:pre-wrap;"><?= htmlspecialchars($q['message']) ?></td>
                                <td><?= query_status_badge($q['status']) ?></td>

                                <!-- Inline reply / status update form -->
                                <td style="min-width:240px;">
                                    <form method="POST">
                                        <?php csrf_field(); ?>
                                        <input type="hidden" name="id" value="<?= (int)$q['id'] ?>">

                                        <textarea name="admin_reply" class="form-control form-control-sm mb-1"
                                                  rows="2" placeholder="Write a reply..."><?= htmlspecialchars($q['admin_reply'] ?? '') ?></textarea>

                                        <div class="d-flex gap-1">
                                            <select name="status" class="form-select form-select-sm">
                                                <?php foreach ($allowedStatus as $s): ?>
                                                    <option value="<?= $s ?>" <?= $q['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <button type="submit" name="respond" class="btn btn-sm btn-success">Save</button>
                                        </div>
                                    </form>
                                </td>

                                <td><?= htmlspecialchars($q['created_at']) ?></td>

                                <td>
                                    <a href="?delete=<?= (int)$q['id'] ?>&csrf_token=<?= urlencode(csrf_token()) ?>"
                                       class="btn btn-sm btn-danger"
                                       onclick="return confirm('Delete this query?')">Delete</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="8" class="text-center text-muted py-3">No queries from supervisors or store employees yet.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

</body>
</html>
