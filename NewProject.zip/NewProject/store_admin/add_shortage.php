<?php
require "../config.php";
require "../includes/auth_admin_store.php";

$kitNoSearch    = trim($_GET['kit_no'] ?? '');
$poSearch       = trim($_GET['production_order'] ?? '');
$results        = [];
$resultMode     = '';
$searchedKitNo  = '';
$searchTermUsed = '';

// Shows EVERY row for a KITNO/PO, not just untouched ones. ps.status /
// ps.shortage_qty / ps.updated_by let the page render already-saved rows
// as locked (with an Edit link) instead of hiding them.
$baseQuery = "
    SELECT p.*, ps.status AS saved_status, ps.shortage_qty AS saved_shortage_qty, ps.updated_by AS saved_updated_by
    FROM plansstore p
    LEFT JOIN plan_status ps ON ps.plan_id = p.id
";

if ($kitNoSearch !== '') {
    $searchTermUsed = $kitNoSearch;

    $stmt = $conn->prepare($baseQuery . " WHERE p.kit_no = ? ORDER BY p.id ASC");
    $stmt->bind_param("s", $kitNoSearch);
    $stmt->execute();
    $res = $stmt->get_result();
    while ($r = $res->fetch_assoc()) { $results[] = $r; }
    $stmt->close();

    $searchedKitNo = $kitNoSearch;
    $resultMode = !empty($results) ? 'kitno' : 'none';

} elseif ($poSearch !== '') {
    $searchTermUsed = $poSearch;

    // Production order is still used to look up the kit, it's just not displayed as a column.
    $stmt = $conn->prepare("SELECT kit_no FROM plansstore WHERE production_order = ? LIMIT 1");
    $stmt->bind_param("s", $poSearch);
    $stmt->execute();
    $res = $stmt->get_result();

    if ($res && $res->num_rows > 0) {
        $row = $res->fetch_assoc();
        $searchedKitNo = $row['kit_no'];
        $stmt->close();

        $stmt2 = $conn->prepare($baseQuery . " WHERE p.kit_no = ? ORDER BY p.id ASC");
        $stmt2->bind_param("s", $searchedKitNo);
        $stmt2->execute();
        $res2 = $stmt2->get_result();
        while ($r = $res2->fetch_assoc()) { $results[] = $r; }
        $stmt2->close();

        $resultMode = !empty($results) ? 'po' : 'none';
    } else {
        $stmt->close();
        $resultMode = 'none';
    }
}

$redirectUrl = htmlspecialchars($_SERVER['REQUEST_URI']);
?>
<?php include "../includes/header.php"; ?>

  <?php include "../includes/storesidebar_admin.php"; ?>

  <!-- Main content -->
  <div class="flex-grow-1 p-4">
    <h3>Add Shortage</h3>

    <div class="row mb-4">
      <div class="col-md-6">
        <form action="add_shortage.php" method="GET" class="d-flex">
          <input type="text" name="kit_no" class="form-control me-2"
                 placeholder="Search by KITNO" value="<?= htmlspecialchars($kitNoSearch) ?>" required>
          <button type="submit" class="btn btn-primary text-nowrap">Search KITNO</button>
        </form>
      </div>
      <div class="col-md-6 mt-3 mt-md-0">
        <form action="add_shortage.php" method="GET" class="d-flex">
          <input type="text" name="production_order" class="form-control me-2"
                 placeholder="Search by Production Order" value="<?= htmlspecialchars($poSearch) ?>" required>
          <button type="submit" class="btn btn-success text-nowrap">Search Order</button>
        </form>
      </div>
    </div>

    <?php if ($resultMode === 'none'): ?>
      <div class="alert alert-warning">
        No records found for "<?= htmlspecialchars($searchTermUsed) ?>".
      </div>
    <?php elseif ($resultMode === 'kitno' || $resultMode === 'po'): ?>
      <div class="alert alert-info">Showing all rows for KITNO <strong><?= htmlspecialchars($searchedKitNo) ?></strong>.</div>
    <?php endif; ?>

    <?php if (!empty($results)): ?>
      <!-- Every row shares the same markup: a "save-status" block (badge +
           Edit link, shown for already-saved rows) and an "action-choice"
           block (the Full/Shortage checkboxes, shown for untouched rows,
           hidden-until-Edit-clicked for saved rows). This lets the same JS
           handle both fresh rows and edited-in-place rows. -->
      <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle">
          <thead class="table-success">
            <tr>
              <th>KITNO</th>
              <th>Rating</th>
              <th>Kit Size</th>
              <th>Date</th>
              <th>Material</th>
              <th>Material Description</th>
              <th>Total</th>
              <th width="260">Action</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($results as $r): ?>
              <?php
                $id = (int)$r['id'];
                $isSaved = $r['saved_status'] !== null;
                $rowClass = 'table-danger';
                if ($isSaved) {
                    $rowClass = $r['saved_status'] === 'full' ? 'table-success' : 'table-warning';
                }
                $savedStatus  = $isSaved ? $r['saved_status'] : '';
                $savedQty     = $isSaved ? (int)$r['saved_shortage_qty'] : 0;
              ?>
              <tr class="status-row <?= $rowClass ?>" data-id="<?= $id ?>" data-total="<?= (int)$r['total'] ?>"
                  data-saved-status="<?= htmlspecialchars($savedStatus) ?>" data-saved-qty="<?= $savedQty ?>">
                <td><?= htmlspecialchars($r['kit_no']) ?></td>
                <td><?= htmlspecialchars($r['rating']) ?></td>
                <td><?= htmlspecialchars($r['kit_size']) ?></td>
                <td><?= htmlspecialchars($r['plan_date']) ?></td>
                <td><?= htmlspecialchars($r['material']) ?></td>
                <td><?= htmlspecialchars($r['material_description']) ?></td>
                <td><?= htmlspecialchars($r['total']) ?></td>
                <td>
                  <div class="action-cell" id="action-cell-<?= $id ?>">

                    <div class="save-status <?= $isSaved ? '' : 'd-none' ?>">
                      <?php if ($isSaved): ?>
                        <?php if ($r['saved_status'] === 'full'): ?>
                          <span class="badge bg-success">Saved: Full</span>
                        <?php else: ?>
                          <span class="badge bg-danger">Saved: Shortage (<?= $savedQty ?> short)</span>
                        <?php endif; ?>
                        <?php if (!empty($r['saved_updated_by'])): ?>
                          <div class="form-text mt-1">by <?= htmlspecialchars($r['saved_updated_by']) ?></div>
                        <?php endif; ?>
                        <div class="mt-1">
                          <button type="button" class="btn btn-link btn-sm p-0 btn-edit-saved">Edit</button>
                        </div>
                      <?php endif; ?>
                    </div>

                    <div class="action-choice <?= $isSaved ? 'd-none' : '' ?>">
                      <div class="form-check form-check-inline">
                        <input class="form-check-input full-checkbox" type="checkbox"
                               id="full-<?= $id ?>">
                        <label class="form-check-label" for="full-<?= $id ?>">Full</label>
                      </div>
                      <div class="form-check form-check-inline">
                        <input class="form-check-input shortage-checkbox" type="checkbox"
                               id="shortage-<?= $id ?>">
                        <label class="form-check-label" for="shortage-<?= $id ?>">Shortage</label>
                      </div>
                      <?php if ($isSaved): ?>
                        <button type="button" class="btn btn-link btn-sm p-0 ms-2 btn-cancel-edit">Cancel</button>
                      <?php endif; ?>
                    </div>

                    <div class="shortage-entry d-none mt-2">
                      <div class="form-text mb-1 shortage-label">Total: <strong><?= htmlspecialchars($r['total']) ?></strong> — enter qty received</div>
                      <div class="input-group input-group-sm">
                        <input type="text" class="form-control received-qty-input" placeholder="Qty received now">
                        <button type="button" class="btn btn-primary btn-confirm-shortage">&#10003;</button>
                      </div>
                    </div>

                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php endif; ?>

  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarToggle')?.addEventListener('click', function () {
    document.getElementById('sidebar').classList.toggle('d-none');
});

// Sends one row's save to save_status.php as AJAX (ajax=1) and gets JSON
// back instead of a page redirect. markFull=true saves it as Full;
// otherwise receivedQty is the qty received now. Works identically whether
// the row was untouched or is being edited - save_status.php upserts either way.
function saveRow(id, markFull, receivedQty) {
    var body = new URLSearchParams();
    body.append('ajax', '1');
    body.append('plan_ids[]', id);
    if (markFull) {
        body.append('full[' + id + ']', '1');
    } else {
        body.append('received_qty[' + id + ']', receivedQty);
    }

    return fetch('save_status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: body.toString()
    }).then(function (res) {
        return res.text().then(function (text) {
            try {
                return JSON.parse(text);
            } catch (e) {
                console.error('Non-JSON response from save_status.php:', text);
                return { success: false, error: 'Unexpected server response (see console).' };
            }
        });
    });
}

// After a successful save, show the badge + Edit link again (rebuilding
// save-status fully so editing stays available), and hide the controls.
function lockRowAsSaved(row, data) {
    var cell = row.querySelector('.action-cell');
    cell.querySelector('.action-choice').classList.add('d-none');
    cell.querySelector('.shortage-entry').classList.add('d-none');

    row.classList.remove('table-danger', 'table-success', 'table-warning');
    row.classList.add(data.status === 'full' ? 'table-success' : 'table-warning');

    row.dataset.savedStatus = data.status;
    row.dataset.savedQty = data.status === 'full' ? 0 : data.shortage_qty;

    var badgeHtml = data.status === 'full'
        ? '<span class="badge bg-success">Saved: Full</span>'
        : '<span class="badge bg-danger">Saved: Shortage (' + data.shortage_qty + ' short)</span>';

    var updatedByHtml = data.updated_by
        ? '<div class="form-text mt-1">by ' + data.updated_by + '</div>'
        : '';

    var statusEl = cell.querySelector('.save-status');
    statusEl.innerHTML = badgeHtml + updatedByHtml +
        '<div class="mt-1"><button type="button" class="btn btn-link btn-sm p-0 btn-edit-saved">Edit</button></div>';
    statusEl.classList.remove('d-none');

    // Reset the checkbox/input state underneath so re-opening Edit later starts clean.
    var fullCb = cell.querySelector('.full-checkbox');
    var shortageCb = cell.querySelector('.shortage-checkbox');
    var qtyInput = cell.querySelector('.received-qty-input');
    fullCb.checked = false;
    fullCb.disabled = false;
    shortageCb.checked = false;
    shortageCb.disabled = false;
    qtyInput.value = '';
    qtyInput.disabled = false;
    qtyInput.classList.remove('is-invalid');
    cell.querySelector('.btn-confirm-shortage').disabled = false;
}

document.querySelectorAll('.status-row').forEach(function (row) {
    var id = row.dataset.id;
    var cell = row.querySelector('.action-cell');
    var fullCb = cell.querySelector('.full-checkbox');
    var shortageCb = cell.querySelector('.shortage-checkbox');
    var shortageEntry = cell.querySelector('.shortage-entry');
    var qtyInput = cell.querySelector('.received-qty-input');

    function setChoiceDisabled(disabled) {
        fullCb.disabled = disabled;
        shortageCb.disabled = disabled;
    }

    function showError(msg) {
        var errEl = cell.querySelector('.edit-error');
        if (!errEl) {
            errEl = document.createElement('div');
            errEl.className = 'edit-error text-danger mt-1';
            cell.querySelector('.action-choice').after(errEl);
        }
        errEl.textContent = msg;
    }

    function clearError() {
        var errEl = cell.querySelector('.edit-error');
        if (errEl) { errEl.remove(); }
    }

    // "Full" checkbox -> save instantly, no extra input needed.
    fullCb.addEventListener('change', function () {
        if (!fullCb.checked) { return; }
        shortageCb.checked = false;
        shortageEntry.classList.add('d-none');
        clearError();

        setChoiceDisabled(true);
        saveRow(id, true, null).then(function (data) {
            if (data.success) {
                lockRowAsSaved(row, data);
            } else {
                showError(data.error || 'Save failed, try again.');
                setChoiceDisabled(false);
                fullCb.checked = false;
            }
        }).catch(function () {
            showError('Save failed, try again.');
            setChoiceDisabled(false);
            fullCb.checked = false;
        });
    });

    // "Shortage" checkbox -> reveals the qty box. If this row already has a
    // saved shortage (being edited), pre-fill the label with the remaining
    // qty so it's clear what "qty received" is being subtracted from.
    shortageCb.addEventListener('change', function () {
        if (!shortageCb.checked) {
            shortageEntry.classList.add('d-none');
            return;
        }
        fullCb.checked = false;
        clearError();

        var label = shortageEntry.querySelector('.shortage-label');
        if (row.dataset.savedStatus === 'shortage') {
            label.innerHTML = 'Remaining shortage: <strong>' + row.dataset.savedQty + '</strong> — enter qty received now';
        } else {
            label.innerHTML = 'Total: <strong>' + row.dataset.total + '</strong> — enter qty received';
        }

        shortageEntry.classList.remove('d-none');
        qtyInput.focus();
    });

    // Entering a value and confirming it (Enter key or the check button)
    // saves instantly - there is no separate row-wide Save button.
    function confirmShortage() {
        var qty = qtyInput.value.trim();
        if (qty === '' || isNaN(qty)) {
            qtyInput.classList.add('is-invalid');
            qtyInput.focus();
            return;
        }
        qtyInput.classList.remove('is-invalid');
        clearError();
        setChoiceDisabled(true);
        qtyInput.disabled = true;
        cell.querySelector('.btn-confirm-shortage').disabled = true;

        saveRow(id, false, qty).then(function (data) {
            if (data.success) {
                lockRowAsSaved(row, data);
            } else {
                showError(data.error || 'Save failed, try again.');
                qtyInput.disabled = false;
                cell.querySelector('.btn-confirm-shortage').disabled = false;
                setChoiceDisabled(false);
            }
        }).catch(function () {
            showError('Save failed, try again.');
            qtyInput.disabled = false;
            cell.querySelector('.btn-confirm-shortage').disabled = false;
            setChoiceDisabled(false);
        });
    }

    cell.querySelector('.btn-confirm-shortage').addEventListener('click', confirmShortage);
    qtyInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            confirmShortage();
        }
    });
});

// Event delegation for Edit / Cancel links, since lockRowAsSaved() rebuilds
// the Edit link's HTML after every save - a single delegated listener means
// we never need to re-bind it.
document.addEventListener('click', function (e) {
    var editBtn = e.target.closest('.btn-edit-saved');
    if (editBtn) {
        var cell = editBtn.closest('.action-cell');
        var row = editBtn.closest('.status-row');
        cell.querySelector('.save-status').classList.add('d-none');
        cell.querySelector('.action-choice').classList.remove('d-none');

        // If it was saved as a shortage, jump straight into the shortage
        // entry pre-labelled with the remaining qty, since that's the
        // overwhelmingly common edit (receiving more stock later).
        if (row.dataset.savedStatus === 'shortage') {
            cell.querySelector('.shortage-checkbox').checked = true;
            var shortageEntry = cell.querySelector('.shortage-entry');
            shortageEntry.querySelector('.shortage-label').innerHTML =
                'Remaining shortage: <strong>' + row.dataset.savedQty + '</strong> — enter qty received now';
            shortageEntry.classList.remove('d-none');
            cell.querySelector('.received-qty-input').focus();
        }
        return;
    }

    var cancelBtn = e.target.closest('.btn-cancel-edit');
    if (cancelBtn) {
        var cell2 = cancelBtn.closest('.action-cell');
        cell2.querySelector('.action-choice').classList.add('d-none');
        cell2.querySelector('.shortage-entry').classList.add('d-none');
        cell2.querySelector('.save-status').classList.remove('d-none');
        cell2.querySelector('.full-checkbox').checked = false;
        cell2.querySelector('.shortage-checkbox').checked = false;
        cell2.querySelector('.received-qty-input').value = '';
        var errEl = cell2.querySelector('.edit-error');
        if (errEl) { errEl.remove(); }
    }
});
</script>
</body>
</html>