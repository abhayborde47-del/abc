<?php
require "../config.php"; // config.php already calls session_start()
require "../includes/security.php";
require "../includes/auth_owner.php";
require "../includes/crypto.php";

$message = "";
$error   = "";

// Departments a user can be assigned to.
$DEPARTMENTS = ['AIS', 'supervisor', 'storeemp', 'adi'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify($_POST['csrf_token'] ?? '');
    $action = $_POST['action'] ?? '';

    if ($action === 'add_user') {
        $name       = trim($_POST['name'] ?? '');
        $email      = trim($_POST['email'] ?? '');
        $password   = $_POST['password'] ?? '';
        $department = $_POST['department'] ?? '';

        if ($name === '' || $email === '' || strlen($password) < 8 || !in_array($department, $DEPARTMENTS, true)) {
            $error = "Please fill all fields correctly (password must be at least 8 characters).";
        } else {
            $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $check->bind_param("s", $email);
            $check->execute();
            if ($check->get_result()->fetch_assoc()) {
                $error = "A user with that email already exists.";
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $enc  = pw_encrypt($password);
                $stmt = $conn->prepare(
                    "INSERT INTO users (name, email, password, password_enc, department, created_at)
                     VALUES (?, ?, ?, ?, ?, NOW())"
                );
                $stmt->bind_param("sssss", $name, $email, $hash, $enc, $department);
                $stmt->execute();
                $message = "User \"$name\" created in $department.";
            }
        }
    } elseif ($action === 'change_password') {
        $user_id      = (int)($_POST['user_id'] ?? 0);
        $new_password = $_POST['new_password'] ?? '';

        if (strlen($new_password) < 8) {
            $error = "New password must be at least 8 characters.";
        } else {
            $hash = password_hash($new_password, PASSWORD_BCRYPT);
            $enc  = pw_encrypt($new_password);
            $stmt = $conn->prepare("UPDATE users SET password = ?, password_enc = ? WHERE id = ?");
            $stmt->bind_param("ssi", $hash, $enc, $user_id);
            $stmt->execute();
            $message = "Password updated.";
        }
    } elseif ($action === 'update_department') {
        $user_id    = (int)($_POST['user_id'] ?? 0);
        $department = $_POST['department'] ?? '';

        if (!in_array($department, $DEPARTMENTS, true)) {
            $error = "Invalid department.";
        } else {
            $stmt = $conn->prepare("UPDATE users SET department = ? WHERE id = ?");
            $stmt->bind_param("si", $department, $user_id);
            $stmt->execute();
            $message = "User updated.";
        }
    } elseif ($action === 'delete_user') {
        $user_id = (int)($_POST['user_id'] ?? 0);
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $message = "User deleted.";
    }
}

$users = $conn->query("SELECT id, name, email, department, created_at FROM users ORDER BY created_at DESC");
?>

<?php include "../includes/header.php"; ?>
  <?php include "../includes/sidebar_owner.php"; ?>

  <div class="content">
    <div class="container-fluid">
        <h3 class="mb-3">Manage Users</h3>

        <?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

        <!-- Add user -->
        <div class="card mb-4">
            <div class="card-header"><h5 class="mb-0">Add New User</h5></div>
            <div class="card-body">
                <form method="POST" class="row g-3">
                    <?php csrf_field(); ?>
                    <input type="hidden" name="action" value="add_user">
                    <div class="col-md-3">
                        <label class="form-label">Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" minlength="8" required>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Department</label>
                        <select name="department" class="form-select" required>
                            <option value="AIS">AIS</option>
                            <option value="supervisor">Supervisor</option>
                            <option value="storeemp">Store Employee</option>
                            <option value="adi">ADI</option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-success w-100">Add User</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- User list -->
        <div class="card">
            <div class="card-header"><h5 class="mb-0">All Users</h5></div>
            <div class="card-body">
                <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead>
                        <tr>
                            <th>Name</th><th>Email</th><th>Password</th><th>Department</th><th>Created</th><th style="width:420px">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($users && $users->num_rows > 0): ?>
                        <?php while ($u = $users->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($u['name'] ?? '') ?></td>
                            <td><?= htmlspecialchars($u['email']) ?></td>
                            <td>
                                <span class="js-password-cell text-muted">••••••••</span>
                                <button type="button"
                                        class="btn btn-outline-secondary btn-sm ms-1 js-view-password"
                                        data-type="user"
                                        data-id="<?= (int)$u['id'] ?>">
                                    View
                                </button>
                            </td>
                            <td><span class="badge bg-secondary"><?= htmlspecialchars($u['department']) ?></span></td>
                            <td><?= htmlspecialchars($u['created_at']) ?></td>
                            <td>
                                <div class="d-flex flex-wrap gap-1">
                                    <!-- change department -->
                                    <form method="POST" class="d-flex gap-1">
                                        <?php csrf_field(); ?>
                                        <input type="hidden" name="action" value="update_department">
                                        <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                                        <select name="department" class="form-select form-select-sm">
                                            <?php foreach ($DEPARTMENTS as $d): ?>
                                                <option value="<?= $d ?>" <?= $d === $u['department'] ? 'selected' : '' ?>><?= $d ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <button class="btn btn-sm btn-outline-primary">Save</button>
                                    </form>

                                    <!-- change password -->
                                    <form method="POST" class="d-flex gap-1">
                                        <?php csrf_field(); ?>
                                        <input type="hidden" name="action" value="change_password">
                                        <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                                        <input type="password" name="new_password" class="form-control form-control-sm" placeholder="New password" minlength="8" style="width:140px" required>
                                        <button class="btn btn-sm btn-outline-secondary">Reset</button>
                                    </form>

                                    <!-- delete -->
                                    <form method="POST" onsubmit="return confirm('Delete this user?');">
                                        <?php csrf_field(); ?>
                                        <input type="hidden" name="action" value="delete_user">
                                        <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                                        <button class="btn btn-sm btn-outline-danger">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="6" class="text-center">No users found</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
  </div>

<?php require "../includes/reveal_password_modal.php"; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
<script>
    window.CSRF_TOKEN = <?= json_encode(csrf_token()) ?>;
    window.REVEAL_PASSWORD_URL = "../includes/reveal_password.php";
</script>
<script src="../assets/js/reveal_password.js"></script>

</body>
</html>