<?php
require "../config.php"; // config.php already calls session_start()
require "../includes/security.php";
require "../includes/auth_owner.php";

$admin_count = $conn->query("SELECT COUNT(*) c FROM admins")->fetch_assoc()['c'];
$user_count  = $conn->query("SELECT COUNT(*) c FROM users")->fetch_assoc()['c'];
?>

<?php include "../includes/header.php"; ?>
  <?php include "../includes/sidebar_owner.php"; ?>

  <div class="content">
    <div class="container-fluid">
        <h3 class="mb-3">Owner Dashboard</h3>
        <p class="text-muted">Welcome, <?= htmlspecialchars($_SESSION['admin_email']) ?></p>

        <div class="row">
            <div class="col-md-4 mb-3">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h6 class="text-muted">Total Admins</h6>
                        <h2><?= (int)$admin_count ?></h2>
                        <a href="manage_admins.php">Manage &rarr;</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mb-3">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h6 class="text-muted">Total Users</h6>
                        <h2><?= (int)$user_count ?></h2>
                        <a href="manage_users.php">Manage &rarr;</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

</body>
</html>
