<?php
require "../config.php"; // config.php already calls session_start()
require "../includes/security.php";
require "../includes/auth_owner.php";
require "../includes/crypto.php";

$message = "";
$error   = "";

// The roles a NEW admin can be created as, per the current app design.
// Owner accounts are provisioned separately (see sql/owner_migration.sql / db.sql)
// so this list intentionally does not include 'owner'.
// NOTE: 'ADI' admin is intentionally NOT offered here anymore. ADI is now
// handled as a regular user department (see admin/add_user.php), which the
// AIS Admin manages directly. Existing ADI admin accounts keep working as
// before; this only removes the option to create new ones from this screen.
$CREATE_TYPES = ['store', 'AIS'];

// Existing admins can additionally be re-typed here if needed.
// 'ADI' is kept out of this list too, so an admin can no longer be
// (re)assigned the ADI admin role from the Owner panel.
$ALL_TYPES = ['store', 'AIS', 'owner'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify($_POST['csrf_token'] ?? '');
    $action = $_POST['action'] ?? '';

    if ($action === 'add_admin') {
        $name       = trim($_POST['name'] ?? '');
        $email      = trim($_POST['email'] ?? '');
        $password   = $_POST['password'] ?? '';
        $admin_type = $_POST['admin_type'] ?? '';
        $store_id   = ($admin_type === 'store' && $_POST['store_id'] !== '') ? (int)$_POST['store_id'] : null;

        if ($name === '' || $email === '' || strlen($password) < 8 || !in_array($admin_type, $CREATE_TYPES, true)) {
            $error = "Please fill all fields correctly (password must be at least 8 characters).";
        } elseif ($admin_type === 'store' && $store_id === null) {
            $error = "Store ID is required for a Store admin.";
        } else {
            $check = $conn->prepare("SELECT id FROM admins WHERE email = ?");
            $check->bind_param("s", $email);
            $check->execute();
            if ($check->get_result()->fetch_assoc()) {
                $error = "An admin with that email already exists.";
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $enc  = pw_encrypt($password);
                $stmt = $conn->prepare(
                    "INSERT INTO admins (name, email, password, password_enc, role, created_at, admin_type, store_id)
                     VALUES (?, ?, ?, ?, 'Admin', NOW(), ?, ?)"
                );
                $stmt->bind_param("sssssi", $name, $email, $hash, $enc, $admin_type, $store_id);
                $stmt->execute();
                $message = "Admin \"$name\" created as $admin_type.";
            }
        }
    } elseif ($action === 'change_password') {
        $admin_id     = (int)($_POST['admin_id'] ?? 0);
        $new_password = $_POST['new_password'] ?? '';

        if (strlen($new_password) < 8) {
            $error = "New password must be at least 8 characters.";
        } else {
            $hash = password_hash($new_password, PASSWORD_BCRYPT);
            $enc  = pw_encrypt($new_password);
            $stmt = $conn->prepare("UPDATE admins SET password = ?, password_enc = ? WHERE id = ?");
            $stmt->bind_param("ssi", $hash, $enc, $admin_id);
            $stmt->execute();
            $message = "Password updated.";
        }
    } elseif ($action === 'update_type') {
        $admin_id   = (int)($_POST['admin_id'] ?? 0);
        $admin_type = $_POST['admin_type'] ?? '';
        $store_id   = ($admin_type === 'store' && $_POST['store_id'] !== '') ? (int)$_POST['store_id'] : null;

        // Look up the current type so a legacy type (e.g. old 'ADI' admins,
        // no longer selectable) can be re-saved unchanged without erroring.
        $curStmt = $conn->prepare("SELECT admin_type FROM admins WHERE id = ?");
        $curStmt->bind_param("i", $admin_id);
        $curStmt->execute();
        $curRow = $curStmt->get_result()->fetch_assoc();
        $currentType = $curRow['admin_type'] ?? null;

        if (!in_array($admin_type, $ALL_TYPES, true) && $admin_type !== $currentType) {
            $error = "Invalid admin type.";
        } else {
            $stmt = $conn->prepare("UPDATE admins SET admin_type = ?, store_id = ? WHERE id = ?");
            $stmt->bind_param("sii", $admin_type, $store_id, $admin_id);
            $stmt->execute();
            $message = "Admin updated.";
        }
    } elseif ($action === 'delete_admin') {
        $admin_id = (int)($_POST['admin_id'] ?? 0);

        if ($admin_id === (int)$_SESSION['admin_id']) {
            $error = "You can't delete the account you're currently logged in as.";
        } else {
            $stmt = $conn->prepare("DELETE FROM admins WHERE id = ?");
            $stmt->bind_param("i", $admin_id);
            $stmt->execute();
            $message = "Admin deleted.";
        }
    }
}

$admins = $conn->query("SELECT id, name, email, admin_type, store_id, created_at FROM admins ORDER BY created_at DESC");
?>

<?php include "../includes/header.php"; ?>
  <?php include "../includes/sidebar_owner.php"; ?>

  <div class="content">
    <div class="container-fluid">
        <h3 class="mb-3">Manage Admins</h3>

        <?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

        <!-- Add admin -->
        <div class="card mb-4">
            <div class="card-header"><h5 class="mb-0">Add New Admin</h5></div>
            <div class="card-body">
                <form method="POST" class="row g-3">
                    <?php csrf_field(); ?>
                    <input type="hidden" name="action" value="add_admin">
                    <div class="col-md-3">
                        <label class="form-label">Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" minlength="8" required>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Admin Role</label>
                        <select name="admin_type" class="form-select" required>
                            <option value="store">Store Admin</option>
                            <option value="AIS">AIS Admin</option>
                        </select>
                        <small class="text-muted d-block mt-1">
                            ADI is now a user department, not an admin role — add ADI users from the AIS Admin's "Add User" screen.
                        </small>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Store ID <small class="text-muted">(Store only)</small></label>
                        <input type="number" name="store_id" class="form-control">
                    </div>
                    <div class="col-12">
                        <button type="submit" class="btn btn-success">Add Admin</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Admin list -->
        <div class="card">
            <div class="card-header"><h5 class="mb-0">All Admins</h5></div>
            <div class="card-body">
                <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead>
                        <tr>
                            <th>Name</th><th>Email</th><th>Password</th><th>Role</th><th>Store ID</th><th>Created</th><th style="width:440px">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($admins && $admins->num_rows > 0): ?>
                        <?php while ($a = $admins->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($a['name'] ?? '') ?></td>
                            <td><?= htmlspecialchars($a['email']) ?></td>
                            <td>
                                <span class="js-password-cell text-muted">••••••••</span>
                                <button type="button"
                                        class="btn btn-outline-secondary btn-sm ms-1 js-view-password"
                                        data-type="admin"
                                        data-id="<?= (int)$a['id'] ?>">
                                    View
                                </button>
                            </td>
                            <td><span class="badge bg-secondary"><?= htmlspecialchars($a['admin_type']) ?></span></td>
                            <td><?= htmlspecialchars($a['store_id'] ?? '-') ?></td>
                            <td><?= htmlspecialchars($a['created_at']) ?></td>
                            <td>
                                <div class="d-flex flex-wrap gap-1">
                                    <!-- change type -->
                                    <form method="POST" class="d-flex gap-1">
                                        <?php csrf_field(); ?>
                                        <input type="hidden" name="action" value="update_type">
                                        <input type="hidden" name="admin_id" value="<?= (int)$a['id'] ?>">
                                        <select name="admin_type" class="form-select form-select-sm">
                                            <?php if (!in_array($a['admin_type'], $ALL_TYPES, true)): ?>
                                                <!-- Legacy type (e.g. old 'ADI' admins) no longer assignable, but
                                                     shown here so the current value isn't silently changed. -->
                                                <option value="<?= htmlspecialchars($a['admin_type']) ?>" selected>
                                                    <?= htmlspecialchars($a['admin_type']) ?> (legacy)
                                                </option>
                                            <?php endif; ?>
                                            <?php foreach ($ALL_TYPES as $t): ?>
                                                <option value="<?= $t ?>" <?= $t === $a['admin_type'] ? 'selected' : '' ?>><?= $t ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                        <input type="number" name="store_id" class="form-control form-control-sm" placeholder="Store ID" style="width:90px" value="<?= htmlspecialchars($a['store_id'] ?? '') ?>">
                                        <button class="btn btn-sm btn-outline-primary">Save</button>
                                    </form>

                                    <!-- change password -->
                                    <form method="POST" class="d-flex gap-1">
                                        <?php csrf_field(); ?>
                                        <input type="hidden" name="action" value="change_password">
                                        <input type="hidden" name="admin_id" value="<?= (int)$a['id'] ?>">
                                        <input type="password" name="new_password" class="form-control form-control-sm" placeholder="New password" minlength="8" style="width:140px" required>
                                        <button class="btn btn-sm btn-outline-secondary">Reset</button>
                                    </form>

                                    <!-- delete -->
                                    <form method="POST" onsubmit="return confirm('Delete this admin?');">
                                        <?php csrf_field(); ?>
                                        <input type="hidden" name="action" value="delete_admin">
                                        <input type="hidden" name="admin_id" value="<?= (int)$a['id'] ?>">
                                        <button class="btn btn-sm btn-outline-danger">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center">No admins found</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
  </div>

<?php require "../includes/reveal_password_modal.php"; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>
<script>
    window.CSRF_TOKEN = <?= json_encode(csrf_token()) ?>;
    window.REVEAL_PASSWORD_URL = "../includes/reveal_password.php";
</script>
<script src="../assets/js/reveal_password.js"></script>

</body>
</html>
