SIMPLE PLAN PORTAL - DEMO (PHP + MySQL + Bootstrap)
=====================================================

SETUP (XAMPP / WAMP / any PHP+MySQL server):

1. Copy the whole "project" folder into your server's htdocs (e.g. C:\xampp\htdocs\project)

2. Create the database:
   - Open phpMyAdmin
   - Import db.sql   (this creates the "plan_demo" database, all tables,
     and 2 admin logins with passwords already encrypted using bcrypt)

3. Edit config.php if your MySQL username/password is different (default XAMPP: user=root, pass="")

4. Open in browser:
   http://localhost/project/login.php

ADMIN LOGIN:
   abhay@gmail.com / Abhay@222
   admin@gmail.com / Admin@222
   (Passwords are stored bcrypt-encrypted in the "admins" table.)

ADMIN CAN:
   - Add User        -> admin/add_user.php   (email, password [encrypted], department)
   - Upload Plan      -> admin/upload_plan.php (upload .xlsx, header row must contain:
                          Spare, SO_No_NEW, Region, Customer, Product, Creepage, CB_Serial_No)
                          CB_Serial_No is the primary key - if you upload the same excel again,
                          existing CB_Serial_No rows are skipped, only new ones are added.
   - View Plan        -> admin/view_plan.php  (update / delete any record, mobile + laptop friendly)

USER LOGIN:
   Any user added by admin (email/password set by admin) can log in as "User" role.

USER CAN:
   - Add Product      -> user/add_product.php
        Enter CB Serial No + select Hall (CB1 / CB2) -> Search -> shows plan info
        -> click Add -> saves into "added_products" table
        -> Recent list below with update / delete
   - History          -> user/history.php
        Search added products by date and / or CB Serial No

NOTES:
   - This is a SIMPLE DEMO build (no CSRF tokens / rate limiting / advanced security),
     as requested. Passwords are stored using PHP bcrypt (password_hash/password_verify).
   - xlsx reading uses a small built-in reader (lib/xlsx_reader.php) - no composer needed,
     just needs PHP's Zip + SimpleXML extensions (enabled by default in XAMPP).
