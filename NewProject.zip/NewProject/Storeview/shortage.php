<?php
require "../config.php";
require "../includes/auth_user.php";

// auth_user.php only confirms someone is logged in as a "user" - it doesn't
// know which department. This page is for supervisor only, so check that here.
if (($_SESSION['user_department'] ?? '') !== 'supervisor') {
    header("Location: ../login.php");
    exit;
}

// Read-only for supervisors: view + search + download only. No Save/Edit/Add
// controls exist anywhere on this page - that's intentional, not an oversight.

$kitNoSearch = trim($_GET['kit_no'] ?? '');
$poSearch    = trim($_GET['production_order'] ?? '');
$dateSearch  = trim($_GET['plan_date'] ?? ''); // <input type="date"> -> YYYY-MM-DD

// The three search fields are independent (separate forms) - whichever one is
// filled in is the one used. If more than one somehow arrives, KITNO wins,
// then Production Order, then Date, matching the order the fields are shown.
$where  = "WHERE COALESCE(ps.status,'shortage') = 'shortage'";
$params = [];
$types  = '';
$searchError = '';
$activeLabel = '';

if ($kitNoSearch !== '') {
    $where .= " AND p.kit_no = ?";
    $params[] = $kitNoSearch;
    $types   .= 's';
    $activeLabel = 'KITNO "' . $kitNoSearch . '"';

} elseif ($poSearch !== '') {
    // Resolve to the owning KITNO and show every remaining shortage row for
    // that whole kit, same convention used on the admin-side pages.
    $stmt = $conn->prepare("SELECT kit_no FROM plansstore WHERE production_order = ? LIMIT 1");
    $stmt->bind_param("s", $poSearch);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res && $res->num_rows > 0) {
        $resolvedKit = $res->fetch_assoc()['kit_no'];
        $where .= " AND p.kit_no = ?";
        $params[] = $resolvedKit;
        $types   .= 's';
        $activeLabel = 'Production Order "' . $poSearch . '" (KITNO ' . $resolvedKit . ')';
    } else {
        $searchError = 'No record found for Production Order "' . $poSearch . '".';
    }
    $stmt->close();

} elseif ($dateSearch !== '') {
    $where .= " AND p.plan_date = ?";
    $params[] = $dateSearch;
    $types   .= 's';
    $activeLabel = 'Date ' . $dateSearch;
}

if ($searchError !== '') {
    // Force an empty result set rather than showing unfiltered data.
    $where .= " AND 1 = 0";
}

$perPage = 13;
$page    = max(1, (int)($_GET['page'] ?? 1));
$offset  = ($page - 1) * $perPage;

$countSql = "
    SELECT COUNT(*) AS total
    FROM plansstore p
    LEFT JOIN plan_status ps ON ps.plan_id = p.id
    $where
";
$countStmt = $conn->prepare($countSql);
if ($types !== '') { $countStmt->bind_param($types, ...$params); }
$countStmt->execute();
$totalRows = (int)($countStmt->get_result()->fetch_assoc()['total'] ?? 0);
$countStmt->close();

$totalPages = max(1, (int)ceil($totalRows / $perPage));
if ($page > $totalPages) {
    $page   = $totalPages;
    $offset = ($page - 1) * $perPage;
}

// -----------------------------------------------------------------
// Download Excel - handled inline (Storeview has no separate download
// file), streamed instead of the normal HTML page when ?export=1 is present.
// -----------------------------------------------------------------
if (($_GET['export'] ?? '') === '1') {
    $sql = "
        SELECT p.*, COALESCE(ps.status,'shortage') AS status, ps.shortage_qty, ps.created_by, ps.updated_by
        FROM plansstore p
        LEFT JOIN plan_status ps ON ps.plan_id = p.id
        $where
        ORDER BY p.id ASC
    ";
    $stmt = $conn->prepare($sql);
    if ($types !== '') { $stmt->bind_param($types, ...$params); }
    $stmt->execute();
    $result = $stmt->get_result();

    $safeLabel = preg_replace('/[^A-Za-z0-9_-]/', '_', $activeLabel !== '' ? $activeLabel : 'all');
    $filename = 'shortage_report_' . $safeLabel . '.xls';

    header("Content-Type: application/vnd.ms-excel");
    header("Content-Disposition: attachment; filename=\"$filename\"");
    ?>
<table border="1">
  <tr>
    <th>KITNO</th>
    <th>Rating</th>
    <th>Kit Size</th>
    <th>Date</th>
    <th>Production Order</th>
    <th>Material</th>
    <th>Material Description</th>
    <th>Total</th>
    <th>Shortage Qty</th>
    <th>Created By</th>
    <th>Updated By</th>
  </tr>
  <?php while ($r = $result->fetch_assoc()): ?>
    <tr>
      <td><?= htmlspecialchars($r['kit_no']) ?></td>
      <td><?= htmlspecialchars($r['rating']) ?></td>
      <td><?= htmlspecialchars($r['kit_size']) ?></td>
      <td><?= htmlspecialchars($r['plan_date']) ?></td>
      <td><?= htmlspecialchars($r['production_order']) ?></td>
      <td><?= htmlspecialchars($r['material']) ?></td>
      <td><?= htmlspecialchars($r['material_description']) ?></td>
      <td><?= htmlspecialchars($r['total']) ?></td>
      <td><?= htmlspecialchars($r['shortage_qty'] ?? '') ?></td>
      <td><?= htmlspecialchars($r['created_by'] ?? '') ?></td>
      <td><?= htmlspecialchars($r['updated_by'] ?? '') ?></td>
    </tr>
  <?php endwhile; ?>
</table>
    <?php
    $stmt->close();
    exit;
}

// -----------------------------------------------------------------
// Normal page view
// -----------------------------------------------------------------
$sql = "
    SELECT p.*, COALESCE(ps.status,'shortage') AS status, ps.shortage_qty, ps.created_by, ps.updated_by
    FROM plansstore p
    LEFT JOIN plan_status ps ON ps.plan_id = p.id
    $where
    ORDER BY p.id ASC
    LIMIT ? OFFSET ?
";
$stmt = $conn->prepare($sql);
$allParams = $params;
$allTypes  = $types . 'ii';
$allParams[] = $perPage;
$allParams[] = $offset;
$stmt->bind_param($allTypes, ...$allParams);
$stmt->execute();
$result = $stmt->get_result();

$rows = [];
while ($r = $result->fetch_assoc()) { $rows[] = $r; }
$stmt->close();

function shortagePageUrl($kitNoSearch, $poSearch, $dateSearch, $page) {
    $params = ['page' => $page];
    if ($kitNoSearch !== '') { $params['kit_no'] = $kitNoSearch; }
    if ($poSearch !== '')    { $params['production_order'] = $poSearch; }
    if ($dateSearch !== '')  { $params['plan_date'] = $dateSearch; }
    return 'shortage.php?' . http_build_query($params);
}

function shortageDownloadUrl($kitNoSearch, $poSearch, $dateSearch) {
    $params = ['export' => 1];
    if ($kitNoSearch !== '') { $params['kit_no'] = $kitNoSearch; }
    if ($poSearch !== '')    { $params['production_order'] = $poSearch; }
    if ($dateSearch !== '')  { $params['plan_date'] = $dateSearch; }
    return 'shortage.php?' . http_build_query($params);
}
?>
<?php include "../includes/header.php"; ?>

  <?php include "../includes/storesidebar_view.php"; ?>

  <!-- Main content -->
  <div class="flex-grow-1 p-4">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
      <h3 class="mb-0">Shortage</h3>
      <a href="<?= htmlspecialchars(shortageDownloadUrl($kitNoSearch, $poSearch, $dateSearch)) ?>" class="btn btn-sm btn-outline-primary">Download Excel</a>
    </div>

    <!-- Three independent search fields: KITNO, Production Order, Date. -->
    <div class="row mb-3 gy-2">
      <div class="col-md-4">
        <form action="shortage.php" method="GET" class="d-flex">
          <input type="text" name="kit_no" class="form-control me-2"
                 placeholder="Search by KITNO" value="<?= htmlspecialchars($kitNoSearch) ?>">
          <button type="submit" class="btn btn-primary text-nowrap">Search</button>
        </form>
      </div>
      <div class="col-md-4">
        <form action="shortage.php" method="GET" class="d-flex">
          <input type="text" name="production_order" class="form-control me-2"
                 placeholder="Search by Production Order" value="<?= htmlspecialchars($poSearch) ?>">
          <button type="submit" class="btn btn-success text-nowrap">Search</button>
        </form>
      </div>
      <div class="col-md-4">
        <form action="shortage.php" method="GET" class="d-flex">
          <input type="date" name="plan_date" class="form-control me-2"
                 value="<?= htmlspecialchars($dateSearch) ?>">
          <button type="submit" class="btn btn-secondary text-nowrap">Search</button>
        </form>
      </div>
    </div>

    <?php if ($kitNoSearch !== '' || $poSearch !== '' || $dateSearch !== ''): ?>
      <div class="mb-3">
        <a href="shortage.php" class="btn btn-sm btn-outline-secondary">Clear search</a>
      </div>
    <?php endif; ?>

    <?php if ($searchError !== ''): ?>
      <div class="alert alert-warning"><?= htmlspecialchars($searchError) ?></div>
    <?php elseif ($activeLabel !== ''): ?>
      <div class="alert alert-info">Showing shortage rows for <?= htmlspecialchars($activeLabel) ?>.</div>
    <?php endif; ?>

    <?php if (empty($rows)): ?>
      <?php if ($searchError === ''): ?>
        <div class="alert alert-info">No shortage records found.</div>
      <?php endif; ?>
    <?php else: ?>
      <!-- View-only table: no Save button, no checkboxes, no inputs. -->
      <div class="table-responsive">
        <table class="table table-bordered table-striped align-middle">
          <thead class="table-danger">
            <tr>
              <th>KITNO</th>
              <th>Rating</th>
              <th>Kit Size</th>
              <th>Date</th>
              <th>Production Order</th>
              <th>Material</th>
              <th>Material Description</th>
              <th>Total</th>
              <th>Shortage Qty</th>
              <th>Created By</th>
              <th>Updated By</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($rows as $r): ?>
              <tr>
                <td><?= htmlspecialchars($r['kit_no']) ?></td>
                <td><?= htmlspecialchars($r['rating']) ?></td>
                <td><?= htmlspecialchars($r['kit_size']) ?></td>
                <td><?= htmlspecialchars($r['plan_date']) ?></td>
                <td><?= htmlspecialchars($r['production_order']) ?></td>
                <td><?= htmlspecialchars($r['material']) ?></td>
                <td><?= htmlspecialchars($r['material_description']) ?></td>
                <td><?= htmlspecialchars($r['total']) ?></td>
                <td><?= htmlspecialchars($r['shortage_qty'] ?? '') ?></td>
                <td><?= htmlspecialchars($r['created_by'] ?? '-') ?></td>
                <td><?= htmlspecialchars($r['updated_by'] ?? '-') ?></td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>

      <?php if ($totalPages > 1): ?>
        <nav class="d-flex justify-content-between align-items-center mt-3">
          <div class="text-muted small">
            Page <?= $page ?> of <?= $totalPages ?> (<?= $totalRows ?> records)
          </div>
          <ul class="pagination mb-0">
            <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
              <a class="page-link" href="<?= $page > 1 ? htmlspecialchars(shortagePageUrl($kitNoSearch, $poSearch, $dateSearch, $page - 1)) : '#' ?>">Previous</a>
            </li>
            <li class="page-item <?= $page >= $totalPages ? 'disabled' : '' ?>">
              <a class="page-link" href="<?= $page < $totalPages ? htmlspecialchars(shortagePageUrl($kitNoSearch, $poSearch, $dateSearch, $page + 1)) : '#' ?>">Next</a>
            </li>
          </ul>
        </nav>
      <?php endif; ?>
    <?php endif; ?>

  </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('sidebarToggle')?.addEventListener('click', function () {
    document.getElementById('sidebar').classList.toggle('d-none');
});
</script>
</body>
</html>