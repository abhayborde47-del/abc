<?php
require "config.php";
require "includes/security.php";

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    csrf_verify($_POST['csrf_token'] ?? '');

    $role     = $_POST['role'];
    $email    = trim($_POST['email']);
    $password = $_POST['password'];

    if (login_is_locked_out($conn, $email)) {

        $error = "Too many failed login attempts. Please try again in " .
                  LOGIN_LOCKOUT_MINUTES . " minutes.";

    } elseif ($role === 'admin') {

        // Fetch admin_type and store_id too, so we know where to route them
        $stmt = $conn->prepare("SELECT id, password, admin_type, store_id FROM admins WHERE email=?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {

            if (password_verify($password, $row['password'])) {

                // Prevent session fixation
                session_regenerate_id(true);

                $_SESSION['admin_email'] = $email;
                $_SESSION['admin_id']    = $row['id'];
                $_SESSION['admin_type']  = $row['admin_type']; // 'owner' | 'AIS' | 'store' | 'ADI'
                $_SESSION['store_id']    = $row['store_id'];   // NULL unless admin_type = 'store'

                login_clear_attempts($conn, $email);

                // Route based on admin type. Add new mappings here if you add new admin types.
                $admin_routes = [
                    'owner' => 'owner/dashboard.php',
                    'AIS'   => 'admin/view_plan.php',
                    'store' => 'store_admin/search_plan.php',
                    'ADI'   => 'adi_admin/dashboard.php',
                ];

                $target = $admin_routes[$row['admin_type']] ?? 'store_admin/search_plan.php';
                header("Location: " . $target);
                exit;
            }
        }

        login_record_failure($conn, $email);
        $error = "Invalid Admin Email or Password";

    } else {

        // Fetch department too, so we know where to route the user
        $stmt = $conn->prepare("SELECT id, password, department FROM users WHERE email=?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($row = $result->fetch_assoc()) {

            if (password_verify($password, $row['password'])) {

                session_regenerate_id(true);

                $_SESSION['user_email']      = $email;
                $_SESSION['user_id']         = $row['id'];
                $_SESSION['user_department'] = $row['department']; // 'AIS' | 'supervisor' | 'storeemp' | 'adi'

                login_clear_attempts($conn, $email);

                // Route based on department
                if ($row['department'] === 'AIS') {
                    header("Location: user/add_product.php");
                } elseif ($row['department'] === 'supervisor') {
                    header("Location: Storeview/shortage.php");
                    
                }
                elseif ($row['department'] === 'SSControl') {
                    header("Location: sscontrol/dashboard.php");
                    
                } elseif ($row['department'] === 'storeemp') {
                    header("Location: Storeuser/add_shortage.php");
                } elseif ($row['department'] === 'adi') {
                    header("Location: Adiuser/dashboard.php");
                } else {
                    // Unknown department - fall back to a safe default
                    $error = "Your account has no valid department assigned. Contact admin.";
                    session_destroy();
                }

                if (empty($error)) {
                    exit;
                }
            } else {
                login_record_failure($conn, $email);
                $error = "Invalid User Email or Password";
            }
        } else {
            login_record_failure($conn, $email);
            $error = "Invalid User Email or Password";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Plan Portal Login</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

<style>
*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    min-height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:linear-gradient(135deg,#0d6efd,#6ea8fe);
    font-family:Arial, sans-serif;
}

.login-box{
    width:100%;
    max-width:450px;
}

.card{
    border:none;
    border-radius:15px;
    overflow:hidden;
}

.card-body{
    padding:35px;
}

h2{
    text-align:center;
    margin-bottom:25px;
    font-weight:700;
    color:#0d6efd;
}

.form-label{
    font-weight:600;
}

.form-control,
.form-select{
    height:48px;
    border-radius:8px;
}

.btn-primary{
    height:48px;
    font-size:18px;
    font-weight:600;
    border-radius:8px;
}

.alert{
    border-radius:8px;
}

@media(max-width:576px){
    .login-box{
        width:95%;
    }

    .card-body{
        padding:25px;
    }
}
</style>

</head>
<body>

<div class="login-box">
    <div class="card shadow-lg">
        <div class="card-body">

            <h2>Plan Portal Login</h2>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger">
                    <?= htmlspecialchars($error) ?>
                </div>
            <?php endif; ?>

            <form method="POST">

                <?php csrf_field(); ?>

                <!--
                    Note: no separate role dropdown for Owner / Store / AIS / ADI here.
                    Admins: PHP checks admin_type ('owner' / 'AIS' / 'store' / 'ADI') and
                    routes to owner/, admin/, store_admin/, or adi_admin/ automatically.
                    Users: PHP checks department (AIS / supervisor / storeemp / adi) and
                    routes to user/, Storeview/, Storeuser/, or Adiuser/ automatically.
                -->
                <div class="mb-3">
                    <label class="form-label">Login As</label>
                    <select name="role" class="form-select" required>
                        <option value="admin">Admin</option>
                        <option value="user">User</option>
                    </select>
                </div>

                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <input type="email"
                           name="email"
                           class="form-control"
                           placeholder="Enter Email"
                           required>
                </div>

                <div class="mb-4">
                    <label class="form-label">Password</label>
                    <input type="password"
                           name="password"
                           class="form-control"
                           placeholder="Enter Password"
                           required>
                </div>

                <button type="submit" class="btn btn-primary w-100">
                    Login
                </button>

            </form>

        </div>
    </div>
</div>

</body>
</html>