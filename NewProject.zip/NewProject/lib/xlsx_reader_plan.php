<?php
// XLSX reader dedicated to plan uploads (store_admin/upload_plan.php)
// Returns array of rows (each row = numeric-indexed array of cell values: 0=A, 1=B, 2=C...)
// Kept separate from readXLSX() to avoid function name collisions with other upload features.

function readXLSXPlan($filePath) {
    $zip = new ZipArchive();
    $rows = [];
    if ($zip->open($filePath) === true) {

        // read shared strings
        $shared = [];
        $ss = $zip->getFromName('xl/sharedStrings.xml');
        if ($ss !== false) {
            $xml = simplexml_load_string($ss);
            foreach ($xml->si as $si) {
                if (isset($si->t)) {
                    $shared[] = (string)$si->t;
                } else {
                    $text = '';
                    foreach ($si->r as $r) $text .= (string)$r->t;
                    $shared[] = $text;
                }
            }
        }

        $sheet = $zip->getFromName('xl/worksheets/sheet1.xml');
        $zip->close();

        if ($sheet !== false) {
            $xml = simplexml_load_string($sheet);
            foreach ($xml->sheetData->row as $row) {
                $rowData = [];
                foreach ($row->c as $c) {
                    // figure column letter -> index (handle blank/skipped cells)
                    $ref = (string)$c['r'];
                    preg_match('/[A-Z]+/', $ref, $m);
                    $colLetters = $m[0] ?? '';
                    $idx = 0;
                    foreach (str_split($colLetters) as $ch) {
                        $idx = $idx * 26 + (ord($ch) - 64);
                    }
                    $idx = $idx - 1; // zero-based

                    $val = '';
                    if (isset($c['t']) && (string)$c['t'] == 's') {
                        $val = $shared[(int)$c->v] ?? '';
                    } else {
                        $val = (string)$c->v;
                    }
                    while (count($rowData) < $idx) $rowData[] = '';
                    $rowData[$idx] = $val;
                }
                $rows[] = $rowData;
            }
        }
    }
    return $rows;
}

/**
 * Converts an Excel date serial number to Y-m-d.
 */
function excelDateToYmdPlan($serial) {
    if (!is_numeric($serial)) return null;
    $unixTimestamp = ($serial - 25569) * 86400;
    return gmdate('Y-m-d', $unixTimestamp);
}