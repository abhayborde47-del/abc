<?php
// Very small XLSX reader - returns array of rows (each row = array of cell values)
// Works for simple single-sheet xlsx files exported from Excel.
function readXLSX($filePath) {
    $zip = new ZipArchive();
    $rows = [];
    if ($zip->open($filePath) === true) {

        // read shared strings
        $shared = [];
        $ss = $zip->getFromName('xl/sharedStrings.xml');
        if ($ss !== false) {
            $xml = simplexml_load_string($ss);
            foreach ($xml->si as $si) {
                if (isset($si->t)) {
                    $shared[] = (string)$si->t;
                } else {
                    $text = '';
                    foreach ($si->r as $r) $text .= (string)$r->t;
                    $shared[] = $text;
                }
            }
        }

        $sheet = $zip->getFromName('xl/worksheets/sheet1.xml');
        $zip->close();

        if ($sheet !== false) {
            $xml = simplexml_load_string($sheet);
            foreach ($xml->sheetData->row as $row) {
                $rowData = [];
                $colIndex = 0;
                foreach ($row->c as $c) {
                    // figure column letter -> index (handle blank/skipped cells)
                    $ref = (string)$c['r'];
                    preg_match('/[A-Z]+/', $ref, $m);
                    $colLetters = $m[0] ?? '';
                    $idx = 0;
                    foreach (str_split($colLetters) as $ch) {
                        $idx = $idx * 26 + (ord($ch) - 64);
                    }
                    $idx = $idx - 1; // zero-based

                    $val = '';
                    if (isset($c['t']) && (string)$c['t'] == 's') {
                        $val = $shared[(int)$c->v] ?? '';
                    } else {
                        $val = (string)$c->v;
                    }
                    while (count($rowData) < $idx) $rowData[] = '';
                    $rowData[$idx] = $val;
                }
                $rows[] = $rowData;
            }
        }
    }
    return $rows;
}
