<?php
require "../config.php"; // config.php already calls session_start()
require "../includes/security.php";

// --- Auth guard: only logged-in users with department = 'adi' allowed here ---
if (!isset($_SESSION['user_email']) || ($_SESSION['user_department'] ?? '') !== 'adi') {
    header("Location: ../login.php");
    exit;
}
?>

<?php include "../includes/header.php"; ?>
  <?php include "../includes/sidebar_adiuser.php"; ?>

  <div class="content">
    <div class="container-fluid">
        <h3 class="mb-3">ADI User Dashboard</h3>

        <div class="alert alert-info">
            Welcome, <?= htmlspecialchars($_SESSION['user_email']) ?>. This is a starter page for
            ADI-department users &mdash; wire up whatever ADI-specific tools this role needs, the same
            way <code>Storeuser/</code> and <code>user/</code> are built.
        </div>
    </div>
  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

</body>
</html>