-- Simple demo database
CREATE DATABASE IF NOT EXISTS plan_demo;
USE plan_demo;

CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL
);

-- passwords are bcrypt hashed (Abhay@222 / Admin@222)
INSERT INTO admins (email, password) VALUES
('abhay@gmail.com', '$2y$10$Ad0/jbDZGlHPUoaNwZht4O1YOl.7yJoil/G1SWBvCw0CzyEbDFLRu'),
('admin@gmail.com', '$2y$10$/i1uPBbFDlgU83MTQ6J8JOAjoVl6aK9fFUxI7ym05FI6OSBh7EPym');

CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  email VARCHAR(100) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  department VARCHAR(100),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS plans (
  cb_serial_no VARCHAR(100) PRIMARY KEY,
  spare VARCHAR(100),
  so_no_new VARCHAR(100),
  region VARCHAR(100),
  customer VARCHAR(150),
  product VARCHAR(150),
  creepage VARCHAR(100),
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS added_products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  cb_serial_no VARCHAR(100),
  hall VARCHAR(10),
  spare VARCHAR(100),
  so_no_new VARCHAR(100),
  region VARCHAR(100),
  customer VARCHAR(150),
  product VARCHAR(150),
  creepage VARCHAR(100),
  added_by VARCHAR(100),
  added_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- Insert a new Store Admin account into the admins table
-- Login: Storeadmin@gmail.com | Password: Storeadmin@222 (bcrypt hashed below)
-- admin_type = 'store' routes this user to store_admin/view_plan.php on login
-- store_id = 1 scopes this admin to Store #1 -- update this to match the correct store
INSERT INTO admins (email, password, admin_type, store_id) VALUES
(
    'Storeadmin@gmail.com',                                          -- email used to log in
    '$2b$10$XqhxSu4a/DmB4zZPADTVAOB3LPiTGkwbt3hFNPYivKoLcV.wqD7VW',  -- bcrypt hash of "Storeadmin@222"
    'store',                                                         -- role type: 'main' = super admin, 'store' = store-level admin
    1                                                                 -- store_id this admin is restricted to
);
CREATE TABLE plans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    rating VARCHAR(50) NOT NULL,
    kit_size INT NOT NULL,
    plan_date DATE NOT NULL,
    variant_details VARCHAR(255) NOT NULL,
    production_order VARCHAR(50) NOT NULL,
    material VARCHAR(100) NOT NULL,
    material_description VARCHAR(255) NOT NULL,
    total INT NOT NULL,
    uploaded_by VARCHAR(150) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- =========================================================
-- USER QUERIES / SUPPORT TICKETS
-- Submitted by users (user/queries.php), managed by admin (admin/queries.php)
-- =========================================================
CREATE TABLE IF NOT EXISTS queries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_email VARCHAR(150) NOT NULL,
    subject VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('Open','In Progress','Resolved') NOT NULL DEFAULT 'Open',
    admin_reply TEXT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_email (user_email),
    INDEX idx_status (status)
);

-- =========================================================
-- LOGIN RATE LIMITING (brute-force protection)
-- Also auto-created at runtime by includes/security.php if missing
-- =========================================================
CREATE TABLE IF NOT EXISTS login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    identifier VARCHAR(150) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_identifier (identifier),
    INDEX idx_attempted_at (attempted_at)
);

-- =========================================================
-- DAY-WISE CB1 / CB2 PLAN (admin/day_plan.php, user/day_plan.php)
-- Also auto-created at runtime by includes/day_plan_shared.php if missing
-- =========================================================
CREATE TABLE IF NOT EXISTS day_plans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cb_serial_no VARCHAR(100) NOT NULL,
    hall ENUM('CB1','CB2') NOT NULL,
    plan_date DATE NOT NULL,
    spare VARCHAR(100) DEFAULT NULL,
    so_no_new VARCHAR(100) DEFAULT NULL,
    region VARCHAR(100) DEFAULT NULL,
    customer VARCHAR(150) DEFAULT NULL,
    product VARCHAR(150) DEFAULT NULL,
    creepage VARCHAR(100) DEFAULT NULL,
    quantity INT DEFAULT 1,
    status ENUM('Incomplete','Process','Completed') NOT NULL DEFAULT 'Incomplete',
    is_extra TINYINT(1) NOT NULL DEFAULT 0,
    remark TEXT DEFAULT NULL,
    added_by VARCHAR(150) DEFAULT NULL,
    updated_by VARCHAR(150) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_cb (cb_serial_no),
    INDEX idx_status (status),
    INDEX idx_date (plan_date)
);