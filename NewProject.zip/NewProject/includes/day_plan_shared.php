<?php
/**
 * includes/day_plan_shared.php
 * -------------------------------------------------------
 * Day-wise CB1 / CB2 production plan.
 *
 * This single file is shared by BOTH:
 *   - admin/day_plan.php  (AIS Admin)
 *   - user/day_plan.php   (AIS User)
 *
 * Both admin and user can, from this same screen:
 *   - Add a CB Serial No to a day's plan for CB1 or CB2
 *   - See ALL day-plan entries (not just their own)
 *   - Mark each entry Incomplete / Process / Completed
 *   - Update (edit) an existing entry
 *   - Accept an "Extra" entry for a CB Serial No a user produced
 *     that was never part of the plan
 *
 * Rules:
 *   - Once an entry for a CB Serial No is marked "Completed", that
 *     CB Serial No cannot be added into the plan again.
 *   - While an entry is "Incomplete" or "Process", the same CB
 *     Serial No CAN be added again (re-planned) — as long as the
 *     other rules below don't block it.
 *   - Only ONE entry per CB Serial No is allowed for a single day
 *     (you cannot add the same CB Serial No twice on the same date).
 *   - Once a product has actually been created for a CB Serial No
 *     (a row exists in `added_products`), that CB Serial No can
 *     never be added into the plan again.
 *   - An "Extra" entry (CB produced outside of the plan) is accepted
 *     through its own button/form and is immediately locked
 *     (Completed) so it also can't be planned again afterwards.
 *
 * The caller must define, before requiring this file:
 *   $conn            - mysqli connection (from config.php)
 *   $actor_email     - the logged-in admin/user email (for added_by / updated_by)
 *   $panel           - 'admin' or 'user' (only used for small text/labels)
 *   $sidebar_include - filename (in includes/) of the sidebar to show
 *
 * Everything else (auth, header) is expected to already have been
 * required by the calling admin/day_plan.php or user/day_plan.php.
 */

/* =============================================================
   ENSURE TABLE EXISTS (safe on every request, like other pages)
============================================================= */

$conn->query("
    CREATE TABLE IF NOT EXISTS day_plans (
        id INT AUTO_INCREMENT PRIMARY KEY,
        cb_serial_no VARCHAR(100) NOT NULL,
        hall ENUM('CB1','CB2') NOT NULL,
        plan_date DATE NOT NULL,
        spare VARCHAR(100) DEFAULT NULL,
        so_no_new VARCHAR(100) DEFAULT NULL,
        region VARCHAR(100) DEFAULT NULL,
        customer VARCHAR(150) DEFAULT NULL,
        product VARCHAR(150) DEFAULT NULL,
        creepage VARCHAR(100) DEFAULT NULL,
        quantity INT DEFAULT 1,
        status ENUM('Incomplete','Process','Completed') NOT NULL DEFAULT 'Incomplete',
        is_extra TINYINT(1) NOT NULL DEFAULT 0,
        remark TEXT DEFAULT NULL,
        added_by VARCHAR(150) DEFAULT NULL,
        updated_by VARCHAR(150) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        INDEX idx_cb (cb_serial_no),
        INDEX idx_status (status),
        INDEX idx_date (plan_date)
    )
");

$msg     = "";
$msgType = "info";

$HALLS    = ['CB1', 'CB2'];
$STATUSES = ['Incomplete', 'Process', 'Completed'];

/**
 * Is this CB Serial No currently locked (already Completed somewhere)?
 * Returns the completed row if locked, otherwise null.
 */
function day_plan_find_completed($conn, $cb) {
    $stmt = $conn->prepare(
        "SELECT id, plan_date, hall, is_extra
         FROM day_plans
         WHERE cb_serial_no = ? AND status = 'Completed'
         ORDER BY id DESC LIMIT 1"
    );
    $stmt->bind_param("s", $cb);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

/**
 * Has a product already been created (in added_products) for this
 * CB Serial No? If yes, it can never be added into the day plan
 * again (a plan entry only makes sense before the product exists).
 */
function day_plan_find_in_products($conn, $cb) {
    $stmt = $conn->prepare(
        "SELECT id, production_date, hall
         FROM added_products
         WHERE cb_serial_no = ? LIMIT 1"
    );
    $stmt->bind_param("s", $cb);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

/**
 * Is this CB Serial No already planned on this SAME day (any hall)?
 * Only one plan entry per CB Serial No per day is allowed.
 */
function day_plan_find_same_day($conn, $cb, $plan_date) {
    $stmt = $conn->prepare(
        "SELECT id, hall, status
         FROM day_plans
         WHERE cb_serial_no = ? AND plan_date = ?
         LIMIT 1"
    );
    $stmt->bind_param("ss", $cb, $plan_date);
    $stmt->execute();
    return $stmt->get_result()->fetch_assoc();
}

/* =============================================================
   ADD TO PLAN  (normal, found in master `plans`, OR extra/manual)
============================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_plan'])) {

    csrf_verify($_POST['csrf_token'] ?? '');

    $cb         = trim($_POST['cb_serial_no'] ?? '');
    $hall       = trim($_POST['hall'] ?? '');
    $plan_date  = trim($_POST['plan_date'] ?? '');
    $quantity   = max(1, (int)($_POST['quantity'] ?? 1));
    $remark     = trim($_POST['remark'] ?? '');
    $is_extra   = isset($_POST['is_extra']) && $_POST['is_extra'] === '1';

    if ($cb === '') {
        $msg = "Please enter CB Serial No.";
        $msgType = "warning";
    } elseif (!in_array($hall, $HALLS, true)) {
        $msg = "Please select a valid Hall (CB1 or CB2).";
        $msgType = "warning";
    } elseif (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $plan_date)) {
        $msg = "Please select a valid plan date.";
        $msgType = "warning";
    } else {

        $completed  = day_plan_find_completed($conn, $cb);
        $inProduct  = day_plan_find_in_products($conn, $cb);
        $sameDay    = day_plan_find_same_day($conn, $cb, $plan_date);

        if ($completed) {

            $msg = "CB Serial No " . htmlspecialchars($cb) .
                   " is already marked Completed (on " . htmlspecialchars($completed['plan_date']) .
                   ", " . htmlspecialchars($completed['hall']) .
                   "). Completed CB numbers cannot be added to the plan again.";
            $msgType = "danger";

        } elseif ($inProduct) {

            $msg = "CB Serial No " . htmlspecialchars($cb) .
                   " already has a product created (on " . htmlspecialchars($inProduct['production_date']) .
                   ", " . htmlspecialchars($inProduct['hall']) .
                   "). Once a product is created for a CB Serial No, it cannot be added to the plan again.";
            $msgType = "danger";

        } elseif ($sameDay) {

            $msg = "CB Serial No " . htmlspecialchars($cb) .
                   " is already in the plan for " . htmlspecialchars($plan_date) .
                   " (Hall " . htmlspecialchars($sameDay['hall']) .
                   "). Only one entry per CB Serial No is allowed for a single day.";
            $msgType = "danger";

        } elseif ($is_extra) {

            /* -------------------------------------------------
               EXTRA ENTRY: product made by the user outside the
               plan. Details are entered manually, and once
               accepted it is immediately locked as Completed so
               it also cannot be planned again afterwards.
            ------------------------------------------------- */

            $spare    = trim($_POST['spare'] ?? '');
            $so_no    = trim($_POST['so_no_new'] ?? '');
            $region   = trim($_POST['region'] ?? '');
            $customer = trim($_POST['customer'] ?? '');
            $product  = trim($_POST['product'] ?? '');
            $creepage = trim($_POST['creepage'] ?? '');

            $stmt = $conn->prepare(
                "INSERT INTO day_plans
                 (cb_serial_no, hall, plan_date, spare, so_no_new, region, customer, product, creepage, quantity, status, is_extra, remark, added_by)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Completed', 1, ?, ?)"
            );
            $stmt->bind_param(
                "sssssssssiss",
                $cb, $hall, $plan_date, $spare, $so_no, $region, $customer, $product, $creepage, $quantity, $remark, $actor_email
            );

            if ($stmt->execute()) {
                $msg = "Extra entry for CB Serial No " . htmlspecialchars($cb) . " accepted and recorded as Completed.";
                $msgType = "success";
            } else {
                $msg = "Error saving extra entry: " . htmlspecialchars($conn->error);
                $msgType = "danger";
            }

        } else {

            /* -------------------------------------------------
               NORMAL PLAN ENTRY: pull the rest of the details
               from the master `plans` table using CB Serial No.
            ------------------------------------------------- */

            $lookup = $conn->prepare(
                "SELECT spare, so_no_new, region, customer, product, creepage
                 FROM plans WHERE cb_serial_no = ? LIMIT 1"
            );
            $lookup->bind_param("s", $cb);
            $lookup->execute();
            $planRow = $lookup->get_result()->fetch_assoc();

            if (!$planRow) {

                $msg = "CB Serial No " . htmlspecialchars($cb) .
                       " was not found in the uploaded plan. If this product was made outside " .
                       "the plan, use \"Add Extra Entry\" instead.";
                $msgType = "warning";

            } else {

                $stmt = $conn->prepare(
                    "INSERT INTO day_plans
                     (cb_serial_no, hall, plan_date, spare, so_no_new, region, customer, product, creepage, quantity, status, is_extra, remark, added_by)
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Incomplete', 0, ?, ?)"
                );
                $stmt->bind_param(
                    "sssssssssiss",
                    $cb, $hall, $plan_date,
                    $planRow['spare'], $planRow['so_no_new'], $planRow['region'],
                    $planRow['customer'], $planRow['product'], $planRow['creepage'],
                    $quantity, $remark, $actor_email
                );

                if ($stmt->execute()) {
                    $msg = "CB Serial No " . htmlspecialchars($cb) . " added to the " . htmlspecialchars($hall) . " plan for " . htmlspecialchars($plan_date) . ".";
                    $msgType = "success";
                } else {
                    $msg = "Error saving plan entry: " . htmlspecialchars($conn->error);
                    $msgType = "danger";
                }
            }
        }
    }
}

/* =============================================================
   UPDATE AN EXISTING ENTRY (date / hall / qty / remark / status)
============================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_plan'])) {

    csrf_verify($_POST['csrf_token'] ?? '');

    $id        = (int)($_POST['id'] ?? 0);
    $hall      = trim($_POST['hall'] ?? '');
    $plan_date = trim($_POST['plan_date'] ?? '');
    $quantity  = max(1, (int)($_POST['quantity'] ?? 1));
    $remark    = trim($_POST['remark'] ?? '');
    $status    = trim($_POST['status'] ?? 'Incomplete');

    if ($id <= 0) {
        $msg = "Invalid entry.";
        $msgType = "danger";
    } elseif (!in_array($hall, $HALLS, true) || !in_array($status, $STATUSES, true) ||
              !preg_match('/^\d{4}-\d{2}-\d{2}$/', $plan_date)) {
        $msg = "Please fill the update form correctly.";
        $msgType = "warning";
    } else {
        $stmt = $conn->prepare(
            "UPDATE day_plans
             SET hall = ?, plan_date = ?, quantity = ?, remark = ?, status = ?, updated_by = ?
             WHERE id = ?"
        );
        $stmt->bind_param("ssisssi", $hall, $plan_date, $quantity, $remark, $status, $actor_email, $id);

        if ($stmt->execute()) {
            $msg = "Plan entry #$id updated.";
            $msgType = "success";
        } else {
            $msg = "Error updating entry: " . htmlspecialchars($conn->error);
            $msgType = "danger";
        }
    }
}

/* =============================================================
   QUICK STATUS CHANGE (Incomplete / Process / Completed)
============================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_status'])) {

    csrf_verify($_POST['csrf_token'] ?? '');

    $id     = (int)($_POST['id'] ?? 0);
    $status = trim($_POST['status'] ?? '');

    if ($id > 0 && in_array($status, $STATUSES, true)) {
        $stmt = $conn->prepare("UPDATE day_plans SET status = ?, updated_by = ? WHERE id = ?");
        $stmt->bind_param("ssi", $status, $actor_email, $id);
        $stmt->execute();
        $msg = "Status for entry #$id set to $status.";
        $msgType = "success";
    } else {
        $msg = "Invalid status change.";
        $msgType = "danger";
    }
}

/* =============================================================
   DELETE
============================================================= */
if (isset($_GET['delete'])) {
    csrf_verify($_GET['csrf_token'] ?? '');
    $id = (int)$_GET['delete'];
    if ($id > 0) {
        $stmt = $conn->prepare("DELETE FROM day_plans WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
    }
    header("Location: day_plan.php");
    exit;
}

/* =============================================================
   FILTERS + LISTING (shown to BOTH admin and user, all entries)
============================================================= */

$f_hall   = trim($_GET['hall'] ?? '');
$f_status = trim($_GET['status'] ?? '');
$f_date   = trim($_GET['plan_date'] ?? '');
$f_search = trim($_GET['search'] ?? '');

$where  = [];
$params = [];
$types  = "";

if (in_array($f_hall, $HALLS, true)) {
    $where[] = "hall = ?";
    $params[] = $f_hall;
    $types .= "s";
}
if (in_array($f_status, $STATUSES, true)) {
    $where[] = "status = ?";
    $params[] = $f_status;
    $types .= "s";
}
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $f_date)) {
    $where[] = "plan_date = ?";
    $params[] = $f_date;
    $types .= "s";
}
if ($f_search !== '') {
    $where[] = "cb_serial_no LIKE ?";
    $params[] = "%$f_search%";
    $types .= "s";
}

$sql = "SELECT * FROM day_plans";
if ($where) {
    $sql .= " WHERE " . implode(" AND ", $where);
}
$sql .= " ORDER BY plan_date DESC, id DESC";

if ($params) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $rows = $stmt->get_result();
} else {
    $rows = $conn->query($sql);
}

?>
<?php require __DIR__ . "/header.php"; ?>
<?php require __DIR__ . "/" . $sidebar_include; ?>

<div class="content">
    <div class="container-fluid">

        <h3 class="mb-3">Day Plan (CB1 / CB2)</h3>

        <?php if (!empty($msg)): ?>
            <div class="alert alert-<?= htmlspecialchars($msgType) ?>"><?= $msg /* already escaped above */ ?></div>
        <?php endif; ?>

        <!-- ================= ADD TO PLAN ================= -->
        <div class="card mb-4">
            <div class="card-body">

                <form method="POST" id="dayPlanForm">
                    <?php csrf_field(); ?>
                    <input type="hidden" name="is_extra" id="is_extra_field" value="0">

                    <div class="row g-2">

                        <div class="col-md-3">
                            <label class="form-label">CB Serial No</label>
                            <input type="text" name="cb_serial_no" class="form-control" required>
                        </div>

                        <div class="col-md-2">
                            <label class="form-label">Hall</label>
                            <select name="hall" class="form-select" required>
                                <option value="CB1">CB1</option>
                                <option value="CB2">CB2</option>
                            </select>
                        </div>

                        <div class="col-md-2">
                            <label class="form-label">Plan Date</label>
                            <input type="date" name="plan_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
                        </div>

                        <div class="col-md-2">
                            <label class="form-label">Quantity</label>
                            <input type="number" name="quantity" class="form-control" value="1" min="1" required>
                        </div>

                        <div class="col-md-3">
                            <label class="form-label">Remark</label>
                            <input type="text" name="remark" class="form-control">
                        </div>

                    </div>

                    <!-- Extra fields: only used/required when "Add Extra Entry" is toggled on -->
                    <div id="extraFields" class="row g-2 mt-1" style="display:none;">
                        <div class="col-12">
                            <hr>
                            <span class="badge bg-warning text-dark mb-2">
                                Extra Entry — product made outside the plan
                            </span>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Spare</label>
                            <input type="text" name="spare" class="form-control">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">SO No</label>
                            <input type="text" name="so_no_new" class="form-control">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Region</label>
                            <input type="text" name="region" class="form-control">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Customer</label>
                            <input type="text" name="customer" class="form-control">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Product</label>
                            <input type="text" name="product" class="form-control">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Creepage</label>
                            <input type="text" name="creepage" class="form-control">
                        </div>
                    </div>

                    <div class="mt-3 d-flex gap-2">
                        <button type="submit" name="add_plan" class="btn btn-success">
                            Add to Plan
                        </button>
                        <button type="button" id="toggleExtraBtn" class="btn btn-outline-warning">
                            + Add Extra Entry (not in plan)
                        </button>
                    </div>

                    <div class="form-text mt-2">
                        Normal entries auto-fill Spare / SO No / Region / Customer / Product / Creepage from the uploaded plan
                        using the CB Serial No. A CB Serial No already marked <strong>Completed</strong>, already has a
                        <strong>product created</strong> for it, or is <strong>already planned for the same day</strong>
                        cannot be added again. Only one entry per CB Serial No is allowed per day.
                    </div>
                </form>

            </div>
        </div>

        <!-- ================= FILTERS ================= -->
        <div class="card mb-3">
            <div class="card-body">
                <form method="GET" class="row g-2 align-items-end">
                    <div class="col-md-3">
                        <label class="form-label">Search CB Serial</label>
                        <input type="text" name="search" class="form-control" value="<?= htmlspecialchars($f_search) ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Hall</label>
                        <select name="hall" class="form-select">
                            <option value="">All</option>
                            <?php foreach ($HALLS as $h): ?>
                                <option value="<?= $h ?>" <?= $f_hall === $h ? 'selected' : '' ?>><?= $h ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Status</label>
                        <select name="status" class="form-select">
                            <option value="">All</option>
                            <?php foreach ($STATUSES as $s): ?>
                                <option value="<?= $s ?>" <?= $f_status === $s ? 'selected' : '' ?>><?= $s ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label class="form-label">Plan Date</label>
                        <input type="date" name="plan_date" class="form-control" value="<?= htmlspecialchars($f_date) ?>">
                    </div>
                    <div class="col-md-2">
                        <button class="btn btn-primary w-100">Filter</button>
                    </div>
                    <div class="col-md-1">
                        <a href="day_plan.php" class="btn btn-secondary w-100">Reset</a>
                    </div>
                </form>
                <div class="mt-2">
                    <a href="download_day_plan.php?<?= htmlspecialchars(http_build_query([
                            'hall' => $f_hall, 'status' => $f_status,
                            'plan_date' => $f_date, 'search' => $f_search,
                        ])) ?>" class="btn btn-outline-success btn-sm">
                        <i class="bi bi-file-earmark-excel"></i> Download Excel
                    </a>
                    <span class="text-muted small ms-2">Downloads the list below using the current filters.</span>
                </div>
            </div>
        </div>

        <!-- ================= LIST (visible to admin AND user) ================= -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">All Plan Entries</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover align-middle" style="font-size:13px;">
                        <thead class="table-dark">
                            <tr>
                                <th>CB Serial</th>
                                <th>Hall</th>
                                <th>Plan Date</th>
                                <th>Product</th>
                                <th>Customer</th>
                                <th>Qty</th>
                                <th>Extra?</th>
                                <th>Status</th>
                                <th>Added By</th>
                                <th style="width:160px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if ($rows && $rows->num_rows > 0): ?>
                            <?php while ($r = $rows->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($r['cb_serial_no']) ?></td>
                                    <td><?= htmlspecialchars($r['hall']) ?></td>
                                    <td><?= htmlspecialchars($r['plan_date']) ?></td>
                                    <td><?= htmlspecialchars($r['product'] ?? '') ?></td>
                                    <td><?= htmlspecialchars($r['customer'] ?? '') ?></td>
                                    <td><?= (int)$r['quantity'] ?></td>
                                    <td>
                                        <?php if ((int)$r['is_extra'] === 1): ?>
                                            <span class="badge bg-warning text-dark">Extra</span>
                                        <?php else: ?>
                                            <span class="text-muted">-</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <!-- Quick status change: Incomplete / Process / Completed -->
                                        <form method="POST" class="d-flex gap-1">
                                            <?php csrf_field(); ?>
                                            <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                            <select name="status" class="form-select form-select-sm"
                                                    onchange="this.form.submit()">
                                                <?php foreach ($STATUSES as $s): ?>
                                                    <option value="<?= $s ?>" <?= $r['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
                                                <?php endforeach; ?>
                                            </select>
                                            <button type="submit" name="set_status" class="d-none">Save</button>
                                        </form>
                                    </td>
                                    <td><?= htmlspecialchars($r['added_by'] ?? '') ?></td>
                                    <td>
                                        <button type="button" class="btn btn-warning btn-sm"
                                                data-bs-toggle="modal"
                                                data-bs-target="#editModal<?= (int)$r['id'] ?>">
                                            Update
                                        </button>
                                        <a href="day_plan.php?delete=<?= (int)$r['id'] ?>&csrf_token=<?= urlencode(csrf_token()) ?>"
                                           class="btn btn-danger btn-sm"
                                           onclick="return confirm('Delete this plan entry?');">
                                            Delete
                                        </a>
                                    </td>
                                </tr>

                                <!-- Update modal -->
                                <div class="modal fade" id="editModal<?= (int)$r['id'] ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <form method="POST">
                                                <?php csrf_field(); ?>
                                                <input type="hidden" name="id" value="<?= (int)$r['id'] ?>">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Update Plan — <?= htmlspecialchars($r['cb_serial_no']) ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <div class="mb-2">
                                                        <label class="form-label">Hall</label>
                                                        <select name="hall" class="form-select">
                                                            <?php foreach ($HALLS as $h): ?>
                                                                <option value="<?= $h ?>" <?= $r['hall'] === $h ? 'selected' : '' ?>><?= $h ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <div class="mb-2">
                                                        <label class="form-label">Plan Date</label>
                                                        <input type="date" name="plan_date" class="form-control" value="<?= htmlspecialchars($r['plan_date']) ?>" required>
                                                    </div>
                                                    <div class="mb-2">
                                                        <label class="form-label">Quantity</label>
                                                        <input type="number" name="quantity" class="form-control" value="<?= (int)$r['quantity'] ?>" min="1" required>
                                                    </div>
                                                    <div class="mb-2">
                                                        <label class="form-label">Status</label>
                                                        <select name="status" class="form-select">
                                                            <?php foreach ($STATUSES as $s): ?>
                                                                <option value="<?= $s ?>" <?= $r['status'] === $s ? 'selected' : '' ?>><?= $s ?></option>
                                                            <?php endforeach; ?>
                                                        </select>
                                                    </div>
                                                    <div class="mb-2">
                                                        <label class="form-label">Remark</label>
                                                        <input type="text" name="remark" class="form-control" value="<?= htmlspecialchars($r['remark'] ?? '') ?>">
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="submit" name="update_plan" class="btn btn-success">Save Changes</button>
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>

                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr><td colspan="10" class="text-center">No plan entries found.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </div>
</div>

</div><!-- closes the .d-flex div opened in header.php -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

<script>
// Toggle the "Extra Entry" fields on/off, and flag the hidden is_extra field.
document.getElementById('toggleExtraBtn').addEventListener('click', function () {
    var box = document.getElementById('extraFields');
    var flag = document.getElementById('is_extra_field');
    var isOn = box.style.display !== 'none';

    box.style.display = isOn ? 'none' : 'flex';
    flag.value = isOn ? '0' : '1';
    this.textContent = isOn
        ? '+ Add Extra Entry (not in plan)'
        : '- Cancel Extra Entry';
    this.classList.toggle('btn-outline-warning', isOn);
    this.classList.toggle('btn-warning', !isOn);
});
</script>

</body>
</html>
