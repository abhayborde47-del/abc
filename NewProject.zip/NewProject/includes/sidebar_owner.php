<?php
// includes/sidebar_owner.php
// Assumes session already started and owner auth already verified by the calling page
?>

<!-- Owner Sidebar -->
<div class="sidebar bg-light border-end" id="sidebar">
  <ul class="nav flex-column p-2">
    <li class="nav-item">
      <a class="nav-link" href="dashboard.php">Dashboard</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="manage_admins.php">Manage Admins</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="manage_users.php">Manage Users</a>
    </li>
  </ul>
</div>
