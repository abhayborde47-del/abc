<?php
// includes/auth_admin_store.php
// Restricts pages in /store_admin to admin_type 'store' or 'owner'.
// A few store_admin pages previously only checked "is some admin logged in"
// (via auth_admin.php) without checking type - this closes that gap.
// Assumes config.php (session_start) has already run.

if (!isset($_SESSION['admin_email']) || !in_array($_SESSION['admin_type'] ?? '', ['store', 'owner'], true)) {
    header("Location: ../login.php");
    exit;
}
