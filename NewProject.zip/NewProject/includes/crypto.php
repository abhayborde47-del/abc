<?php
/**
 * crypto.php
 * ---------------------------------------------------------------
 * Reversible encryption for passwords that Admin/Owner are allowed
 * to view in plain text (see includes/reveal_password.php).
 *
 * This is SEPARATE from the bcrypt hash used for login
 * (users.password / admins.password) — that hash still governs
 * authentication and is never touched here. This module only
 * manages `password_enc`, a reversible copy used purely for display.
 *
 * SECURITY NOTE: storing a reversible copy of a password is a
 * deliberate trade-off for this internal tool. It weakens the
 * guarantee a bcrypt-only system gives. Keep ENCRYPTION_KEY (in
 * config.php) secret, and rely on the role checks + re-auth step in
 * reveal_password.php to control who can actually view a password.
 */

function pw_encrypt(string $plaintext): string {
    $key    = hash('sha256', ENCRYPTION_KEY, true); // 32 raw bytes for AES-256
    $iv     = random_bytes(16);
    $cipher = openssl_encrypt($plaintext, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return base64_encode($iv . $cipher);
}

function pw_decrypt(?string $encoded): ?string {
    if (empty($encoded)) {
        return null;
    }

    $raw = base64_decode($encoded, true);
    if ($raw === false || strlen($raw) <= 16) {
        return null;
    }

    $iv     = substr($raw, 0, 16);
    $cipher = substr($raw, 16);
    $key    = hash('sha256', ENCRYPTION_KEY, true);

    $plain = openssl_decrypt($cipher, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);
    return $plain === false ? null : $plain;
}
