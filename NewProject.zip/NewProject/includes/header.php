<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>LogNest</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>

<nav class="navbar navbar-dark bg-dark px-3">
  <div class="d-flex align-items-center">
    <button class="btn btn-outline-light d-md-none me-2" id="sidebarToggle">&#9776;</button>
    <span class="navbar-brand mb-0 h1">
      <img src="../assets/logo.png" onerror="this.style.display='none'" height="30" class="me-2">
      LogNest
    </span>
  </div>
  <a href="../logout.php" class="btn btn-outline-light btn-sm">Logout</a>
</nav>

<div class="d-flex">
