<?php

/*
|--------------------------------------------------------------------------
| SSControl Sidebar
|--------------------------------------------------------------------------
*/

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| ACCESS CHECK
|--------------------------------------------------------------------------
*/

if (
    !isset($_SESSION['user_id']) ||
    !isset($_SESSION['user_department'])
) {

    header("Location: ../login.php");
    exit;
}


/*
|--------------------------------------------------------------------------
| ONLY SSCONTROL USERS
|--------------------------------------------------------------------------
*/

if (
    strtolower(trim($_SESSION['user_department']))
    !== 'sscontrol'
) {

    header("Location: ../login.php");
    exit;
}

?>

<!-- SSControl Sidebar -->

<div
    class="sidebar bg-light border-end"
    id="sidebar"
>

    <ul class="nav flex-column p-2">

        <!-- ADD -->

        <li class="nav-item mb-1">

            <a
                class="nav-link"
                href="add.php"
            >
                Add
            </a>

        </li>


        <!-- VIEW -->

        <li class="nav-item">

            <a
                class="nav-link"
                href="view.php"
            >
                View
            </a>

        </li>

    </ul>

</div>