<?php
// includes/storesidebar_view.php
// Sidebar for Storeview (supervisor) pages.
// Assumes session already started and user auth already verified by the calling page
?>

<!-- Store Supervisor Sidebar -->
<div class="sidebar bg-light border-end" id="sidebar">
  <ul class="nav flex-column p-2">
    <li class="nav-item">
      <a class="nav-link" href="shortage.php">Shortage</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="queries.php">My Queries</a>
    </li>
  </ul>
</div>