<div class="sidebar bg-light border-end" id="sidebar">
  <ul class="nav flex-column p-2">

    <!-- Product Section -->
    <li class="nav-item">
      <a class="nav-link d-flex justify-content-between align-items-center" 
         data-bs-toggle="collapse" 
         href="#productSubmenu" 
         role="button" 
         aria-expanded="false" 
         aria-controls="productSubmenu">
        Product
        <i class="bi bi-chevron-down"></i>
      </a>
      <div class="collapse" id="productSubmenu">
        <ul class="nav flex-column ms-3">
          <li class="nav-item">
            <a class="nav-link" href="add_product.php">Add Product</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="history.php">History</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="day_plan.php">Day Plan (CB1 / CB2)</a>
          </li>
        </ul>
      </div>
    </li>

    <!-- Employee Section -->
    <li class="nav-item">
      <a class="nav-link d-flex justify-content-between align-items-center" 
         data-bs-toggle="collapse" 
         href="#employeeSubmenu" 
         role="button" 
         aria-expanded="false" 
         aria-controls="employeeSubmenu">
        Employee
        <i class="bi bi-chevron-down"></i>
      </a>
      <div class="collapse" id="employeeSubmenu">
        <ul class="nav flex-column ms-3">

          <!-- Attendance nested submenu -->
          <li class="nav-item">
            <a class="nav-link d-flex justify-content-between align-items-center"
               data-bs-toggle="collapse"
               href="#attendanceSubmenu"
               role="button"
               aria-expanded="false"
               aria-controls="attendanceSubmenu">
              Attendance
              <i class="bi bi-chevron-down"></i>
            </a>
            <div class="collapse" id="attendanceSubmenu">
              <ul class="nav flex-column ms-3">
                <li class="nav-item">
                  <a class="nav-link" href="add_attendance.php">Add Attendance</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="view_attendance.php">View Attendance</a>
                </li>
              </ul>
            </div>
          </li>

          <!-- Plan vs Actual nested submenu -->
          <li class="nav-item">
            <a class="nav-link d-flex justify-content-between align-items-center"
               data-bs-toggle="collapse"
               href="#planActualSubmenu"
               role="button"
               aria-expanded="false"
               aria-controls="planActualSubmenu">
              Plan vs Actual
              <i class="bi bi-chevron-down"></i>
            </a>
            <div class="collapse" id="planActualSubmenu">
              <ul class="nav flex-column ms-3">
                <li class="nav-item">
                  <a class="nav-link" href="add_plan_actual.php">Add Entry</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="view_plan_actual.php">View Entries</a>
                </li>
              </ul>
            </div>
          </li>

        </ul>
      </div>
    </li>

    <!-- My Queries -->
    <li class="nav-item">
      <a class="nav-link" href="queries.php">My Queries</a>
    </li>

  </ul>
</div>

<script>
// Keep the sidebar submenu open for whichever page is currently active,
// instead of it collapsing back closed on every page load/navigation.
(function () {
    var currentPage = window.location.pathname.split('/').pop();

    var activeLink = document.querySelector('.sidebar .nav-link[href="' + currentPage + '"]');
    if (!activeLink) return;

    activeLink.classList.add('active');

    var el = activeLink;
    while (el) {
        var parentCollapse = el.closest('.collapse');
        if (!parentCollapse) break;

        parentCollapse.classList.add('show');

        var toggle = document.querySelector('[href="#' + parentCollapse.id + '"]');
        if (toggle) {
            toggle.setAttribute('aria-expanded', 'true');
            toggle.classList.remove('collapsed');
        }

        el = parentCollapse.parentElement;
    }
})();
</script>