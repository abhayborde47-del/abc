<?php
/**
 * reveal_password.php
 * ---------------------------------------------------------------
 * AJAX endpoint: lets an authorised Admin/Owner see a user's or
 * admin's actual password.
 *
 * EXTRA SECURITY LAYER: the viewer must re-enter THEIR OWN current
 * login password before anything is revealed. This protects against
 * an already-open/unlocked session being used to dump every password
 * in the system in one go. Every successful reveal is written to
 * activity_logs for audit purposes; every failed re-auth attempt
 * counts against the normal login lockout counter.
 *
 * POST params:
 *   csrf_token       - standard CSRF token
 *   type             - 'user' or 'admin'
 *   target_id        - id of the users/admins row to reveal
 *   confirm_password - the logged-in admin/owner's own password
 *
 * Who can view what:
 *   type=user   -> admin_type must be 'owner' or 'AIS'
 *   type=admin  -> admin_type must be 'owner'   (only Owner sees other admins)
 */

require __DIR__ . "/../config.php";
require __DIR__ . "/security.php";
require __DIR__ . "/crypto.php";

header('Content-Type: application/json');

function reveal_fail(string $msg, int $code = 400): void {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $msg]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    reveal_fail('Invalid request method.', 405);
}

// Must already be logged in as an admin/owner
if (!isset($_SESSION['admin_email'], $_SESSION['admin_id'])) {
    reveal_fail('Not authorized.', 403);
}

// CSRF check
if (empty($_SESSION['csrf_token']) || empty($_POST['csrf_token']) ||
    !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    reveal_fail('Security check failed. Refresh the page and try again.', 403);
}

$type      = $_POST['type'] ?? '';
$target_id = (int)($_POST['target_id'] ?? 0);
$confirm   = (string)($_POST['confirm_password'] ?? '');
$adminType = $_SESSION['admin_type'] ?? '';
$viewerEmail = $_SESSION['admin_email'];

if (!in_array($type, ['user', 'admin'], true) || $target_id <= 0 || $confirm === '') {
    reveal_fail('Missing or invalid parameters.');
}

// Role check
if ($type === 'user' && !in_array($adminType, ['owner', 'AIS'], true)) {
    reveal_fail('You are not allowed to view user passwords.', 403);
}
if ($type === 'admin' && $adminType !== 'owner') {
    reveal_fail('Only the Owner can view admin passwords.', 403);
}

// Rate-limit re-auth attempts the same way login itself is rate-limited
if (login_is_locked_out($conn, $viewerEmail)) {
    reveal_fail('Too many failed attempts. Please try again later.', 429);
}

// Re-authenticate: confirm the viewer's OWN current password
$selfStmt = $conn->prepare("SELECT password FROM admins WHERE id = ?");
$selfStmt->bind_param("i", $_SESSION['admin_id']);
$selfStmt->execute();
$self = $selfStmt->get_result()->fetch_assoc();

if (!$self || !password_verify($confirm, $self['password'])) {
    login_record_failure($conn, $viewerEmail);
    reveal_fail('Your password was incorrect.', 403);
}
login_clear_attempts($conn, $viewerEmail);

// Fetch + decrypt target password
$table = $type === 'user' ? 'users' : 'admins';
$stmt = $conn->prepare("SELECT email, password_enc FROM `$table` WHERE id = ?");
$stmt->bind_param("i", $target_id);
$stmt->execute();
$row = $stmt->get_result()->fetch_assoc();

if (!$row) {
    reveal_fail('Record not found.', 404);
}

$plain = pw_decrypt($row['password_enc']);

if ($plain === null) {
    reveal_fail('No viewable password stored for this account yet — set/reset its password once to enable viewing.', 404);
}

// Audit log (never log the password itself, only that it was viewed)
$logStmt = $conn->prepare("INSERT INTO activity_logs (user_email, action, description) VALUES (?, ?, ?)");
$action = "viewed_password";
$description = "Viewed password for {$type} #{$target_id} ({$row['email']})";
$logStmt->bind_param("sss", $viewerEmail, $action, $description);
$logStmt->execute();

echo json_encode(['ok' => true, 'password' => $plain]);
