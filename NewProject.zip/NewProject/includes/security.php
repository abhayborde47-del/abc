<?php
/**
 * security.php
 * -------------------------------------------------------
 * Small, dependency-free security helpers used across the app:
 *   1. CSRF token generation / verification
 *   2. Login rate-limiting (brute-force protection)
 *
 * Include this AFTER config.php (session_start() must already have run).
 */

/* =============================================================
   CSRF TOKEN HELPERS
============================================================= */

/**
 * Return the current CSRF token, creating one for this session
 * if it doesn't exist yet.
 */
function csrf_token() {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Echo a ready-to-use hidden <input> field for forms.
 * Usage inside a <form>: <?php csrf_field(); ?>
 */
function csrf_field() {
    echo '<input type="hidden" name="csrf_token" value="' . htmlspecialchars(csrf_token()) . '">';
}

/**
 * Verify a submitted token against the session token.
 * Call this at the top of every state-changing (POST, or
 * destructive GET like delete) request handler.
 *
 * On failure it stops the request with a 403 rather than silently
 * continuing, so a forged/expired request can never take effect.
 */
function csrf_verify($token) {
    if (empty($_SESSION['csrf_token']) || empty($token) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        die('Security check failed (invalid or expired form token). Please go back, refresh the page, and try again.');
    }
}


/* =============================================================
   LOGIN RATE LIMITING (BRUTE-FORCE PROTECTION)
   -------------------------------------------------------------
   Tracked per (email + IP) in the database so it survives across
   sessions/tabs and can't be bypassed by simply clearing cookies.
============================================================= */

define('LOGIN_MAX_ATTEMPTS', 5);      // failed attempts allowed
define('LOGIN_LOCKOUT_MINUTES', 10);  // lockout window after max attempts

/**
 * Make sure the login_attempts table exists (safe to call every request).
 */
function login_attempts_ensure_table($conn) {
    $conn->query("
        CREATE TABLE IF NOT EXISTS login_attempts (
            id INT AUTO_INCREMENT PRIMARY KEY,
            identifier VARCHAR(150) NOT NULL,
            ip_address VARCHAR(45) NOT NULL,
            attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_identifier (identifier),
            INDEX idx_attempted_at (attempted_at)
        )
    ");
}

function client_ip() {
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

/**
 * Returns true (and blocks) if this email/IP combo has exceeded the
 * allowed number of failed attempts within the lockout window.
 */
function login_is_locked_out($conn, $email) {
    login_attempts_ensure_table($conn);

    $identifier = strtolower(trim($email));
    $ip = client_ip();

    $stmt = $conn->prepare(
        "SELECT COUNT(*) AS c FROM login_attempts
         WHERE identifier = ? AND ip_address = ?
         AND attempted_at > (NOW() - INTERVAL ? MINUTE)"
    );
    $minutes = LOGIN_LOCKOUT_MINUTES;
    $stmt->bind_param("ssi", $identifier, $ip, $minutes);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();

    return ((int)$row['c']) >= LOGIN_MAX_ATTEMPTS;
}

/**
 * Record a failed login attempt.
 */
function login_record_failure($conn, $email) {
    login_attempts_ensure_table($conn);

    $identifier = strtolower(trim($email));
    $ip = client_ip();

    $stmt = $conn->prepare(
        "INSERT INTO login_attempts (identifier, ip_address) VALUES (?, ?)"
    );
    $stmt->bind_param("ss", $identifier, $ip);
    $stmt->execute();
}

/**
 * Clear attempts after a successful login.
 */
function login_clear_attempts($conn, $email) {
    login_attempts_ensure_table($conn);

    $identifier = strtolower(trim($email));
    $ip = client_ip();

    $stmt = $conn->prepare(
        "DELETE FROM login_attempts WHERE identifier = ? AND ip_address = ?"
    );
    $stmt->bind_param("ss", $identifier, $ip);
    $stmt->execute();
}
