<?php
// includes/sidebar_adiuser.php
// Assumes session already started and ADI-user (department='adi') auth already verified by the calling page
?>

<!-- ADI User Sidebar -->
<div class="sidebar bg-light border-end" id="sidebar">
  <ul class="nav flex-column p-2">
    <li class="nav-item">
      <a class="nav-link" href="dashboard.php">Dashboard</a>
    </li>
  </ul>
</div>