<?php
// includes/auth_admin_ais.php
// Restricts pages in /admin (the AIS admin panel) to admin_type 'AIS' or 'owner'.
// Assumes config.php (session_start) has already run.

if (!isset($_SESSION['admin_email']) || !in_array($_SESSION['admin_type'] ?? '', ['AIS', 'owner'], true)) {
    header("Location: ../login.php");
    exit;
}
