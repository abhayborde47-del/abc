<?php
// includes/storesidebar_admin.php
// Assumes session already started and admin auth already verified by the calling page
?>

<!-- Store Admin Sidebar -->
<div class="sidebar bg-light border-end" id="sidebar">
  <ul class="nav flex-column p-2">
    <li class="nav-item">
      <a class="nav-link" href="add_user.php">Add User</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="upload_plan.php">Add Plan</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="search_plan.php">View Plan</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="add_shortage.php">Add Shortage</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="view_shortage.php">View Shortage</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="dashboard.php">Dashboard</a>
    </li>
  </ul>
</div>
