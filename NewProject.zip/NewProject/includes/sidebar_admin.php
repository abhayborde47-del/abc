<div class="sidebar bg-light border-end" id="sidebar">
  <ul class="nav flex-column p-2">

    <!-- Dashboard -->
    

    

    <!-- Plan Section -->
    <li class="nav-item">
      <a class="nav-link d-flex justify-content-between align-items-center"
         data-bs-toggle="collapse"
         href="#planSubmenu"
         role="button"
         aria-expanded="false"
         aria-controls="planSubmenu">
        Plan
        <i class="bi bi-chevron-down"></i>
      </a>
      <div class="collapse" id="planSubmenu">
        <ul class="nav flex-column ms-3">
          <li class="nav-item">
            <a class="nav-link" href="upload_plan.php">Upload Plan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="view_plan.php">View Plan</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="day_plan.php">Day Plan (CB1 / CB2)</a>
          </li>
        </ul>
      </div>
    </li>

    <!-- Product Section -->
    <li class="nav-item">
      <a class="nav-link d-flex justify-content-between align-items-center" 
         data-bs-toggle="collapse" 
         href="#productSubmenu" 
         role="button" 
         aria-expanded="false" 
         aria-controls="productSubmenu">
        Product
        <i class="bi bi-chevron-down"></i>
      </a>
      <div class="collapse" id="productSubmenu">
        <ul class="nav flex-column ms-3">
          <li class="nav-item">
            <a class="nav-link" href="add_product.php">Add Product</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="history.php">History</a>
          </li>
        </ul>
      </div>
    </li>

    <!-- Employee Section -->
    <li class="nav-item">
      <a class="nav-link d-flex justify-content-between align-items-center" 
         data-bs-toggle="collapse" 
         href="#employeeSubmenu" 
         role="button" 
         aria-expanded="false" 
         aria-controls="employeeSubmenu">
        Employee
        <i class="bi bi-chevron-down"></i>
      </a>
      <div class="collapse" id="employeeSubmenu">
        <ul class="nav flex-column ms-3">

          <li class="nav-item">
            <a class="nav-link" href="employees.php">Employee List</a>
          </li>

          <!-- Bulk employee upload — a distinct feature from daily Attendance -->
          <li class="nav-item">
            <a class="nav-link" href="attendance_upload.php">Upload Employees</a>
          </li>

          <!-- Attendance nested submenu -->
          <li class="nav-item">
            <a class="nav-link d-flex justify-content-between align-items-center"
               data-bs-toggle="collapse"
               href="#attendanceSubmenu"
               role="button"
               aria-expanded="false"
               aria-controls="attendanceSubmenu">
              Attendance
              <i class="bi bi-chevron-down"></i>
            </a>
            <div class="collapse" id="attendanceSubmenu">
              <ul class="nav flex-column ms-3">
                <li class="nav-item">
                  <a class="nav-link" href="add_attendance.php">Add Attendance</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="view_attendance.php">View Attendance</a>
                </li>
              </ul>
            </div>
          </li>

          <!-- Plan vs Actual nested submenu -->
          <li class="nav-item">
            <a class="nav-link d-flex justify-content-between align-items-center"
               data-bs-toggle="collapse"
               href="#planActualSubmenu"
               role="button"
               aria-expanded="false"
               aria-controls="planActualSubmenu">
              Plan vs Actual
              <i class="bi bi-chevron-down"></i>
            </a>
            <div class="collapse" id="planActualSubmenu">
              <ul class="nav flex-column ms-3">
                <li class="nav-item">
                  <a class="nav-link" href="add_plan_actual.php">Add Entry</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="view_plan_actual.php">View Entries</a>
                </li>
              </ul>
            </div>
          </li>

        </ul>
      </div>
    </li>
    <li class="nav-item">
            <a class="nav-link d-flex justify-content-between align-items-center"
               data-bs-toggle="collapse"
               href="#attendanceSubmenu"
               role="button"
               aria-expanded="false"
               aria-controls="attendanceSubmenu">
              SsControl
              <i class="bi bi-chevron-down"></i>
            </a>
            <div class="collapse" id="attendanceSubmenu">
              <ul class="nav flex-column ms-3">
                <li class="nav-item">
                  <a
                class="nav-link"
                href="add.php"
            >
                Add
            </a>
                </li>
                <li class="nav-item">
                  <a
                class="nav-link"
                href="view.php"
            >
                View
            </a>
                </li>
              </ul>
            </div>
          </li>

    <!-- User Management Section -->
    <li class="nav-item">
      <a class="nav-link d-flex justify-content-between align-items-center"
         data-bs-toggle="collapse"
         href="#userSubmenu"
         role="button"
         aria-expanded="false"
         aria-controls="userSubmenu">
        Users
        <i class="bi bi-chevron-down"></i>
      </a>
      <div class="collapse" id="userSubmenu">
        <ul class="nav flex-column ms-3">
          <li class="nav-item">
            <a class="nav-link" href="add_user.php">Add User</a>
          </li>
        </ul>
      </div>
    </li>

    <!-- My Queries -->
    <li class="nav-item">
      <a class="nav-link" href="queries.php">My Queries</a>
    </li>
    

  </ul>
</div>

<style>
/* Sidebar link styling — hover + open state.
   No existing colors changed; hover/open use neutral tints only. */

.sidebar .nav-link {
    display: flex;
    align-items: center;
    border-radius: 6px;
    padding: 8px 10px;
    margin-bottom: 2px;
    transition: background-color 0.15s ease, padding-left 0.15s ease;
}

/* Hover state — subtle neutral tint, no brand color change */
.sidebar .nav-link:hover {
    background-color: rgba(0, 0, 0, 0.05);
    padding-left: 14px;
}

/* Open/expanded state — distinct from plain hover so users can tell
   a section is currently open even without hovering it */
.sidebar .nav-link[aria-expanded="true"] {
    background-color: rgba(0, 0, 0, 0.08);
    font-weight: 600;
}

/* Open state still gets a slightly stronger tint on hover, so it
   doesn't look "stuck" the same as a closed hovered item */
.sidebar .nav-link[aria-expanded="true"]:hover {
    background-color: rgba(0, 0, 0, 0.12);
}

/* Currently active page link (set by the script below) */
.sidebar .nav-link.active {
    background-color: rgba(0, 0, 0, 0.08);
    font-weight: 600;
}

/* Chevron rotates smoothly when a submenu opens */
.sidebar .nav-link .bi-chevron-down {
    transition: transform 0.2s ease;
}

.sidebar .nav-link[aria-expanded="true"] .bi-chevron-down {
    transform: rotate(180deg);
}

/* Nested submenu items sit slightly smaller/dimmer until hovered */
.sidebar .collapse .nav-link {
    font-size: 0.93rem;
    opacity: 0.85;
}

.sidebar .collapse .nav-link:hover,
.sidebar .collapse .nav-link.active {
    opacity: 1;
}
</style>

<script>
// Keep the sidebar submenu open for whichever page is currently active,
// instead of it collapsing back closed on every page load/navigation.
(function () {
    var currentPage = window.location.pathname.split('/').pop();

    var activeLink = document.querySelector('.sidebar .nav-link[href="' + currentPage + '"]');
    if (!activeLink) return;

    activeLink.classList.add('active');

    var el = activeLink;
    while (el) {
        var parentCollapse = el.closest('.collapse');
        if (!parentCollapse) break;

        parentCollapse.classList.add('show');

        var toggle = document.querySelector('[href="#' + parentCollapse.id + '"]');
        if (toggle) {
            toggle.setAttribute('aria-expanded', 'true');
            toggle.classList.remove('collapsed');
        }

        el = parentCollapse.parentElement;
    }
})();
</script>