<?php
// includes/sidebar_adi.php
// Assumes session already started and ADI admin auth already verified by the calling page
?>

<!-- ADI Admin Sidebar -->
<div class="sidebar bg-light border-end" id="sidebar">
  <ul class="nav flex-column p-2">
    <li class="nav-item">
      <a class="nav-link" href="dashboard.php">Dashboard</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="manage_users.php">Manage ADI Users</a>
    </li>
  </ul>
</div>