<?php
// includes/storesidebar_user.php
// Sidebar for Storeuser (storeemp) pages.
// Assumes session already started and user auth already verified by the calling page
?>

<!-- Store Employee Sidebar -->
<div class="sidebar bg-light border-end" id="sidebar">
  <ul class="nav flex-column p-2">
    <li class="nav-item">
      <a class="nav-link" href="add_shortage.php">Add Shortage</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="view_shortage.php">View Shortage</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="queries.php">My Queries</a>
    </li>
  </ul>
</div>