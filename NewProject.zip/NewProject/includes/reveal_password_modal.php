<!-- Reveal-password re-auth modal (see includes/reveal_password.php) -->
<div class="modal fade" id="revealPasswordModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Confirm Your Identity</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <p class="text-muted small mb-3">
            For security, re-enter <strong>your own</strong> login password to view this account's password.
        </p>
        <div id="revealPasswordError" class="alert alert-danger py-2 d-none"></div>
        <input type="password"
               id="revealPasswordInput"
               class="form-control"
               placeholder="Your password"
               autocomplete="current-password">
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="button" id="revealPasswordConfirmBtn" class="btn btn-primary">View Password</button>
      </div>
    </div>
  </div>
</div>
