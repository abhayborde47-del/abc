<?php
// includes/auth_owner.php
// Include this at the top of every page inside /owner/
// Assumes config.php (session_start) has already run.

if (!isset($_SESSION['admin_email']) || ($_SESSION['admin_type'] ?? '') !== 'owner') {
    header("Location: ../login.php");
    exit;
}
