<?php
/**
 * includes/day_plan_download_shared.php
 * -------------------------------------------------------
 * Downloads the Day Plan (CB1/CB2) list as an Excel-openable
 * CSV file, honoring the same filters used on the day_plan.php
 * screen (hall, status, plan_date, search).
 *
 * The caller (admin/download_day_plan.php or
 * user/download_day_plan.php) must require config.php and the
 * correct auth include BEFORE requiring this file.
 */

$HALLS    = ['CB1', 'CB2'];
$STATUSES = ['Incomplete', 'Process', 'Completed'];

$f_hall   = trim($_GET['hall'] ?? '');
$f_status = trim($_GET['status'] ?? '');
$f_date   = trim($_GET['plan_date'] ?? '');
$f_search = trim($_GET['search'] ?? '');

$where  = [];
$params = [];
$types  = "";

if (in_array($f_hall, $HALLS, true)) {
    $where[] = "hall = ?";
    $params[] = $f_hall;
    $types .= "s";
}
if (in_array($f_status, $STATUSES, true)) {
    $where[] = "status = ?";
    $params[] = $f_status;
    $types .= "s";
}
if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $f_date)) {
    $where[] = "plan_date = ?";
    $params[] = $f_date;
    $types .= "s";
}
if ($f_search !== '') {
    $where[] = "cb_serial_no LIKE ?";
    $params[] = "%$f_search%";
    $types .= "s";
}

$sql = "SELECT * FROM day_plans";
if ($where) {
    $sql .= " WHERE " . implode(" AND ", $where);
}
$sql .= " ORDER BY plan_date DESC, id DESC";

if ($params) {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $rows = $stmt->get_result();
} else {
    $rows = $conn->query($sql);
}

header('Content-Type: text/csv');
header('Content-Disposition: attachment; filename="day_plan_' . date('Y-m-d_His') . '.csv"');

$out = fopen('php://output', 'w');

fputcsv($out, [
    'CB Serial No', 'Hall', 'Plan Date', 'Spare', 'SO No New', 'Region',
    'Customer', 'Product', 'Creepage', 'Quantity', 'Extra Entry?',
    'Status', 'Remark', 'Added By', 'Updated By', 'Created At', 'Updated At',
]);

if ($rows) {
    while ($r = $rows->fetch_assoc()) {
        fputcsv($out, [
            $r['cb_serial_no'],
            $r['hall'],
            $r['plan_date'],
            $r['spare'],
            $r['so_no_new'],
            $r['region'],
            $r['customer'],
            $r['product'],
            $r['creepage'],
            $r['quantity'],
            ((int)$r['is_extra'] === 1) ? 'Yes' : 'No',
            $r['status'],
            $r['remark'],
            $r['added_by'],
            $r['updated_by'],
            $r['created_at'],
            $r['updated_at'],
        ]);
    }
}

fclose($out);
exit;
