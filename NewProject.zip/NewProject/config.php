<?php
session_start();
// ---- DB CONFIG (edit as per your server) ----
$host = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "plan_demo";

$conn = new mysqli($host, $dbuser, $dbpass, $dbname);
if ($conn->connect_error) {
    die("Database connection failed: " . $conn->connect_error);
}

// ---- REVERSIBLE PASSWORD ENCRYPTION KEY ----
// Used ONLY by includes/crypto.php to let Admin/Owner view a plaintext
// copy of a password (separate from the bcrypt hash used for login).
// IMPORTANT: change this to your own random value in production, and
// keep it out of version control (e.g. move it into an untracked
// config-local.php or an environment variable). If this key changes,
// any previously encrypted passwords can no longer be decrypted.
define('ENCRYPTION_KEY', 'ed0a9478a0fa830cb3b31ca207ecd30ab70faff2e2bd83c5a83b8fb644403445');
?>
