<?php
require "../config.php"; // config.php already calls session_start()
require "../includes/security.php";

// --- Auth guard: only logged-in ADI admins (or owner) allowed here ---
if (!isset($_SESSION['admin_email']) || !in_array($_SESSION['admin_type'] ?? '', ['ADI', 'owner'], true)) {
    header("Location: ../login.php");
    exit;
}
?>

<?php include "../includes/header.php"; ?>
  <?php include "../includes/sidebar_adi.php"; ?>

  <div class="content">
    <div class="container-fluid">
        <h3 class="mb-3">ADI Admin Dashboard</h3>

        <div class="alert alert-info">
            Welcome, <?= htmlspecialchars($_SESSION['admin_email']) ?>. This is a starter page for the
            ADI admin role &mdash; wire up whatever ADI-specific tools (plans, products, queries, etc.)
            this role needs, the same way <code>admin/</code> and <code>store_admin/</code> are built.
        </div>
    </div>
  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

</body>
</html>