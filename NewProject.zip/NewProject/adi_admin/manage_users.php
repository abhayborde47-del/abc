<?php
require "../config.php"; // config.php already calls session_start()
require "../includes/security.php";

// --- Auth guard: only logged-in ADI admins (or owner) allowed here ---
if (!isset($_SESSION['admin_email']) || !in_array($_SESSION['admin_type'] ?? '', ['ADI', 'owner'], true)) {
    header("Location: ../login.php");
    exit;
}

$message = "";
$error   = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify($_POST['csrf_token'] ?? '');
    $action = $_POST['action'] ?? '';

    if ($action === 'add_user') {
        $name     = trim($_POST['name'] ?? '');
        $email    = trim($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($name === '' || $email === '' || strlen($password) < 8) {
            $error = "Please fill all fields correctly (password must be at least 8 characters).";
        } else {
            $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $check->bind_param("s", $email);
            $check->execute();
            if ($check->get_result()->fetch_assoc()) {
                $error = "A user with that email already exists.";
            } else {
                $hash = password_hash($password, PASSWORD_BCRYPT);
                $stmt = $conn->prepare(
                    "INSERT INTO users (name, email, password, department, created_at)
                     VALUES (?, ?, ?, 'adi', NOW())"
                );
                $stmt->bind_param("sss", $name, $email, $hash);
                $stmt->execute();
                $message = "User \"$name\" added under ADI.";
            }
        }
    } elseif ($action === 'change_password') {
        $user_id      = (int)($_POST['user_id'] ?? 0);
        $new_password = $_POST['new_password'] ?? '';

        if (strlen($new_password) < 8) {
            $error = "New password must be at least 8 characters.";
        } else {
            $hash = password_hash($new_password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ? AND department = 'adi'");
            $stmt->bind_param("si", $hash, $user_id);
            $stmt->execute();
            $message = "Password updated.";
        }
    } elseif ($action === 'delete_user') {
        $user_id = (int)($_POST['user_id'] ?? 0);
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ? AND department = 'adi'");
        $stmt->bind_param("i", $user_id);
        $stmt->execute();
        $message = "User deleted.";
    }
}

// Only show users that belong to the ADI department
$users = $conn->prepare("SELECT id, name, email, created_at FROM users WHERE department = 'adi' ORDER BY created_at DESC");
$users->execute();
$users = $users->get_result();
?>

<?php include "../includes/header.php"; ?>
  <?php include "../includes/sidebar_adi.php"; ?>

  <div class="content">
    <div class="container-fluid">
        <h3 class="mb-3">Manage ADI Users</h3>

        <?php if ($message): ?><div class="alert alert-success"><?= htmlspecialchars($message) ?></div><?php endif; ?>
        <?php if ($error): ?><div class="alert alert-danger"><?= htmlspecialchars($error) ?></div><?php endif; ?>

        <!-- Add user -->
        <div class="card mb-4">
            <div class="card-header"><h5 class="mb-0">Add New ADI User</h5></div>
            <div class="card-body">
                <form method="POST" class="row g-3">
                    <?php csrf_field(); ?>
                    <input type="hidden" name="action" value="add_user">
                    <div class="col-md-4">
                        <label class="form-label">Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" minlength="8" required>
                    </div>
                    <div class="col-md-1 d-flex align-items-end">
                        <button type="submit" class="btn btn-success w-100">Add</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- User list -->
        <div class="card">
            <div class="card-header"><h5 class="mb-0">All ADI Users</h5></div>
            <div class="card-body">
                <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead>
                        <tr><th>Name</th><th>Email</th><th>Created</th><th style="width:340px">Actions</th></tr>
                    </thead>
                    <tbody>
                    <?php if ($users && $users->num_rows > 0): ?>
                        <?php while ($u = $users->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($u['name'] ?? '') ?></td>
                            <td><?= htmlspecialchars($u['email']) ?></td>
                            <td><?= htmlspecialchars($u['created_at']) ?></td>
                            <td>
                                <div class="d-flex flex-wrap gap-1">
                                    <form method="POST" class="d-flex gap-1">
                                        <?php csrf_field(); ?>
                                        <input type="hidden" name="action" value="change_password">
                                        <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                                        <input type="password" name="new_password" class="form-control form-control-sm" placeholder="New password" minlength="8" style="width:140px" required>
                                        <button class="btn btn-sm btn-outline-secondary">Reset</button>
                                    </form>
                                    <form method="POST" onsubmit="return confirm('Delete this user?');">
                                        <?php csrf_field(); ?>
                                        <input type="hidden" name="action" value="delete_user">
                                        <input type="hidden" name="user_id" value="<?= (int)$u['id'] ?>">
                                        <button class="btn btn-sm btn-outline-danger">Delete</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="4" class="text-center">No ADI users found</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                </div>
            </div>
        </div>
    </div>
  </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

</body>
</html>