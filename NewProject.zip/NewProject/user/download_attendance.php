<?php
require "../config.php";
require "../includes/auth_user.php";

$month   = $_GET['month']   ?? '';
$factory = $_GET['factory'] ?? '';

/* ------------------------------------------------------------
   STEP 1: No month chosen yet — ask for it first instead of
   generating the file straight away.
------------------------------------------------------------ */
if ($month === '') {

    $factories = [];
    $fRes = $conn->query("SELECT DISTINCT factory FROM employees WHERE factory <> '' ORDER BY factory");
    if ($fRes) {
        while ($row = $fRes->fetch_assoc()) {
            $factories[] = $row['factory'];
        }
    }
    ?>
    <?php require "../includes/header.php"; ?>
    <?php require "../includes/sidebar_user.php"; ?>

    <div class="content">
        <div class="container-fluid">

            <h3 class="mb-3">Download Attendance</h3>

            <div class="card" style="max-width:500px;">
                <div class="card-body">

                    <form method="GET">

                        <div class="mb-3">
                            <label class="form-label">Select Month</label>
                            <input type="month"
                                   name="month"
                                   class="form-control"
                                   value="<?= htmlspecialchars(date('Y-m')) ?>"
                                   required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Factory (optional)</label>
                            <select name="factory" class="form-control">
                                <option value="">All Factories</option>
                                <?php foreach ($factories as $f) : ?>
                                    <option value="<?= htmlspecialchars($f) ?>"
                                        <?= $f === $factory ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($f) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="row g-2">
                            <div class="col-6">
                                <button type="submit" class="btn btn-success w-100">
                                    Download Excel
                                </button>
                            </div>
                            <div class="col-6">
                                <a href="view_attendance.php" class="btn btn-secondary w-100">
                                    Cancel
                                </a>
                            </div>
                        </div>

                    </form>

                </div>
            </div>

        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>

    </body>
    </html>
    <?php
    exit;
}

/* ------------------------------------------------------------
   STEP 2: Month provided — generate the Excel (.xls) file,
   one row per employee per day (GID / Name / Date / Weekday / Status).
------------------------------------------------------------ */
$firstDay    = $month . '-01';
$daysInMonth = (int) date('t', strtotime($firstDay));

/* Employees */
if ($factory !== '') {
    $stmt = $conn->prepare("
        SELECT id, employee_code, name, factory
        FROM employees
        WHERE factory = ?
        ORDER BY name ASC
    ");
    $stmt->bind_param("s", $factory);
    $stmt->execute();
    $employees = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} else {
    $employees = $conn->query("
        SELECT id, employee_code, name, factory
        FROM employees
        ORDER BY factory ASC, name ASC
    ")->fetch_all(MYSQLI_ASSOC);
}

/* Attendance map: [employee_id][day] = status text ('Present' / 'Half Day' / 'Absent') */
$lastDay = $month . '-' . $daysInMonth;
$attMap  = [];
$stmt = $conn->prepare("
    SELECT employee_id, attendance_date, status
    FROM attendance
    WHERE attendance_date BETWEEN ? AND ?
");
$stmt->bind_param("ss", $firstDay, $lastDay);
$stmt->execute();
$res = $stmt->get_result();

while ($row = $res->fetch_assoc()) {
    $day = (int) date('j', strtotime($row['attendance_date']));
    $attMap[$row['employee_id']][$day] = $row['status'];
}

/* Readable month name for filename + title row, e.g. "August 2026" */
$monthLabel = DateTime::createFromFormat('Y-m-d', $firstDay)->format('F Y');

$filename = "Attendance_" . str_replace(' ', '_', $monthLabel)
          . ($factory !== '' ? "_{$factory}" : "")
          . ".xls";

/* Status -> font color map, matching the reference sheet */
$statusColors = [
    'Present'    => '2E7D32', // green
    'Absent'     => 'C62828', // red
    'Half Day'   => 'F9A825', // amber
    'Weekly Off' => 'E65100', // orange
];

/* Output as an Excel-readable HTML table (.xls). Works in Excel/LibreOffice
   without any extra PHP libraries. */
header("Content-Type: application/vnd.ms-excel; charset=UTF-8");
header("Content-Disposition: attachment; filename=\"$filename\"");
header("Pragma: public");

echo "\xEF\xBB\xBF"; // UTF-8 BOM so Excel reads names/special chars correctly
?>
<table border="1" cellspacing="0" cellpadding="4">
    <thead>
        <tr>
            <th colspan="5" style="background-color:#1B5E20; color:#FFFFFF; font-weight:bold; text-align:center; font-size:14px; padding:8px;">
                Attendance — <?= htmlspecialchars($monthLabel) ?><?= $factory !== '' ? ' (' . htmlspecialchars($factory) . ')' : '' ?>
            </th>
        </tr>
        <tr style="background-color:#2E7D32; color:#FFFFFF; font-weight:bold; text-align:center;">
            <th>GID</th>
            <th>Name</th>
            <th>Date</th>
            <th>Weekday</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php $i = 0; ?>
        <?php foreach ($employees as $e) :
            $empId = (int) $e['id'];
            $days  = $attMap[$empId] ?? [];

            for ($d = 1; $d <= $daysInMonth; $d++) :
                $i++;
                $rowBg = ($i % 2 === 0) ? '#E8F5E9' : '#FFFFFF';

                $ts       = strtotime("$month-" . str_pad($d, 2, '0', STR_PAD_LEFT));
                $dateStr  = date('n/j/Y', $ts);
                $weekday  = date('l', $ts); // Sunday, Monday, ...

                // Weekly Off overrides whatever (if anything) is stored, on Sundays
                if ($weekday === 'Sunday') {
                    $status = 'Weekly Off';
                } else {
                    $status = $days[$d] ?? '';
                }

                $statusColor = $statusColors[$status] ?? '000000';
        ?>
            <tr style="background-color:<?= $rowBg ?>;">
                <td style="color:#2E7D32; font-weight:bold; mso-number-format:'\@'"><?= htmlspecialchars($e['employee_code']) ?></td>
                <td style="color:#2E7D32; font-weight:bold;"><?= htmlspecialchars($e['name']) ?></td>
                <td><?= $dateStr ?></td>
                <td><?= $weekday ?></td>
                <td style="text-align:center; font-weight:bold; color:<?= $statusColor ?>;">
                    <?= htmlspecialchars($status) ?>
                </td>
            </tr>
        <?php
            endfor;
        endforeach; ?>
    </tbody>
</table>
<?php
exit;