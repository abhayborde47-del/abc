<?php
require "../config.php";
require "../includes/auth_user.php";

$msg = "";
$msgType = "info";

/* =========================================================
   PAGINATION
========================================================= */

$limit = 20;

$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;

if ($page < 1) {
    $page = 1;
}

$offset = ($page - 1) * $limit;


/* =========================================================
   SEARCH CB SERIAL NUMBER + DATE
   Default date filter = yesterday, so the page opens showing
   "live one day back" history instead of everything. If the
   user submits the search form (even leaving date blank on
   purpose), that explicit choice is respected instead.
========================================================= */

$search_cb = trim($_GET['cb_serial_no'] ?? '');

$defaultDate = date('Y-m-d', strtotime('-1 day'));
$search_date = isset($_GET['production_date'])
    ? trim($_GET['production_date'])
    : $defaultDate;

$where = [];
$params = [];
$types = "";


if ($search_cb !== "") {

    $where[] = "cb_serial_no LIKE ?";

    $params[] = "%" . $search_cb . "%";

    $types .= "s";
}


if ($search_date !== "") {

    $where[] = "production_date = ?";

    $params[] = $search_date;

    $types .= "s";
}


/* =========================================================
   COUNT TOTAL RECORDS
========================================================= */

$countSql = "SELECT COUNT(*) AS total FROM added_products";

if ($where) {

    $countSql .= " WHERE " . implode(" AND ", $where);
}


$countStmt = $conn->prepare($countSql);

if ($params) {

    $countStmt->bind_param($types, ...$params);
}

$countStmt->execute();

$countResult = $countStmt->get_result()->fetch_assoc();

$totalRecords = (int)$countResult['total'];

$totalPages = max(1, ceil($totalRecords / $limit));


/* =========================================================
   IF PAGE IS GREATER THAN TOTAL PAGES
========================================================= */

if ($page > $totalPages) {

    $page = $totalPages;

    $offset = ($page - 1) * $limit;
}


/* =========================================================
   GET HISTORY
========================================================= */

$sql = "
    SELECT *
    FROM added_products
";


if ($where) {

    $sql .= " WHERE " . implode(" AND ", $where);
}


$sql .= "
    ORDER BY added_at DESC
    LIMIT ? OFFSET ?
";


$params2 = $params;
$types2 = $types . "ii";

$params2[] = $limit;
$params2[] = $offset;


$stmt = $conn->prepare($sql);

$stmt->bind_param($types2, ...$params2);

$stmt->execute();

$history = $stmt->get_result();


/* =========================================================
   DELETE
========================================================= */

if (isset($_GET['delete'])) {

    $deleteId = (int)$_GET['delete'];

    if ($deleteId > 0) {

        $deleteStmt = $conn->prepare(
            "DELETE FROM added_products WHERE id = ?"
        );

        $deleteStmt->bind_param("i", $deleteId);

        if ($deleteStmt->execute()) {

            header("Location: history.php");
            exit;

        } else {

            $msg = "Unable to delete record.";
            $msgType = "danger";
        }
    }
}

?>

<?php require "../includes/header.php"; ?>
<?php require "../includes/sidebar_user.php"; ?>


<div class="content">

    <!-- =====================================================
         TITLE
    ====================================================== -->

    <div class="d-flex justify-content-between align-items-center mb-3">

        <h4 class="mb-0">
            Product History
        </h4>

        <!-- DOWNLOAD BUTTON -->

        <button
            type="button"
            class="btn btn-success"
            data-bs-toggle="modal"
            data-bs-target="#downloadMonthModal">

            Download Excel

        </button>

    </div>


    <!-- =====================================================
         MESSAGE
    ====================================================== -->

    <?php if ($msg): ?>

        <div class="alert alert-<?= $msgType ?>">

            <?= htmlspecialchars($msg) ?>

        </div>

    <?php endif; ?>


    <!-- =====================================================
         SEARCH
    ====================================================== -->

    <div class="card mb-3">

        <div class="card-body">

            <form method="GET" class="row g-2">

                <div class="col-md-4">

                    <input
                        type="text"
                        name="cb_serial_no"
                        class="form-control"
                        placeholder="Search CB Serial No"
                        autocomplete="off"
                        value="<?= htmlspecialchars($search_cb) ?>"
                    >

                </div>


                <div class="col-md-3">

                    <input
                        type="date"
                        name="production_date"
                        class="form-control"
                        value="<?= htmlspecialchars($search_date) ?>"
                    >

                </div>


                <div class="col-md-2">

                    <button
                        type="submit"
                        class="btn btn-primary w-100">

                        Search

                    </button>

                </div>


                <div class="col-md-2">

                    <a
                        href="history.php"
                        class="btn btn-secondary w-100">

                        Reset

                    </a>

                </div>

            </form>

            <p class="text-muted small mt-2 mb-0">
                Showing <?= $search_date !== '' ? 'records for <strong>' . htmlspecialchars($search_date) . '</strong>' : 'all records' ?> by default (one day back from today).
                Clear the date and search to view all history.
            </p>

        </div>

    </div>


    <!-- =====================================================
         COUNT CARD
    ====================================================== -->

    <div class="card mb-3">
        <div class="card-body py-3">
            <div class="d-flex flex-wrap align-items-center gap-2">
                <span class="fw-semibold me-2">
                    <?= $search_date !== '' ? htmlspecialchars($search_date) : 'All Dates' ?>
                    <?= $search_cb !== '' ? ' — CB: ' . htmlspecialchars($search_cb) : '' ?>:
                </span>
                <span class="badge bg-primary px-3 py-2">
                    Total Records: <?= $totalRecords ?>
                </span>
            </div>
        </div>
    </div>


    <!-- =====================================================
         RECORD INFORMATION
    ====================================================== -->

    <div class="d-flex justify-content-between align-items-center mb-2">

        <strong>
            History Records
        </strong>

        <small class="text-muted">

            Total: <?= $totalRecords ?>

            |
            Page <?= $page ?> of <?= $totalPages ?>

        </small>

    </div>


    <!-- =====================================================
         TABLE
    ====================================================== -->

    <div
        class="table-responsive"
        style="
            max-height:520px;
            overflow:auto;
            font-size:12px;
        "
    >

        <table
            class="table table-bordered table-sm table-hover align-middle"
        >

            <thead
                class="table-dark"
                style="
                    position:sticky;
                    top:0;
                    z-index:2;
                "
            >

                <tr>

                    <th>CB Serial No</th>
                    <th>Hall</th>
                    <th>Spare</th>
                    <th>SO No New</th>
                    <th>Region</th>
                    <th>Customer</th>
                    <th>Product</th>
                    <th>Creepage</th>
                    <th>Production Date</th>
                    <th>Remark</th>
                    <th>Added By</th>
                    <th>Action</th>

                </tr>

            </thead>


            <tbody>

            <?php if ($history && $history->num_rows > 0): ?>

                <?php while ($h = $history->fetch_assoc()): ?>

                    <tr>

                        <td>
                            <strong>
                                <?= htmlspecialchars(
                                    $h['cb_serial_no']
                                ) ?>
                            </strong>
                        </td>


                        <td>
                            <?= htmlspecialchars(
                                $h['hall']
                            ) ?>
                        </td>


                        <td>
                            <?= htmlspecialchars(
                                $h['spare']
                            ) ?>
                        </td>


                        <td>
                            <?= htmlspecialchars(
                                $h['so_no_new']
                            ) ?>
                        </td>


                        <td>
                            <?= htmlspecialchars(
                                $h['region']
                            ) ?>
                        </td>


                        <td>
                            <?= htmlspecialchars(
                                $h['customer']
                            ) ?>
                        </td>


                        <td>
                            <?= htmlspecialchars(
                                $h['product']
                            ) ?>
                        </td>


                        <td>
                            <?= htmlspecialchars(
                                $h['creepage']
                            ) ?>
                        </td>


                        <td>
                            <?= htmlspecialchars(
                                $h['production_date'] ?? ''
                            ) ?>
                        </td>


                        <td>
                            <?= htmlspecialchars(
                                $h['remark'] ?? ''
                            ) ?>
                        </td>


                        <td>
                            <?= htmlspecialchars(
                                $h['added_by']
                            ) ?>
                        </td>


                        <td class="text-nowrap">

                            <!-- UPDATE -->

                            <a
                                href="edit_product.php?id=<?= (int)$h['id'] ?>"
                                class="btn btn-sm btn-primary"
                            >

                                Update

                            </a>


                            <!-- DELETE -->

                            <a
                                href="?delete=<?= (int)$h['id'] ?>"
                                class="btn btn-sm btn-danger"
                                onclick="return confirm('Delete this product?')"
                            >

                                Delete

                            </a>

                        </td>

                    </tr>

                <?php endwhile; ?>

            <?php else: ?>

                <tr>

                    <td
                        colspan="12"
                        class="text-center text-muted py-4"
                    >

                        No records found.

                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>


    <!-- =====================================================
         PAGINATION
    ====================================================== -->

    <?php if ($totalPages > 1): ?>

        <div class="d-flex justify-content-center mt-3">

            <nav>

                <ul class="pagination pagination-sm">

                    <!-- PREVIOUS -->

                    <li
                        class="page-item
                        <?= ($page <= 1) ? 'disabled' : '' ?>"
                    >

                        <a
                            class="page-link"
                            href="?cb_serial_no=<?= urlencode($search_cb) ?>&production_date=<?= urlencode($search_date) ?>&page=<?= $page - 1 ?>"
                        >

                            Previous

                        </a>

                    </li>


                    <?php

                    /*
                     * Show limited page numbers
                     */

                    $startPage = max(1, $page - 2);

                    $endPage = min(
                        $totalPages,
                        $page + 2
                    );

                    ?>


                    <?php for (
                        $p = $startPage;
                        $p <= $endPage;
                        $p++
                    ): ?>

                        <li
                            class="page-item
                            <?= ($p == $page)
                                ? 'active'
                                : '' ?>"
                        >

                            <a
                                class="page-link"
                                href="?cb_serial_no=<?= urlencode($search_cb) ?>&production_date=<?= urlencode($search_date) ?>&page=<?= $p ?>"
                            >

                                <?= $p ?>

                            </a>

                        </li>

                    <?php endfor; ?>


                    <!-- NEXT -->

                    <li
                        class="page-item
                        <?= ($page >= $totalPages)
                            ? 'disabled'
                            : '' ?>"
                    >

                        <a
                            class="page-link"
                            href="?cb_serial_no=<?= urlencode($search_cb) ?>&production_date=<?= urlencode($search_date) ?>&page=<?= $page + 1 ?>"
                        >

                            Next

                        </a>

                    </li>

                </ul>

            </nav>

        </div>

    <?php endif; ?>

</div>


<!-- =========================================================
     DOWNLOAD MONTH MODAL
========================================================= -->

<div
    class="modal fade"
    id="downloadMonthModal"
    tabindex="-1"
>

    <div class="modal-dialog modal-dialog-centered">

        <div class="modal-content">

            <div class="modal-header">

                <h5 class="modal-title">

                    Download Monthly Excel

                </h5>

                <button
                    type="button"
                    class="btn-close"
                    data-bs-dismiss="modal"
                ></button>

            </div>


            <form
                method="GET"
                action="download_history.php"
            >

                <div class="modal-body">

                    <label class="form-label fw-bold">

                        Select Month

                    </label>


                    <input
                        type="month"
                        name="month"
                        class="form-control"
                        required
                    >


                    <small class="text-muted">

                        All records added during the selected
                        month will be downloaded.

                    </small>

                </div>


                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-secondary"
                        data-bs-dismiss="modal"
                    >

                        Cancel

                    </button>


                    <button
                        type="submit"
                        class="btn btn-success"
                    >

                        Download Excel

                    </button>

                </div>

            </form>

        </div>

    </div>

</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="../assets/js/script.js"></script>


</body>
</html>