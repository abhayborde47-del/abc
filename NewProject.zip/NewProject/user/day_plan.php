<?php
require "../config.php";
require "../includes/auth_user.php";
require "../includes/security.php";

$actor_email     = $_SESSION['user_email'];
$panel           = 'user';
$sidebar_include = "sidebar_user.php";

require "../includes/day_plan_shared.php";
