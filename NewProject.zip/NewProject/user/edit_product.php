<?php
require "../config.php";
require "../includes/auth_user.php";
require "../includes/security.php";

$msg = "";
$msgType = "info";

/* =========================================================
   GET PRODUCT ID
========================================================= */

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    die("Invalid product ID.");
}


/* =========================================================
   UPDATE PRODUCT
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {

    csrf_verify($_POST['csrf_token'] ?? '');

    $id              = (int)($_POST['id'] ?? 0);
    $new_cb          = trim($_POST['cb_serial_no'] ?? '');
    $hall            = trim($_POST['hall'] ?? '');
    $remark          = trim($_POST['remark'] ?? '');
    $production_date = trim($_POST['production_date'] ?? '');
    $status          = trim($_POST['status'] ?? 'Pending');

    if (!in_array($status, ['Pending', 'In Progress', 'Completed'], true)) {
        $status = 'Pending';
    }


    /* ---------------------------------------------------------
       BASIC VALIDATION
    --------------------------------------------------------- */

    if ($new_cb === '') {

        $msg = "CB Serial No cannot be empty.";
        $msgType = "danger";

    } elseif (!in_array($hall, ['CB1', 'CB2'], true)) {

        $msg = "Please select a valid Hall.";
        $msgType = "danger";

    } elseif ($production_date === '' ||
        !preg_match('/^\d{4}-\d{2}-\d{2}$/', $production_date)) {

        $msg = "Please select a valid Production Date.";
        $msgType = "danger";

    } else {


        /* -----------------------------------------------------
           CHECK DUPLICATE CB SERIAL NUMBER
           Exclude current record
        ----------------------------------------------------- */

        $check = $conn->prepare(
            "SELECT id
             FROM added_products
             WHERE cb_serial_no = ?
             AND id != ?
             LIMIT 1"
        );

        $check->bind_param("si", $new_cb, $id);
        $check->execute();

        $duplicate = $check->get_result()->fetch_assoc();


        if ($duplicate) {

            $msg = "CB Serial No " .
                   htmlspecialchars($new_cb) .
                   " is already used by another product.";

            $msgType = "danger";

        } else {


            /* -------------------------------------------------
               GET NEW CB INFORMATION FROM PLANS
            ------------------------------------------------- */

            $planStmt = $conn->prepare(
                "SELECT
                    cb_serial_no,
                    spare,
                    so_no_new,
                    region,
                    customer,
                    product,
                    creepage
                 FROM plans
                 WHERE cb_serial_no = ?
                 LIMIT 1"
            );

            $planStmt->bind_param("s", $new_cb);
            $planStmt->execute();

            $newPlan = $planStmt->get_result()->fetch_assoc();


            if (!$newPlan) {

                $msg = "CB Serial No " .
                       htmlspecialchars($new_cb) .
                       " was not found in the plans database.";

                $msgType = "danger";

            } else {


                /* -------------------------------------------------
                   UPDATE PRODUCT

                   Only these are taken from user:
                   - CB Serial No
                   - Hall
                   - Production Date
                   - Remark

                   Other information comes automatically from plans
                ------------------------------------------------- */

                $stmt = $conn->prepare(
                    "UPDATE added_products
                     SET
                        cb_serial_no = ?,
                        hall = ?,
                        spare = ?,
                        so_no_new = ?,
                        region = ?,
                        customer = ?,
                        product = ?,
                        creepage = ?,
                        production_date = ?,
                        remark = ?,
                        status = ?
                     WHERE id = ?"
                );


                $stmt->bind_param(
                    "sssssssssssi",
                    $new_cb,
                    $hall,
                    $newPlan['spare'],
                    $newPlan['so_no_new'],
                    $newPlan['region'],
                    $newPlan['customer'],
                    $newPlan['product'],
                    $newPlan['creepage'],
                    $production_date,
                    $remark,
                    $status,
                    $id
                );


                if ($stmt->execute()) {

                    /*
                     * IMPORTANT:
                     * After successful update return to add_product.php
                     */

                    header("Location: add_product.php?updated=1");
                    exit;

                } else {

                    if ($conn->errno == 1062) {

                        $msg =
                            "Duplicate CB Serial No. Update not allowed.";

                    } else {

                        $msg =
                            "Unable to update product: " .
                            htmlspecialchars($conn->error);
                    }

                    $msgType = "danger";
                }
            }
        }
    }
}


/* =========================================================
   GET CURRENT PRODUCT
========================================================= */

$stmt = $conn->prepare(
    "SELECT *
     FROM added_products
     WHERE id = ?
     LIMIT 1"
);

$stmt->bind_param("i", $id);
$stmt->execute();

$productData = $stmt->get_result()->fetch_assoc();


if (!$productData) {
    die("Product not found.");
}

?>


<?php require "../includes/header.php"; ?>


<div class="container-fluid py-3">

    <div class="card shadow-sm">

        <!-- =====================================================
             HEADER
        ====================================================== -->

        <div class="card-header">

            <h5 class="mb-0">
                Update Product
            </h5>

        </div>


        <div class="card-body">


            <!-- =================================================
                 MESSAGE
            ================================================== -->

            <?php if ($msg): ?>

                <div class="alert alert-<?= $msgType ?> alert-dismissible fade show">

                    <?= htmlspecialchars($msg) ?>

                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="alert">
                    </button>

                </div>

            <?php endif; ?>


            <!-- =================================================
                 UPDATE FORM
            ================================================== -->

            <form method="POST">

                <?php csrf_field(); ?>

                <input
                    type="hidden"
                    name="id"
                    value="<?= (int)$productData['id'] ?>"
                >


                <div class="row g-3">


                    <!-- =================================================
                         CB SERIAL NUMBER
                    ================================================== -->

                    <div class="col-md-4">

                        <label class="form-label fw-bold">
                            CB Serial No
                        </label>

                        <input
                            type="text"
                            name="cb_serial_no"
                            class="form-control"
                            value="<?= htmlspecialchars(
                                $productData['cb_serial_no']
                            ) ?>"
                            required
                            autocomplete="off"
                        >

                        <small class="text-muted">

                            Change CB Serial No to automatically
                            load its plan information.

                        </small>

                    </div>


                    <!-- =================================================
                         HALL
                    ================================================== -->

                    <div class="col-md-4">

                        <label class="form-label fw-bold">
                            Hall
                        </label>

                        <select
                            name="hall"
                            class="form-select"
                            required>

                            <option
                                value="CB1"
                                <?= ($productData['hall'] === 'CB1')
                                    ? 'selected'
                                    : '' ?>>

                                CB1

                            </option>

                            <option
                                value="CB2"
                                <?= ($productData['hall'] === 'CB2')
                                    ? 'selected'
                                    : '' ?>>

                                CB2

                            </option>

                        </select>

                    </div>


                    <!-- =================================================
                         PRODUCTION DATE (NEW)
                    ================================================== -->

                    <div class="col-md-4">

                        <label class="form-label fw-bold">
                            Production Date
                        </label>

                        <input
                            type="date"
                            name="production_date"
                            class="form-control"
                            value="<?= htmlspecialchars(
                                $productData['production_date'] ?? ''
                            ) ?>"
                            required
                        >

                    </div>


                    <!-- =================================================
                         REMARK
                    ================================================== -->

                    <div class="col-md-4">

                        <label class="form-label fw-bold">
                            Remark
                        </label>

                        <textarea
                            name="remark"
                            class="form-control"
                            rows="2"
                            placeholder="Enter remark..."
                        ><?= htmlspecialchars(
                            $productData['remark'] ?? ''
                        ) ?></textarea>

                    </div>


                    <!-- =================================================
                         STATUS
                    ================================================== -->

                    <div class="col-md-4">

                        <label class="form-label fw-bold">
                            Status
                        </label>

                        <?php $curStatus = $productData['status'] ?? 'Pending'; ?>

                        <select name="status" class="form-select">
                            <option value="Pending" <?= $curStatus === 'Pending' ? 'selected' : '' ?>>Not Done</option>
                            <option value="In Progress" <?= $curStatus === 'In Progress' ? 'selected' : '' ?>>In Process</option>
                            <option value="Completed" <?= $curStatus === 'Completed' ? 'selected' : '' ?>>Completed</option>
                        </select>

                    </div>


                    <!-- =================================================
                         PLAN INFORMATION
                    ================================================== -->

                    <div class="col-12">

                        <hr>

                        <h6 class="mb-3">

                            Plan Information

                            <span class="badge bg-secondary">
                                Read Only
                            </span>

                        </h6>

                    </div>


                    <!-- =================================================
                         SPARE
                    ================================================== -->

                    <div class="col-md-3">

                        <label class="form-label">
                            Spare
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            value="<?= htmlspecialchars(
                                $productData['spare'] ?? ''
                            ) ?>"
                            readonly
                        >

                    </div>


                    <!-- =================================================
                         SO NO NEW
                    ================================================== -->

                    <div class="col-md-3">

                        <label class="form-label">
                            SO No New
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            value="<?= htmlspecialchars(
                                $productData['so_no_new'] ?? ''
                            ) ?>"
                            readonly
                        >

                    </div>


                    <!-- =================================================
                         REGION
                    ================================================== -->

                    <div class="col-md-3">

                        <label class="form-label">
                            Region
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            value="<?= htmlspecialchars(
                                $productData['region'] ?? ''
                            ) ?>"
                            readonly
                        >

                    </div>


                    <!-- =================================================
                         CUSTOMER
                    ================================================== -->

                    <div class="col-md-3">

                        <label class="form-label">
                            Customer
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            value="<?= htmlspecialchars(
                                $productData['customer'] ?? ''
                            ) ?>"
                            readonly
                        >

                    </div>


                    <!-- =================================================
                         PRODUCT
                    ================================================== -->

                    <div class="col-md-3">

                        <label class="form-label">
                            Product
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            value="<?= htmlspecialchars(
                                $productData['product'] ?? ''
                            ) ?>"
                            readonly
                        >

                    </div>


                    <!-- =================================================
                         CREEPAGE
                    ================================================== -->

                    <div class="col-md-3">

                        <label class="form-label">
                            Creepage
                        </label>

                        <input
                            type="text"
                            class="form-control"
                            value="<?= htmlspecialchars(
                                $productData['creepage'] ?? ''
                            ) ?>"
                            readonly
                        >

                    </div>


                </div>


                <!-- =================================================
                     BUTTONS
                ================================================== -->

                <div class="mt-4">

                    <button
                        type="submit"
                        name="update"
                        class="btn btn-success">

                        Save Changes

                    </button>


                    <a
                        href="add_product.php"
                        class="btn btn-secondary">

                        Cancel

                    </a>

                </div>


            </form>

        </div>

    </div>

</div>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<script src="../assets/js/script.js"></script>

</body>
</html>