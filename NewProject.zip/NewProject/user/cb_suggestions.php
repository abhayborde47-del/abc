<?php
/* =========================================================
   AJAX ENDPOINT: SUGGEST CB SERIAL NO
   Kept in its own file so nothing else can print HTML
   before the JSON response.
========================================================= */

ob_start();

require "../config.php";
require "../includes/auth_user.php";
require "../includes/security.php";

/* Discard anything accidentally echoed by the includes above
   (whitespace, BOM, notices, etc.) so it can never break JSON */
ob_end_clean();

header('Content-Type: application/json');

$term = trim($_GET['term'] ?? '');
$suggestions = [];

if ($term !== '') {

    /* Escape LIKE wildcard characters so a literal % or _
       in the search term can't be misinterpreted as a wildcard */
    $safeTerm = str_replace(
        ['\\', '%', '_'],
        ['\\\\', '\%', '\_'],
        $term
    );

    $like = $safeTerm . '%';

    /* Only suggest CB serial numbers that:
       - exist in plans
       - are NOT already present in added_products
       (prevents suggesting/selecting a CB that will just
        fail the duplicate check on search) */
    $stmt = $conn->prepare(
        "SELECT DISTINCT p.cb_serial_no
         FROM plans p
         LEFT JOIN added_products ap
                ON ap.cb_serial_no = p.cb_serial_no
         WHERE p.cb_serial_no LIKE ? ESCAPE '\\\\'
           AND ap.id IS NULL
         ORDER BY p.cb_serial_no
         LIMIT 10"
    );

    $stmt->bind_param("s", $like);
    $stmt->execute();

    $res = $stmt->get_result();

    while ($row = $res->fetch_assoc()) {
        $suggestions[] = $row['cb_serial_no'];
    }
}

echo json_encode($suggestions);
exit;