<?php
require "../config.php";
require "../includes/auth_user.php";
require "../includes/day_plan_download_shared.php";
