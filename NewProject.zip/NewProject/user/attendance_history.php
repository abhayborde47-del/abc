<?php
require "../config.php";
require "../includes/auth_user.php";

/* Selected month (YYYY-MM) + optional factory filter */
$month   = $_GET['month']   ?? date('Y-m');
$factory = $_GET['factory'] ?? '';

$firstDay    = $month . '-01';
$daysInMonth = (int) date('t', strtotime($firstDay));
$lastDay     = $month . '-' . $daysInMonth;

/* Factories for the filter dropdown */
$factories = [];
$fRes = $conn->query("SELECT DISTINCT factory FROM employees WHERE factory <> '' ORDER BY factory");
if ($fRes) {
    while ($row = $fRes->fetch_assoc()) {
        $factories[] = $row['factory'];
    }
}

/* Employees to show */
if ($factory !== '') {
    $stmt = $conn->prepare("
        SELECT id, employee_code, name, factory
        FROM employees
        WHERE factory = ?
        ORDER BY name ASC
    ");
    $stmt->bind_param("s", $factory);
    $stmt->execute();
    $employees = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
} else {
    $employees = $conn->query("
        SELECT id, employee_code, name, factory
        FROM employees
        ORDER BY factory ASC, name ASC
    ")->fetch_all(MYSQLI_ASSOC);
}

/* Attendance for the month, keyed by [employee_id][day] = status letter */
$attMap = [];
$stmt = $conn->prepare("
    SELECT employee_id, attendance_date, status
    FROM attendance
    WHERE attendance_date BETWEEN ? AND ?
");
$stmt->bind_param("ss", $firstDay, $lastDay);
$stmt->execute();
$res = $stmt->get_result();

while ($row = $res->fetch_assoc()) {
    $day = (int) date('j', strtotime($row['attendance_date']));
    $letter = $row['status'] === 'Present' ? 'P' : ($row['status'] === 'Half Day' ? 'H' : 'A');
    $attMap[$row['employee_id']][$day] = $letter;
}

/* % attendance = (Present days + 0.5 * Half days) / days actually marked
   for that employee this month. Days with no record are excluded rather
   than counted as absent. */
function attendancePercent(array $days): float
{
    if (count($days) === 0) {
        return 0.0;
    }
    $earned = 0.0;
    foreach ($days as $letter) {
        if ($letter === 'P') {
            $earned += 1;
        } elseif ($letter === 'H') {
            $earned += 0.5;
        }
    }
    return round(($earned / count($days)) * 100, 1);
}

/* ------------------------------------------------------------
   LIVE "TODAY" ATTENDANCE STATUS — always shown, independent of
   the month/filter selection above, so it's obvious at a glance
   whether today's attendance has been filled in yet or not.
------------------------------------------------------------ */
$today = date('Y-m-d');

if ($factory !== '') {
    $stmtToday = $conn->prepare("
        SELECT e.id, e.employee_code, e.name, e.factory, a.status
        FROM employees e
        LEFT JOIN attendance a
            ON a.employee_id = e.id AND a.attendance_date = ?
        WHERE e.factory = ?
        ORDER BY e.name ASC
    ");
    $stmtToday->bind_param("ss", $today, $factory);
} else {
    $stmtToday = $conn->prepare("
        SELECT e.id, e.employee_code, e.name, e.factory, a.status
        FROM employees e
        LEFT JOIN attendance a
            ON a.employee_id = e.id AND a.attendance_date = ?
        ORDER BY e.factory ASC, e.name ASC
    ");
    $stmtToday->bind_param("s", $today);
}
$stmtToday->execute();
$todayRows = $stmtToday->get_result()->fetch_all(MYSQLI_ASSOC);

$todayTotal   = count($todayRows);
$todayPresent = 0;
$todayHalf    = 0;
$todayAbsent  = 0;
$todayMarked  = 0;

foreach ($todayRows as $tr) {
    if ($tr['status'] === 'Present') {
        $todayPresent++;
        $todayMarked++;
    } elseif ($tr['status'] === 'Half Day') {
        $todayHalf++;
        $todayMarked++;
    } elseif ($tr['status'] === 'Absent') {
        $todayAbsent++;
        $todayMarked++;
    }
}

$todayNotFilled = $todayTotal > 0 && $todayMarked === 0;
$todayPartial   = $todayTotal > 0 && $todayMarked > 0 && $todayMarked < $todayTotal;
$todayComplete  = $todayTotal > 0 && $todayMarked === $todayTotal;
?>

<?php require "../includes/header.php"; ?>
<?php require "../includes/sidebar_user.php"; ?>

<div class="content">

    <div class="container-fluid">

        <h3 class="mb-3">Attendance History</h3>

        <!-- Live "Today" status — always visible -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">
                    Today's Attendance —
                    <?= htmlspecialchars(date('d-M-Y', strtotime($today))) ?>
                    <?= $factory !== '' ? ' (' . htmlspecialchars($factory) . ')' : '' ?>
                </h5>
            </div>
            <div class="card-body">

                <?php if ($todayTotal === 0) : ?>

                    <div class="alert alert-secondary mb-0">
                        No employees found<?= $factory !== '' ? ' for ' . htmlspecialchars($factory) : '' ?>.
                    </div>

                <?php elseif ($todayNotFilled) : ?>

                    <div class="alert alert-warning mb-0">
                        Attendance not filled for today yet
                        (0 of <?= $todayTotal ?> employees marked).
                    </div>

                <?php else : ?>

                    <div class="alert <?= $todayComplete ? 'alert-success' : 'alert-info' ?> mb-3">
                        <?= $todayComplete
                            ? "Today's attendance is complete — $todayMarked of $todayTotal employees marked."
                            : "Today's attendance is partially filled — $todayMarked of $todayTotal employees marked." ?>
                    </div>

                    <div class="row text-center g-2">
                        <div class="col-6 col-md-3">
                            <div class="border rounded p-2">
                                <div class="fw-bold text-success fs-5"><?= $todayPresent ?></div>
                                <div class="small text-muted">Present</div>
                            </div>
                        </div>
                        <div class="col-6 col-md-3">
                            <div class="border rounded p-2">
                                <div class="fw-bold text-warning fs-5"><?= $todayHalf ?></div>
                                <div class="small text-muted">Half Day</div>
                            </div>
                        </div>
                        <div class="col-6 col-md-3">
                            <div class="border rounded p-2">
                                <div class="fw-bold text-danger fs-5"><?= $todayAbsent ?></div>
                                <div class="small text-muted">Absent</div>
                            </div>
                        </div>
                        <div class="col-6 col-md-3">
                            <div class="border rounded p-2">
                                <div class="fw-bold text-muted fs-5"><?= $todayTotal - $todayMarked ?></div>
                                <div class="small text-muted">Not Marked</div>
                            </div>
                        </div>
                    </div>

                <?php endif; ?>

            </div>
        </div>

        <!-- Filters -->
        <div class="card mb-4">
            <div class="card-body">

                <form method="GET" class="row g-2 align-items-end">

                    <div class="col-md-3">
                        <label class="form-label">Month</label>
                        <input type="month"
                               name="month"
                               class="form-control"
                               value="<?= htmlspecialchars($month) ?>"
                               required>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">Factory (optional)</label>
                        <select name="factory" class="form-control">
                            <option value="">All Factories</option>
                            <?php foreach ($factories as $f) : ?>
                                <option value="<?= htmlspecialchars($f) ?>"
                                    <?= $f === $factory ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($f) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary w-100">
                            View
                        </button>
                    </div>

                    <div class="col-md-2">
                        <a class="btn btn-success w-100"
                           href="download_attendance.php?<?= http_build_query(['month' => $month, 'factory' => $factory]) ?>">
                            Download Excel
                        </a>
                    </div>

                </form>

            </div>
        </div>

        <!-- Day-wise matrix -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <?= htmlspecialchars($month) ?><?= $factory !== '' ? ' — ' . htmlspecialchars($factory) : '' ?>
                </h5>
            </div>

            <div class="card-body">

                <div class="table-responsive">

                    <table class="table table-bordered table-sm text-center">

                        <thead>
                            <tr>
                                <th class="text-start">Employee</th>
                                <th>Factory</th>
                                <?php for ($d = 1; $d <= $daysInMonth; $d++) : ?>
                                    <th><?= $d ?></th>
                                <?php endfor; ?>
                                <th>%</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php if (count($employees) === 0) : ?>

                            <tr>
                                <td colspan="<?= $daysInMonth + 3 ?>" class="text-center">
                                    No Employees Found
                                </td>
                            </tr>

                        <?php else : ?>

                            <?php foreach ($employees as $e) :
                                $empId = (int) $e['id'];
                                $days  = $attMap[$empId] ?? [];
                            ?>

                                <tr>

                                    <td class="text-start">
                                        <?= htmlspecialchars($e['name']) ?>
                                        <div class="text-muted small"><?= htmlspecialchars($e['employee_code']) ?></div>
                                    </td>

                                    <td><?= htmlspecialchars($e['factory']) ?></td>

                                    <?php for ($d = 1; $d <= $daysInMonth; $d++) :
                                        $letter = $days[$d] ?? '-';
                                        $cls = $letter === 'P' ? 'text-success' :
                                               ($letter === 'H' ? 'text-warning' :
                                               ($letter === 'A' ? 'text-danger' : 'text-muted'));
                                    ?>
                                        <td class="<?= $cls ?>"><?= $letter ?></td>
                                    <?php endfor; ?>

                                    <td class="fw-bold"><?= attendancePercent($days) ?>%</td>

                                </tr>

                            <?php endforeach; ?>

                        <?php endif; ?>

                        </tbody>

                    </table>

                </div>

                <p class="text-muted small mb-0">
                    P = Present, H = Half Day, A = Absent, - = Not marked.
                    % is calculated over days actually marked for that employee this month.
                </p>

            </div>
        </div>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

</body>
</html>