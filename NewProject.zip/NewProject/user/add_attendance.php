<?php
require "../config.php";
require "../includes/auth_user.php";

$msg = "";

/* Selected date + factory (from GET load step or POST save step) */
$date    = $_POST['date']    ?? ($_GET['date']    ?? date('Y-m-d'));
$factory = $_POST['factory'] ?? ($_GET['factory'] ?? '');

/* Get distinct factories for the dropdown (e.g. CB1, CB2) */
$factories = [];
$fRes = $conn->query("SELECT DISTINCT factory FROM employees WHERE factory <> '' ORDER BY factory");
if ($fRes) {
    while ($row = $fRes->fetch_assoc()) {
        $factories[] = $row['factory'];
    }
}

/* Save attendance (upsert - if a record already exists for this
   employee+date it gets updated, so re-submitting the same date
   effectively edits the existing attendance) */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_attendance'])) {

    $allowedStatus = ['Present', 'Half Day', 'Absent'];
    $statuses = $_POST['status'] ?? [];

    $stmt = $conn->prepare("
        INSERT INTO attendance (employee_id, attendance_date, status)
        VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE status = VALUES(status)
    ");

    $added        = 0; // new attendance rows
    $updated      = 0; // existing rows whose status actually changed
    $sameNoChange = 0; // existing rows resubmitted with same status

    foreach ($statuses as $employeeId => $status) {

        if (!in_array($status, $allowedStatus, true)) {
            continue;
        }

        $employeeId = (int) $employeeId;

        $stmt->bind_param("iss", $employeeId, $date, $status);
        $stmt->execute();

        // mysqli upsert behaviour on affected_rows:
        // 1 -> new row inserted
        // 2 -> existing row updated to a new value
        // 0 -> existing row, value unchanged
        switch ($stmt->affected_rows) {
            case 1:
                $added++;
                break;
            case 2:
                $updated++;
                break;
            default:
                $sameNoChange++;
                break;
        }
    }

    $msg = "Attendance for $date ($factory) — "
         . "New: $added, Updated: $updated, Already same (no change): $sameNoChange.";
}

/* Load employees for the chosen factory, along with any existing
   attendance already marked for the chosen date (so re-opening the
   same date shows current values instead of resetting to blank) */
$employees = [];
$existing  = [];

if ($factory !== '') {

    $stmt = $conn->prepare("
        SELECT id, employee_code, name
        FROM employees
        WHERE factory = ?
        ORDER BY name ASC
    ");
    $stmt->bind_param("s", $factory);
    $stmt->execute();
    $employees = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    /* Pull existing attendance rows for THIS exact date only.
       This is what makes re-opening a date show that date's
       real saved statuses (e.g. Absent) instead of resetting. */
    $stmt2 = $conn->prepare("
        SELECT employee_id, status
        FROM attendance
        WHERE attendance_date = ?
    ");
    $stmt2->bind_param("s", $date);
    $stmt2->execute();
    $res2 = $stmt2->get_result();
    while ($row = $res2->fetch_assoc()) {
        $existing[$row['employee_id']] = $row['status'];
    }
}

/* Check whether attendance for THIS date + factory has already been
   fully uploaded — i.e. every employee in this factory already has
   an attendance row for this date. We still SHOW the table (with the
   correct per-date saved statuses) so it can be reviewed/edited —
   we just show an extra info banner above it. */
$alreadyUploaded = false;
$markedCount = 0;

if ($factory !== '' && count($employees) > 0) {

    foreach ($employees as $e) {
        if (isset($existing[(int) $e['id']])) {
            $markedCount++;
        }
    }

    if ($markedCount === count($employees)) {
        $alreadyUploaded = true;
    }
}
?>

<?php require "../includes/header.php"; ?>
<?php require "../includes/sidebar_user.php"; ?>

<div class="content">

    <div class="container-fluid">

        <h3 class="mb-3">Add Attendance</h3>

        <?php if (!empty($msg)) : ?>
            <div class="alert alert-info">
                <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <!-- Step 1: choose factory + date (auto-loads, no button needed) -->
        <div class="card mb-4">
            <div class="card-body">

                <form method="GET" id="loadForm" class="row g-2 align-items-end">

                    <div class="col-md-4">
                        <label class="form-label">Factory</label>
                        <select name="factory" class="form-control" onchange="this.form.submit()" required>
                            <option value="">-- Select Factory --</option>
                            <?php foreach ($factories as $f) : ?>
                                <option value="<?= htmlspecialchars($f) ?>"
                                    <?= $f === $factory ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($f) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Date</label>
                        <input type="date"
                               name="date"
                               class="form-control"
                               value="<?= htmlspecialchars($date) ?>"
                               onchange="this.form.submit()"
                               required>
                    </div>

                </form>

            </div>
        </div>

        <!-- Step 2: mark attendance for loaded employees -->
        <?php if ($factory !== '') : ?>

            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <?= htmlspecialchars($factory) ?> — <?= htmlspecialchars($date) ?>
                    </h5>
                </div>

                <div class="card-body">

                    <?php if (count($employees) === 0) : ?>

                        <p class="text-center text-muted mb-0">
                            No employees found for this factory.
                        </p>

                    <?php else : ?>

                        <?php if ($alreadyUploaded) : ?>

                            <!-- Info only — table below still shows and is still editable -->
                            <div class="alert alert-success">
                                Attendance already uploaded for
                                <strong><?= htmlspecialchars($date) ?></strong>
                                (<?= htmlspecialchars($factory) ?>) —
                                <?= $markedCount ?> of <?= count($employees) ?> employees marked.
                                You can review or change statuses below and save again.
                            </div>

                        <?php endif; ?>

                        <form method="POST">

                            <input type="hidden" name="date" value="<?= htmlspecialchars($date) ?>">
                            <input type="hidden" name="factory" value="<?= htmlspecialchars($factory) ?>">

                            <div class="table-responsive">

                                <table class="table table-bordered table-hover">

                                    <thead>
                                        <tr>
                                            <th>Employee Code</th>
                                            <th>Name</th>
                                            <th width="380">Status</th>
                                        </tr>
                                    </thead>

                                    <tbody>

                                    <?php foreach ($employees as $e) :

                                        $empId = (int) $e['id'];

                                        /* Status shown is ALWAYS specific to the
                                           selected date - not carried over from
                                           any other date. Defaults to Present
                                           only when this date has no saved row
                                           yet for this employee. */
                                        $currentStatus = $existing[$empId] ?? 'Present';
                                        $alreadyMarked = isset($existing[$empId]);
                                    ?>

                                        <tr>

                                            <td><?= htmlspecialchars($e['employee_code']) ?></td>

                                            <td>
                                                <?= htmlspecialchars($e['name']) ?>
                                            </td>

                                            <td>

                                                <div class="btn-group" role="group">

                                                    <?php foreach (['Present', 'Half Day', 'Absent'] as $opt) :
                                                        $inputId = "status_{$empId}_" . str_replace(' ', '', $opt);
                                                    ?>
                                                        <input type="radio"
                                                               class="btn-check"
                                                               name="status[<?= $empId ?>]"
                                                               id="<?= $inputId ?>"
                                                               value="<?= $opt ?>"
                                                               <?= $currentStatus === $opt ? 'checked' : '' ?>>

                                                        <label class="btn btn-outline-<?=
                                                            $opt === 'Present' ? 'success' : ($opt === 'Half Day' ? 'warning' : 'danger')
                                                        ?> btn-sm" for="<?= $inputId ?>">
                                                            <?= $opt ?>
                                                        </label>

                                                    <?php endforeach; ?>

                                                </div>

                                            </td>

                                        </tr>

                                    <?php endforeach; ?>

                                    </tbody>

                                </table>

                            </div>

                            <button type="submit" name="save_attendance" class="btn btn-success">
                                Save Attendance
                            </button>

                        </form>

                    <?php endif; ?>

                </div>
            </div>

        <?php endif; ?>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

</body>
</html>