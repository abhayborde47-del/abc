<?php
require "../config.php";
require "../includes/auth_user.php";

$msg = "";

/* Selected date + factory (Hall) — load step, auto-submits on change */
$entryDate = $_POST['entry_date'] ?? ($_GET['entry_date'] ?? date('Y-m-d'));
$factory   = $_POST['factory']    ?? ($_GET['factory']    ?? '');

/* Factories for the dropdown */
$factories = [];
$fRes = $conn->query("SELECT DISTINCT factory FROM employees WHERE factory <> '' ORDER BY factory");
if ($fRes) {
    while ($row = $fRes->fetch_assoc()) {
        $factories[] = $row['factory'];
    }
}

$allowedShift  = ['Shift 1', 'Shift 2', 'Shift 3', 'General'];
$allowedRating = ['75 kV', '55 kV', '145 kV', '245 kV', '420 kV', '800 kV', '420 kV PIR', '800 kV With PIR', '800 kV Without PIR'];
$allowedLoss   = ['L0','L1','L2','L3','L4','L5','L6','L7','L8','L9','L10'];

$stationMap = [
    'Fix Assembly'     => ['FCH Assembly', 'Clutch Plate', 'Sliding', 'Fix Screwing on Robot Moving'],
    'Auto 1'           => ['245 kV', '420 kV'],
    'Auto 2'           => ['IU Assembly on Robot', '245 kV Terminal Pad (2 Nos.)', 'Lifting Hook Setting', '420 kV Terminal Pad', 'Tank Preparation', 'Tank to IU Assembly'],
    'Manual 1 + 2'     => ['245 kV Compo RD', 'Indian Insulators', 'Rejects from Automation', '420/800 kV PIR Rework', 'O-Ring Cut', 'Casting Leak Repair'],
    'Gear Box'         => ['245 kV', '420 kV', '800 kV'],
    'Horizontal Line'  => ['420 kV Support', '245 kV Pole'],
    'Tank Assembly'    => ['420/800 kV Without PIR', '420/800 kV With PIR'],
];

/* =========================================================
   UPSERT helper — one row per employee PER DATE.
   Requires: ALTER TABLE plan_vs_actual
             ADD UNIQUE KEY uniq_emp_date (employee_id, entry_date);
   Re-submitting the same employee+date UPDATES the existing
   row instead of creating a duplicate.
========================================================= */
function upsertPlanActual(
    mysqli $conn,
    array $stationMap,
    array $allowedShift,
    array $allowedRating,
    array $allowedLoss,
    string $postDate,
    string $postFactory,
    int $employeeId,
    string $station,
    string $subOption,
    string $shift,
    string $rating,
    int $planQty,
    int $actualQty,
    string $lossCategory,
    float $lossTime,
    string $remark
): string {

    if ($station === '') {
        return 'blank';
    }

    $valid = ($employeeId > 0)
        && isset($stationMap[$station])
        && in_array($subOption, $stationMap[$station], true)
        && in_array($shift, $allowedShift, true)
        && in_array($rating, $allowedRating, true)
        && in_array($lossCategory, $allowedLoss, true);

    if (!$valid) {
        return 'invalid';
    }

    $stmt = $conn->prepare("
        INSERT INTO plan_vs_actual
            (entry_date, factory, employee_id, station, sub_option, shift, breaker_rating,
             plan_qty, actual_qty, loss_category, loss_time_hr, remark)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            factory        = VALUES(factory),
            station        = VALUES(station),
            sub_option     = VALUES(sub_option),
            shift          = VALUES(shift),
            breaker_rating = VALUES(breaker_rating),
            plan_qty       = VALUES(plan_qty),
            actual_qty     = VALUES(actual_qty),
            loss_category  = VALUES(loss_category),
            loss_time_hr   = VALUES(loss_time_hr),
            remark         = VALUES(remark)
    ");

    $stmt->bind_param(
        "ssissssiisds",
        $postDate, $postFactory, $employeeId, $station, $subOption, $shift, $rating,
        $planQty, $actualQty, $lossCategory, $lossTime, $remark
    );

    return $stmt->execute() ? 'saved' : 'invalid';
}

/* =========================================================
   PER-ROW UPDATE — save just the one employee's row via the
   Action column button next to their name.
========================================================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_row'])) {

    $postDate    = $_POST['entry_date'] ?? '';
    $postFactory = trim($_POST['factory'] ?? '');
    $employeeId  = (int) $_POST['update_row'];

    $stations   = $_POST['station']        ?? [];
    $subOptions = $_POST['sub_option']     ?? [];
    $shifts     = $_POST['shift']          ?? [];
    $ratings    = $_POST['breaker_rating'] ?? [];
    $planQtys   = $_POST['plan_qty']       ?? [];
    $actualQtys = $_POST['actual_qty']     ?? [];
    $lossCats   = $_POST['loss_category']  ?? [];
    $lossTimes  = $_POST['loss_time_hr']   ?? [];
    $remarks    = $_POST['remark']         ?? [];

    if ($postDate === '' || $postFactory === '' || $employeeId <= 0) {

        $msg = "Missing date, factory, or employee.";

    } else {

        $result = upsertPlanActual(
            $conn, $stationMap, $allowedShift, $allowedRating, $allowedLoss,
            $postDate, $postFactory, $employeeId,
            trim($stations[$employeeId] ?? ''),
            $subOptions[$employeeId] ?? '',
            $shifts[$employeeId] ?? '',
            $ratings[$employeeId] ?? '',
            (int) ($planQtys[$employeeId] ?? 0),
            (int) ($actualQtys[$employeeId] ?? 0),
            $lossCats[$employeeId] ?? '',
            (float) ($lossTimes[$employeeId] ?? 0),
            trim($remarks[$employeeId] ?? '')
        );

        $msg = match ($result) {
            'saved'   => "Entry updated for employee #$employeeId.",
            'blank'   => "Nothing entered for that employee — station is required.",
            default   => "Could not save — please check station/work/shift/rating/loss category are all set correctly.",
        };

        $entryDate = $postDate;
        $factory   = $postFactory;
    }
}

/* Handle delete from the roster table (if still needed elsewhere) */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_entry'])) {

    $id = (int) ($_POST['id'] ?? 0);
    if ($id > 0) {
        $stmt = $conn->prepare("DELETE FROM plan_vs_actual WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $msg = "Entry #$id deleted.";
    }
}

/* =========================================================
   Load employees for the selected factory + their attendance
   status for the selected date + their EXISTING plan_vs_actual
   entry for that date (if any) so the roster shows saved data
   pre-filled, ready to edit — not blank on reload.
========================================================= */
$employees  = [];
$attendance = [];
$existingEntries = [];

if ($factory !== '' && $entryDate !== '') {

    $stmt = $conn->prepare("
        SELECT id, employee_code, name
        FROM employees
        WHERE factory = ?
        ORDER BY name ASC
    ");
    $stmt->bind_param("s", $factory);
    $stmt->execute();
    $employees = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    $stmt2 = $conn->prepare("
        SELECT employee_id, status
        FROM attendance
        WHERE attendance_date = ?
    ");
    $stmt2->bind_param("s", $entryDate);
    $stmt2->execute();
    $res2 = $stmt2->get_result();
    while ($row = $res2->fetch_assoc()) {
        $attendance[$row['employee_id']] = $row['status'];
    }

    $stmt3 = $conn->prepare("
        SELECT employee_id, station, sub_option, shift, breaker_rating,
               plan_qty, actual_qty, loss_category, loss_time_hr, remark
        FROM plan_vs_actual
        WHERE entry_date = ? AND factory = ?
    ");
    $stmt3->bind_param("ss", $entryDate, $factory);
    $stmt3->execute();
    $res3 = $stmt3->get_result();
    while ($row = $res3->fetch_assoc()) {
        $existingEntries[$row['employee_id']] = $row;
    }
}
?>

<?php require "../includes/header.php"; ?>
<?php require "../includes/sidebar_user.php"; ?>

<div class="content">

    <div class="container-fluid">

        <h3 class="mb-3">Add Plan vs Actual Entry</h3>

        <?php if (!empty($msg)) : ?>
            <div class="alert alert-info"><?= htmlspecialchars($msg) ?></div>
        <?php endif; ?>

        <!-- Step 1: choose date + factory (auto-loads) -->
        <div class="card mb-4">
            <div class="card-body">

                <form method="GET" id="loadForm" class="row g-2 align-items-end">

                    <div class="col-md-4">
                        <label class="form-label">Date</label>
                        <input type="date"
                               name="entry_date"
                               class="form-control"
                               value="<?= htmlspecialchars($entryDate) ?>"
                               onchange="this.form.submit()"
                               required>
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Factory / Hall</label>
                        <select name="factory" class="form-control" onchange="this.form.submit()" required>
                            <option value="">-- Select Factory --</option>
                            <?php foreach ($factories as $f) : ?>
                                <option value="<?= htmlspecialchars($f) ?>"
                                    <?= $f === $factory ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($f) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                </form>

            </div>
        </div>

        <!-- Step 2: roster with attendance status + entry fields for present employees -->
        <?php if ($factory !== '') : ?>

            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">
                        <?= htmlspecialchars($factory) ?> — <?= htmlspecialchars($entryDate) ?>
                    </h5>
                </div>

                <div class="card-body">

                    <?php if (count($employees) === 0) : ?>

                        <p class="text-center text-muted mb-0">
                            No employees found for this factory.
                        </p>

                    <?php else : ?>

                        <form method="POST" id="bulkForm">

                            <input type="hidden" name="entry_date" value="<?= htmlspecialchars($entryDate) ?>">
                            <input type="hidden" name="factory" value="<?= htmlspecialchars($factory) ?>">

                            <div class="table-responsive">

                                <table class="table table-bordered table-sm align-middle">

                                    <thead class="table-light">
                                        <tr>
                                            <th style="min-width:130px;">Employee</th>
                                            <th style="min-width:100px;">Status</th>
                                            <th style="min-width:140px;">Station</th>
                                            <th style="min-width:170px;">Work / Sub Option</th>
                                            <th style="min-width:110px;">Shift</th>
                                            <th style="min-width:140px;">Rating</th>
                                            <th style="min-width:80px;">Plan</th>
                                            <th style="min-width:80px;">Actual</th>
                                            <th style="min-width:90px;">Loss Cat.</th>
                                            <th style="min-width:90px;">Loss Hr</th>
                                            <th style="min-width:150px;">Remark</th>
                                            <th style="min-width:90px;">Action</th>
                                        </tr>
                                    </thead>

                                    <tbody>

                                    <?php foreach ($employees as $e) :

                                        $empId  = (int) $e['id'];
                                        $status = $attendance[$empId] ?? 'Not Marked';
                                        $isAbsent = ($status === 'Absent');
                                        $ex = $existingEntries[$empId] ?? null;

                                        $badgeClass = match ($status) {
                                            'Present'    => 'bg-success',
                                            'Half Day'   => 'bg-warning text-dark',
                                            'Absent'     => 'bg-danger',
                                            default      => 'bg-secondary',
                                        };

                                        $curStation   = $ex['station']        ?? '';
                                        $curSubOption = $ex['sub_option']     ?? '';
                                        $curShift     = $ex['shift']          ?? '';
                                        $curRating    = $ex['breaker_rating'] ?? '';
                                        $curPlanQty   = $ex['plan_qty']       ?? '';
                                        $curActualQty = $ex['actual_qty']     ?? '';
                                        $curLossCat   = $ex['loss_category']  ?? '';
                                        $curLossTime  = $ex['loss_time_hr']   ?? '';
                                        $curRemark    = $ex['remark']         ?? '';
                                    ?>

                                        <tr>

                                            <td>
                                                <?= htmlspecialchars($e['name']) ?>
                                                <div class="text-muted small"><?= htmlspecialchars($e['employee_code']) ?></div>
                                            </td>

                                            <td>
                                                <span class="badge <?= $badgeClass ?>"><?= htmlspecialchars($status) ?></span>
                                                <?php if ($ex) : ?>
                                                    <div class="badge bg-info text-dark mt-1">Saved</div>
                                                <?php endif; ?>
                                            </td>

                                            <?php if ($isAbsent) : ?>

                                                <td colspan="9" class="text-muted text-center">
                                                    — Absent, no entry —
                                                </td>

                                            <?php else : ?>

                                                <td>
                                                    <select name="station[<?= $empId ?>]"
                                                            id="station_<?= $empId ?>"
                                                            class="form-select form-select-sm station-select"
                                                            data-emp="<?= $empId ?>">
                                                        <option value="">--</option>
                                                        <?php foreach (array_keys($stationMap) as $st) : ?>
                                                            <option value="<?= htmlspecialchars($st) ?>"
                                                                <?= $curStation === $st ? 'selected' : '' ?>>
                                                                <?= htmlspecialchars($st) ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </td>

                                                <td>
                                                    <select name="sub_option[<?= $empId ?>]"
                                                            id="sub_option_<?= $empId ?>"
                                                            class="form-select form-select-sm">
                                                        <option value="">--</option>
                                                        <?php foreach (($stationMap[$curStation] ?? []) as $so) : ?>
                                                            <option value="<?= htmlspecialchars($so) ?>"
                                                                <?= $curSubOption === $so ? 'selected' : '' ?>>
                                                                <?= htmlspecialchars($so) ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </td>

                                                <td>
                                                    <select name="shift[<?= $empId ?>]" class="form-select form-select-sm">
                                                        <option value="">--</option>
                                                        <?php foreach ($allowedShift as $s) : ?>
                                                            <option value="<?= htmlspecialchars($s) ?>"
                                                                <?= $curShift === $s ? 'selected' : '' ?>>
                                                                <?= htmlspecialchars($s) ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </td>

                                                <td>
                                                    <select name="breaker_rating[<?= $empId ?>]" class="form-select form-select-sm">
                                                        <option value="">--</option>
                                                        <?php foreach ($allowedRating as $r) : ?>
                                                            <option value="<?= htmlspecialchars($r) ?>"
                                                                <?= $curRating === $r ? 'selected' : '' ?>>
                                                                <?= htmlspecialchars($r) ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </td>

                                                <td>
                                                    <input type="number" min="0" name="plan_qty[<?= $empId ?>]"
                                                           class="form-control form-control-sm"
                                                           value="<?= htmlspecialchars((string) $curPlanQty) ?>">
                                                </td>

                                                <td>
                                                    <input type="number" min="0" name="actual_qty[<?= $empId ?>]"
                                                           class="form-control form-control-sm"
                                                           value="<?= htmlspecialchars((string) $curActualQty) ?>">
                                                </td>

                                                <td>
                                                    <select name="loss_category[<?= $empId ?>]" class="form-select form-select-sm">
                                                        <option value="">--</option>
                                                        <?php foreach ($allowedLoss as $l) : ?>
                                                            <option value="<?= htmlspecialchars($l) ?>"
                                                                <?= $curLossCat === $l ? 'selected' : '' ?>>
                                                                <?= htmlspecialchars($l) ?>
                                                            </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                </td>

                                                <td>
                                                    <input type="number" step="0.1" min="0" name="loss_time_hr[<?= $empId ?>]"
                                                           class="form-control form-control-sm"
                                                           value="<?= htmlspecialchars((string) $curLossTime) ?>">
                                                </td>

                                                <td>
                                                    <input type="text" name="remark[<?= $empId ?>]"
                                                           class="form-control form-control-sm"
                                                           value="<?= htmlspecialchars((string) $curRemark) ?>">
                                                </td>

                                                <td>
                                                    <button type="submit"
                                                            name="update_row"
                                                            value="<?= $empId ?>"
                                                            class="btn btn-sm btn-outline-primary w-100">
                                                        <?= $ex ? 'Update' : 'Save' ?>
                                                    </button>
                                                </td>

                                            <?php endif; ?>

                                        </tr>

                                    <?php endforeach; ?>

                                    </tbody>

                                </table>

                            </div>

                        </form>

                    <?php endif; ?>

                </div>
            </div>

        <?php endif; ?>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

<script>
// Station -> sub-option cascading dropdown, works for ANY number of employee rows
// via event delegation (single listener handles every .station-select on the page).
var stationMap = <?= json_encode($stationMap) ?>;

document.addEventListener('change', function (e) {
    if (!e.target.classList.contains('station-select')) return;

    var empId = e.target.getAttribute('data-emp');
    var subSelect = document.getElementById('sub_option_' + empId);
    if (!subSelect) return;

    var options = stationMap[e.target.value] || [];

    subSelect.innerHTML = '<option value="">--</option>';
    options.forEach(function (opt) {
        var el = document.createElement('option');
        el.value = opt;
        el.textContent = opt;
        subSelect.appendChild(el);
    });
});
</script>

</body>
</html>