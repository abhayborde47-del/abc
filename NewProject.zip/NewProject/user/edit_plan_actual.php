<?php
require "../config.php";
require "../includes/auth_user.php";

$id   = (int) ($_GET['id'] ?? 0);
$back = $_GET['date'] ?? date('Y-m-d');
$msg  = "";

$allowedShift  = ['Shift A', 'Shift B', 'Shift C', 'General'];
$allowedRating = ['75 kV', '55 kV', '145 kV', '245 kV', '420 kV', '800 kV', '420 kV PIR', '800 kV With PIR', '800 kV Without PIR'];
$allowedLoss   = ['L0','L1','L2','L3','L4','L5','L6','L7','L8','L9','L10'];

$stationMap = [
    'Fix Assembly'     => ['FCH Assembly', 'Clutch Plate', 'Sliding', 'Fix Screwing on Robot Moving'],
    'Auto 1'           => ['245 kV', '420 kV'],
    'Auto 2'           => ['IU Assembly on Robot', '245 kV Terminal Pad (2 Nos.)', 'Lifting Hook Setting', '420 kV Terminal Pad', 'Tank Preparation', 'Tank to IU Assembly'],
    'Manual 1 + 2'     => ['245 kV Compo RD', 'Indian Insulators', 'Rejects from Automation', '420/800 kV PIR Rework', 'O-Ring Cut', 'Casting Leak Repair'],
    'Gear Box'         => ['245 kV', '420 kV', '800 kV'],
    'Horizontal Line'  => ['420 kV Support', '245 kV Pole'],
    'Tank Assembly'    => ['420/800 kV Without PIR', '420/800 kV With PIR'],
];

if ($id <= 0) {
    header("Location: view_plan_actual.php?date=" . urlencode($back));
    exit;
}

/* Handle update */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_entry'])) {

    $entryDate    = $_POST['entry_date']    ?? '';
    $factory      = trim($_POST['factory']  ?? '');
    $station      = $_POST['station']       ?? '';
    $subOption    = $_POST['sub_option']    ?? '';
    $shift        = $_POST['shift']         ?? '';
    $rating       = $_POST['breaker_rating']?? '';
    $planQty      = (int) ($_POST['plan_qty']   ?? 0);
    $actualQty    = (int) ($_POST['actual_qty'] ?? 0);
    $lossCategory = $_POST['loss_category'] ?? '';
    $lossTime     = (float) ($_POST['loss_time_hr'] ?? 0);

    $stmt = $conn->prepare("
        UPDATE plan_vs_actual SET
            entry_date = ?, factory = ?, station = ?, sub_option = ?, shift = ?,
            breaker_rating = ?, plan_qty = ?, actual_qty = ?, loss_category = ?, loss_time_hr = ?
        WHERE id = ?
    ");
    $stmt->bind_param(
        "ssssssiisdi",
        $entryDate, $factory, $station, $subOption, $shift, $rating,
        $planQty, $actualQty, $lossCategory, $lossTime, $id
    );
    $stmt->execute();

    header("Location: view_plan_actual.php?date=" . urlencode($entryDate));
    exit;
}

/* Load existing record */
$stmt = $conn->prepare("SELECT * FROM plan_vs_actual WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$entry = $stmt->get_result()->fetch_assoc();

if (!$entry) {
    header("Location: view_plan_actual.php?date=" . urlencode($back));
    exit;
}

$factories = [];
$fRes = $conn->query("SELECT DISTINCT factory FROM employees WHERE factory <> '' ORDER BY factory");
if ($fRes) {
    while ($row = $fRes->fetch_assoc()) {
        $factories[] = $row['factory'];
    }
}
?>

<?php require "../includes/header.php"; ?>
<?php require "../includes/sidebar_user.php"; ?>

<div class="content">
    <div class="container-fluid">

        <h3 class="mb-3">Edit Plan vs Actual Entry</h3>

        <div class="card">
            <div class="card-body">

                <form method="POST" class="row g-3">

                    <div class="col-md-3">
                        <label class="form-label">Date</label>
                        <input type="date" name="entry_date" class="form-control"
                               value="<?= htmlspecialchars($entry['entry_date']) ?>" required>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">Factory</label>
                        <input type="text" name="factory" list="factoryList" class="form-control"
                               value="<?= htmlspecialchars($entry['factory']) ?>" required>
                        <datalist id="factoryList">
                            <?php foreach ($factories as $f) : ?>
                                <option value="<?= htmlspecialchars($f) ?>">
                            <?php endforeach; ?>
                        </datalist>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">Station</label>
                        <select name="station" id="stationSelect" class="form-control" required>
                            <?php foreach (array_keys($stationMap) as $st) : ?>
                                <option value="<?= htmlspecialchars($st) ?>"
                                    <?= $st === $entry['station'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($st) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">Work / Sub Option</label>
                        <select name="sub_option" id="subOptionSelect" class="form-control" required>
                            <?php foreach (($stationMap[$entry['station']] ?? []) as $opt) : ?>
                                <option value="<?= htmlspecialchars($opt) ?>"
                                    <?= $opt === $entry['sub_option'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($opt) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">Shift</label>
                        <select name="shift" class="form-control" required>
                            <?php foreach ($allowedShift as $s) : ?>
                                <option value="<?= htmlspecialchars($s) ?>"
                                    <?= $s === $entry['shift'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($s) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">Breaker Rating</label>
                        <select name="breaker_rating" class="form-control" required>
                            <?php foreach ($allowedRating as $r) : ?>
                                <option value="<?= htmlspecialchars($r) ?>"
                                    <?= $r === $entry['breaker_rating'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($r) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">Plan Qty</label>
                        <input type="number" name="plan_qty" class="form-control" min="0"
                               value="<?= (int) $entry['plan_qty'] ?>" required>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">Actual Qty</label>
                        <input type="number" name="actual_qty" class="form-control" min="0"
                               value="<?= (int) $entry['actual_qty'] ?>" required>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">Loss Category</label>
                        <select name="loss_category" class="form-control" required>
                            <?php foreach ($allowedLoss as $l) : ?>
                                <option value="<?= htmlspecialchars($l) ?>"
                                    <?= $l === $entry['loss_category'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($l) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="col-md-3">
                        <label class="form-label">Loss Time (Hr)</label>
                        <input type="number" step="0.1" min="0" name="loss_time_hr" class="form-control"
                               value="<?= htmlspecialchars($entry['loss_time_hr']) ?>" required>
                    </div>

                    <div class="col-md-3 d-flex align-items-end gap-2">
                        <button type="submit" name="update_entry" class="btn btn-success w-100">
                            Update
                        </button>
                        <a href="view_plan_actual.php?date=<?= urlencode($entry['entry_date']) ?>"
                           class="btn btn-secondary w-100">
                            Cancel
                        </a>
                    </div>

                </form>

            </div>
        </div>

    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

<script>
var stationMap = <?= json_encode($stationMap) ?>;
var stationSelect = document.getElementById('stationSelect');
var subOptionSelect = document.getElementById('subOptionSelect');

stationSelect.addEventListener('change', function () {
    var options = stationMap[this.value] || [];
    subOptionSelect.innerHTML = '<option value="">-- Select --</option>';
    options.forEach(function (opt) {
        var el = document.createElement('option');
        el.value = opt;
        el.textContent = opt;
        subOptionSelect.appendChild(el);
    });
});
</script>

</body>
</html>