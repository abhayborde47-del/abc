<?php
require "../config.php";
require "../includes/auth_user.php";

$id   = (int) ($_GET['id'] ?? 0);
$back = $_GET['date'] ?? date('Y-m-d');

if ($id > 0) {
    $stmt = $conn->prepare("DELETE FROM plan_vs_actual WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

header("Location: view_plan_actual.php?date=" . urlencode($back));
exit;