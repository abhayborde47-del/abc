<?php
require "../config.php";
require "../includes/auth_user.php";

$msg = "";

/* Defaults to TODAY (live date). User can pick another date to view it. */
$searchDate = $_GET['date'] ?? date('Y-m-d');
$searchName = trim($_GET['name'] ?? '');
$isToday    = ($searchDate === date('Y-m-d'));

/* Handle inline status update */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {

    $attendanceId = (int) $_POST['attendance_id'];
    $newStatus    = $_POST['new_status'];
    $allowed      = ['Present', 'Half Day', 'Absent'];

    if (in_array($newStatus, $allowed, true)) {
        $stmt = $conn->prepare("UPDATE attendance SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $newStatus, $attendanceId);
        $stmt->execute();
    }

    // Redirect back preserving the current search, avoids re-submit on refresh
    header("Location: view_attendance.php?" . http_build_query([
        'date' => $searchDate,
        'name' => $searchName,
    ]));
    exit;
}

/* Factories, used to split the results into side-by-side columns
   (e.g. CB1 on the left, CB2 on the right) */
$factories = [];
$fRes = $conn->query("SELECT DISTINCT factory FROM employees WHERE factory <> '' ORDER BY factory");
if ($fRes) {
    while ($row = $fRes->fetch_assoc()) {
        $factories[] = $row['factory'];
    }
}

/* Build search query for the chosen date (+ optional name filter) */
$conditions = ["a.attendance_date = ?"];
$params     = [$searchDate];
$types      = "s";

if ($searchName !== '') {
    $conditions[] = "e.name LIKE ?";
    $params[]     = "%$searchName%";
    $types       .= "s";
}

$where = "WHERE " . implode(" AND ", $conditions);

$sql = "
    SELECT a.id, a.attendance_date, a.status,
           e.employee_code, e.name, e.factory
    FROM attendance a
    JOIN employees e ON e.id = a.employee_id
    $where
    ORDER BY e.factory ASC, e.name ASC
";

$stmt = $conn->prepare($sql);
$stmt->bind_param($types, ...$params);
$stmt->execute();
$result = $stmt->get_result();

/* Group records by factory, so each factory renders as its own
   small column/table */
$recordsByFactory = [];
while ($r = $result->fetch_assoc()) {
    $recordsByFactory[$r['factory']][] = $r;
}

/* ---- Grand totals across ALL factories for the selected date ---- */
$grandTotal   = 0;
$grandPresent = 0;
$grandHalf    = 0;
$grandAbsent  = 0;

foreach ($recordsByFactory as $rows) {
    foreach ($rows as $r) {
        $grandTotal++;
        if ($r['status'] === 'Present') {
            $grandPresent++;
        } elseif ($r['status'] === 'Half Day') {
            $grandHalf++;
        } elseif ($r['status'] === 'Absent') {
            $grandAbsent++;
        }
    }
}
?>

<?php require "../includes/header.php"; ?>
<?php require "../includes/sidebar_user.php"; ?>

<div class="content">

    <div class="container-fluid">

        <h3 class="mb-3">View Attendance</h3>

        <?php if (!empty($msg)) : ?>
            <div class="alert alert-info">
                <?= htmlspecialchars($msg) ?>
            </div>
        <?php endif; ?>

        <!-- Search -->
        <div class="card mb-4">
            <div class="card-body">

                <form method="GET" id="filterForm" class="row g-2 align-items-end">

                    <div class="col-md-4">
                        <label class="form-label">
                            Date
                            <?php if ($isToday) : ?>
                                <span class="badge bg-success ms-1">Live / Today</span>
                            <?php endif; ?>
                        </label>
                        <input type="date"
                               name="date"
                               class="form-control"
                               value="<?= htmlspecialchars($searchDate) ?>"
                               onchange="this.form.submit()">
                    </div>

                    <div class="col-md-4">
                        <label class="form-label">Employee Name</label>
                        <input type="text"
                               name="name"
                               id="nameFilter"
                               class="form-control"
                               placeholder="Search by name"
                               value="<?= htmlspecialchars($searchName) ?>">
                    </div>

                    <div class="col-md-4">
                        <a class="btn btn-success w-100" href="download_attendance.php">
                            Download Excel
                        </a>
                    </div>

                </form>

                <p class="text-muted small mt-2 mb-0">
                    Showing attendance for <strong><?= htmlspecialchars($searchDate) ?></strong>
                    <?= $isToday ? ' (today, live).' : '.' ?>
                    Changing the date or typing a name updates the results automatically.
                </p>

            </div>
        </div>

        <!-- Grand total summary card (all factories combined) -->
        <div class="card mb-4">
            <div class="card-body py-3">
                <div class="d-flex flex-wrap align-items-center gap-2">
                    <span class="fw-semibold me-2">
                        Overall — <?= htmlspecialchars($searchDate) ?>:
                    </span>
                    <span class="badge bg-dark px-3 py-2">Total: <?= $grandTotal ?></span>
                    <span class="badge bg-success px-3 py-2">Present: <?= $grandPresent ?></span>
                    <span class="badge bg-warning text-dark px-3 py-2">Half Day: <?= $grandHalf ?></span>
                    <span class="badge bg-danger px-3 py-2">Absent: <?= $grandAbsent ?></span>
                </div>
            </div>
        </div>

        <!-- Results, split into one column per factory (CB1, CB2, ...) -->
        <?php if (count($factories) === 0) : ?>

            <div class="alert alert-secondary">No factories found.</div>

        <?php else : ?>

            <div class="row g-3">

                <?php foreach ($factories as $f) :

                    $rows = $recordsByFactory[$f] ?? [];

                    /* Per-factory counts for this date */
                    $total   = count($rows);
                    $present = 0;
                    $half    = 0;
                    $absent  = 0;

                    foreach ($rows as $r) {
                        if ($r['status'] === 'Present') {
                            $present++;
                        } elseif ($r['status'] === 'Half Day') {
                            $half++;
                        } elseif ($r['status'] === 'Absent') {
                            $absent++;
                        }
                    }
                ?>

                    <div class="col-md-6">

                        <div class="card h-100">

                            <div class="card-header py-2">
                                <h6 class="mb-0">
                                    <?= htmlspecialchars($f) ?>
                                    <span class="text-muted fw-normal small">
                                        — <?= htmlspecialchars($searchDate) ?>
                                        (<?= count($rows) ?> marked)
                                    </span>
                                </h6>
                            </div>

                            <!-- Per-factory summary stats strip -->
                            <div class="card-body py-2 border-bottom bg-light">
                                <div class="d-flex flex-wrap gap-2">
                                    <span class="badge bg-secondary">Total: <?= $total ?></span>
                                    <span class="badge bg-success">Present: <?= $present ?></span>
                                    <span class="badge bg-warning text-dark">Half Day: <?= $half ?></span>
                                    <span class="badge bg-danger">Absent: <?= $absent ?></span>
                                </div>
                            </div>

                            <div class="card-body p-2">

                                <div class="table-responsive">

                                    <table class="table table-bordered table-sm table-hover mb-0">

                                        <thead>
                                            <tr>
                                                <th>Code</th>
                                                <th>Name</th>
                                                <th>Status</th>
                                                <th width="170">Update</th>
                                            </tr>
                                        </thead>

                                        <tbody>

                                        <?php if (count($rows) === 0) : ?>

                                            <tr>
                                                <td colspan="4" class="text-center text-muted">
                                                    No attendance marked for this date.
                                                </td>
                                            </tr>

                                        <?php else : ?>

                                            <?php foreach ($rows as $r) : ?>

                                                <tr>

                                                    <td><?= htmlspecialchars($r['employee_code']) ?></td>
                                                    <td><?= htmlspecialchars($r['name']) ?></td>

                                                    <td>
                                                        <span class="badge bg-<?=
                                                            $r['status'] === 'Present' ? 'success' :
                                                            ($r['status'] === 'Half Day' ? 'warning' : 'danger')
                                                        ?>">
                                                            <?= htmlspecialchars($r['status']) ?>
                                                        </span>
                                                    </td>

                                                    <td>
                                                        <form method="POST" class="d-flex gap-1">

                                                            <input type="hidden" name="attendance_id" value="<?= (int) $r['id'] ?>">
                                                            <input type="hidden" name="date" value="<?= htmlspecialchars($searchDate) ?>">
                                                            <input type="hidden" name="name" value="<?= htmlspecialchars($searchName) ?>">

                                                            <select name="new_status" class="form-select form-select-sm">
                                                                <?php foreach (['Present', 'Half Day', 'Absent'] as $opt) : ?>
                                                                    <option value="<?= $opt ?>"
                                                                        <?= $r['status'] === $opt ? 'selected' : '' ?>>
                                                                        <?= $opt ?>
                                                                    </option>
                                                                <?php endforeach; ?>
                                                            </select>

                                                            <button type="submit"
                                                                    name="update_status"
                                                                    class="btn btn-sm btn-outline-primary">
                                                                Save
                                                            </button>

                                                        </form>
                                                    </td>

                                                </tr>

                                            <?php endforeach; ?>

                                        <?php endif; ?>

                                        </tbody>

                                    </table>

                                </div>

                            </div>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="../assets/js/script.js"></script>

<script>
// Auto-submit the filter form as the user types in Name,
// debounced so it doesn't fire a request on every keystroke.
(function () {
    var nameInput = document.getElementById('nameFilter');
    var form = document.getElementById('filterForm');
    var timer = null;

    nameInput.addEventListener('input', function () {
        clearTimeout(timer);
        timer = setTimeout(function () {
            form.submit();
        }, 600);
    });
})();
</script>

</body>
</html>