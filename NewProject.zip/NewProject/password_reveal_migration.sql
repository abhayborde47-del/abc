-- Run this once in phpMyAdmin (or mysql CLI) against your existing `plan_demo` database.
-- Adds a reversibly-encrypted copy of the password, used only by the new
-- Admin/Owner "View Password" feature. Does NOT touch the existing bcrypt
-- `password` column used for login.
--
-- NOTE: accounts created BEFORE this migration will have password_enc = NULL
-- and will show "no viewable password stored" until their password is reset
-- once from the Admin/Owner panel (bcrypt hashes can't be decrypted back
-- into this column).

ALTER TABLE `users`
    ADD COLUMN `password_enc` VARCHAR(255) DEFAULT NULL AFTER `password`;

ALTER TABLE `admins`
    ADD COLUMN `password_enc` VARCHAR(255) DEFAULT NULL AFTER `password`;
