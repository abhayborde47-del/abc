-- Run this once in phpMyAdmin (or mysql CLI) against your existing `plan_demo` database.
-- Safe to run even if admin_type is already VARCHAR.

-- 1. Make sure admin_type can hold any of: owner, AIS, store, ADI
ALTER TABLE admins
    MODIFY admin_type VARCHAR(20) NOT NULL DEFAULT 'store';

-- 2. Rename the old 'main' admin type to 'AIS' (same people, same admin/ panel,
--    just the new name that matches the 3 admin roles: store / AIS / ADI).
UPDATE admins SET admin_type = 'AIS' WHERE admin_type = 'main';

-- 3. Create your first Owner account.
--    IMPORTANT: change the email below, then generate your own password hash with:
--    php -r "echo password_hash('YourRealPassword', PASSWORD_BCRYPT);"
--    and paste the result in place of the placeholder hash before running this.
INSERT INTO admins (name, email, password, role, created_at, admin_type, store_id)
VALUES (
    'Owner',
    'owner@example.com',
    '$2y$10$REPLACE.WITH.YOUR.OWN.BCRYPT.HASH.xxxxxxxxxxxxxxxxxxxxx',
    'Admin',
    NOW(),
    'owner',
    NULL
);
